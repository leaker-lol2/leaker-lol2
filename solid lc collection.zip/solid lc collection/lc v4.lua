for i,v in next, game:GetService("Players").LocalPlayer.Character:GetDescendants() do
	if v:IsA("BasePart") and v.Name ~="HumanoidRootPart" then 
		game:GetService("RunService").Heartbeat:connect(function()
			v.Velocity = Vector3.new(31,0,0)
		end)
	end
end
mode = 1
Bypass = "death"
loadstring(game:GetObjects("rbxassetid://5325226148")[1].Source)()
for i,v in next, game:GetService("Players").LocalPlayer.Character:GetDescendants() do
	if v:IsA("BasePart") and v.Name ~="HumanoidRootPart" then 
		game:GetService("RunService").Heartbeat:connect(function()
			v.Velocity = Vector3.new(0,30,0)
			wait(0.5)
		end)
	end
end
local p = game.Players.LocalPlayer
local char = p.Character
local mouse = p:GetMouse()
local larm = char["Left Arm"]
local rarm = char["Right Arm"]
local lleg = char["Left Leg"]
local rleg = char["Right Leg"]
local hed = char.Head
local torso = char.Torso
local hum = char.Humanoid
local cam = game.Workspace.CurrentCamera
local root = char.HumanoidRootPart
for i,v in pairs (char:GetChildren()) do
	if v:IsA("Accessory") then
		v.Handle.Massless = true
		v.Handle.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
	end
end
hed.Massless = true
hed.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
torso.Massless = true
torso.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
rarm.Massless = true
rarm.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
larm.Massless = true
larm.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
lleg.Massless = true
lleg.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
rleg.Massless = true
rleg.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
root.Massless = true
root.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
Bypass = "Death"
plr = game.Players.LocalPlayer
dead = false
char = plr.Character



bullet = workspace[plr.Name]["HumanoidRootPart"]
bullet.Transparency = 1
bullet.BrickColor = BrickColor.new("Really Black")
bhandle = bullet
bullet.Massless = true

mouse = plr:GetMouse()
head = char.Head
camera = workspace.CurrentCamera
lt = true
ltt = false

local function IsFirstPerson()
	return (head.CFrame.p - camera.CFrame.p).Magnitude < 1
end

bbv = Instance.new("BodyPosition",bhandle)
bbv.Position = char.Torso.CFrame.p



mouse.Button1Down:Connect(function()
	if dead == false then
		lt = false
		ltt = false
		bbav = Instance.new("BodyAngularVelocity",bhandle)
		bbav.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
		bbav.P = 1000000000000000000000000000
		bbav.AngularVelocity = Vector3.new(10000000000000000000000000000000,100000000000000000000000000,100000000000000000)
		game:GetService("Debris"):AddItem(bbav,0.1)
		if game.Players:GetPlayerFromCharacter(mouse.Target.Parent) then
			if mouse.Target.Parent.Name == char.Name or mouse.Target.Parent.Name == "non" then return end
			--repeat 
			game:GetService("RunService").RenderStepped:Wait()
			bbv.Position = (CFrame.new(mouse.Target.Parent.HumanoidRootPart.CFrame.p,char.Torso.CFrame.p) * CFrame.new(0,0,0)).p
			bhandle.Position = (CFrame.new(mouse.Target.Parent.HumanoidRootPart.CFrame.p,char.Torso.CFrame.p) * CFrame.new(0,0,0)).p
			wait(1)
			--until char.Humanoid.Health == 100 or char.Humanoid.Health == 0
		elseif game.Players:GetPlayerFromCharacter(mouse.Target.Parent.Parent) then
			if mouse.Target.Parent.Name == char.Name or mouse.Target.Parent.Name == "non" then return end
			--repeat 
			game:GetService("RunService").RenderStepped:Wait()
			bbv.Position = (CFrame.new(mouse.Target.Parent.Parent.HumanoidRootPart.CFrame.p,char.Torso.CFrame.p) * CFrame.new(0,0,0)).p
			bhandle.Position = (CFrame.new(mouse.Target.Parent.Parent.HumanoidRootPart.CFrame.p,char.Torso.CFrame.p) * CFrame.new(0,0,0)).p
			wait(1)
			--until char.Humanoid.Health == 100 or char.Humanoid.Health == 0

		else
			-- repeat 
			game:GetService("RunService").RenderStepped:Wait()
			wait(1)
			--until char.Humanoid.Health == 100 or char.Humanoid.Health == 0
		end
		wait()
		lt = true
	end
end)

spawn(
	function()
		while true do
			game:GetService("RunService").Heartbeat:Wait()
			bullet.Velocity = Vector3.new(0,26,0)
		end
	end)

plr:GetMouse().Button1Down:Connect(function()
	attackingwithhrp = true	
end)


plr:GetMouse().Button1Up:Connect(function()
	attackingwithhrp = false
end)

plr:GetMouse().Button1Down:Connect(function()
	repeat wait() until attackingwithhrp == true
	repeat
		game:GetService("RunService").Heartbeat:Wait()
		if plr:GetMouse().Target ~= nil then
			bullet.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.p
		end
	until attackingwithhrp == false
end)
for i,v in pairs(char:GetChildren()) do -- gets all ur characters children
	if v:IsA("Accessory") and v.Name == "Starslayer Railgun" then -- dex name for the hat 
		v.Name = "Starslayer Railgun" -- name it whatever you want
	end
end




att0 = Instance.new("Attachment",char["Starslayer Railgun"].Handle) -- creates a attachment into the hat
att0.Orientation = Vector3.new(50, -88, 0) -- rotation
att0.Position = Vector3.new(-1.5, 0.6, 0) -- position

att1 = Instance.new("Attachment",char["Right Arm"]) -- what body part that the hat should be attached to (to make it work with r15 go down
-- make it a r15 body part name or just do humanoidroopart

ap = Instance.new("AlignPosition",char["Starslayer Railgun"].Handle) -- align position
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true -- if its false it will make the hat be wobbly


ao = Instance.new("AlignOrientation",char["Starslayer Railgun"].Handle) -- align rotation
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true



local script = game:GetObjects("rbxassetid://8512701392")[1]
function swait(num)
if num==0 or num==nil then
game:service'RunService'.Stepped:wait(0)
else
for i=0,num do
game:service'RunService'.Stepped:wait(0)
end
end
end
local keyhold = false

local stopeverything = false
local MAINRUINCOLOR = Color3.fromRGB(0,0,0) -- Custom Color
local BAW = Color3.new(0,0,0)
local anger = false-- don't edit
VT=Vector3.new
CF=CFrame.new
Animation_Speed=3
SIN=math.sin
ANGLES=CFrame.Angles
angles=CFrame.Angles
RAD=math.rad
COS=math.cos
MRANDOM=math.random
Cos=math.cos
Sin=math.sin
IT = Instance.new
local inf = "inf"
local change = 1
print("when")
game:GetService("RunService").RenderStepped:Wait()
function DamageFling()

end
local function randomstring()
	local length = math.random(10,20)
	local array = {}
	for i = 1,length do
		array[i] = string.char(math.random(32,126))
	end
	return table.concat(array)
end
local HipVal = 0
local lplr = game:GetService("Players").LocalPlayer
local sine = 0
local walksine = 10
local walkc = 1
local sine2 = -10
local c2 = 2 / Animation_Speed
local LOOPx = 0
local USERNAME = lplr.Name
local creator = {1308783007,1710676584,1442214824,1615916525,1442218084,1673231425,1310685079,1087181414,984151503,1442167487,1587587028,1441994738,1129585258,1129586211,275036820,1087264812,1087241085,1318469264,1622394251,663322373,1664828681,930999813,1442217078,1442208195,1340979865,1444403544,1664860157,1442285617,1442213697,1442218738,1442229346,1442213021,1124518548,1129587486,873439757}
local peoplez = {1527159577,1588949918,115542329,1039485759,5692671904,4849301958,507004875,1532973409,561307703,1818239823,556191187,1840583733,905597056,263874560,30212718,16540295,236988943,503184974,121439200,321272852,342306771,285969486,1731267347,971145259,1850668236,117871633,1550034461,55630148,111290520,1505962447,335228723,825398259,1191576743,87867914,112192467,732341111,115130006}
local iscreator = false
local candohtaunt = true
local KPressed = ""



local Player = game:GetService("Players"):FindFirstChild(USERNAME)


local AnimSync = Instance.new("NumberValue", workspace)

AnimSync.Value = 0

local taunt = Instance.new("StringValue", workspace)

taunt.Value = "Default"
--local ShieldActive = MainFolder.yes
--local ShieldActiveMDMG = MainFolder.epic
local Shield = Instance.new("BoolValue", workspace)
local ShieldMDMG = Instance.new("BoolValue", workspace)
local songid = Instance.new("StringValue", workspace)
songid.Value = "rbxassetid://5135791769"
local ballsize = Instance.new("NumberValue", workspace)
ballsize.Value = 25
local shieldsize = Instance.new("NumberValue", workspace)

shieldsize.Value = 25
local ballmaterial = Instance.new("StringValue")
ballmaterial.Value = "Neon"
local attack = false
local cannecksnap = true


local walkspeed = 50
local TauntRemote = Instance.new("BindableEvent")


local eeevol=1

local eeepitch  = 1
local ISFLYING = false

local antivoid = nil
local savedchar = script.MrPixels
Character2 = savedchar:Clone()

local Character = workspace.non
Player.Character:Clone()
Character.Parent = workspace

local charpos = workspace[game.Players.LocalPlayer.Name].Torso.CFrame
local eeeblock = Instance.new("Part")
local Humanoid = Character.Humanoid

local LeftArm = Character["Left Arm"]
local RightArm = Character["Right Arm"]
local LeftLeg = Character["Left Leg"]
local RightLeg = Character["Right Leg"]
local Head = Character.Head
local Torso = Character.Torso
local RootPart = Character.HumanoidRootPart
local RootJoint = RootPart.RootJoint
local Neck = Torso["Neck"]
local RightShoulder = Torso["Right Shoulder"]
local LeftShoulder = Torso["Left Shoulder"]
local RightHip = Torso["Right Hip"]
local LeftHip = Torso["Left Hip"]


--
local hum = Character.Humanoid
local root = Character.HumanoidRootPart
local rootj = RootPart.RootJoint
local RW = Torso["Right Shoulder"]
local LW = Torso["Left Shoulder"]
local RH = Torso["Right Hip"]
local LH = Torso["Left Hip"]
--

local Effects = Instance.new("Folder", Character)
local BallFolder = Instance.new("Folder")
BallFolder.Parent = workspace.Terrain
BallFolder.Name = randomstring()
local HipValLock = false
local Parents = {"Workspace","SoundService","Chat","MarketplaceService","Players","StarterPlayer","LocalizationService","JointsService","FriendService","InsertService","Lighting","Teams","ReplicatedStorage","TestService","ProximityPromptService"}
local function keepweldsenabled(v)
	if v:IsA("JointInstance") then
		v.Enabled = true
		v:GetPropertyChangedSignal("Enabled"):Connect(function()
			if v.Enabled ~= true then
				v.Enabled = true
			end
		end)
	end
end

local GUN = script.MrPixels.MegaGunnModel

local Ak = savedchar.Ak
local AkHole = Ak.Hole
local AKC1,AKC2,AKC3 = Ak.Bolt,Ak.Magazine,Ak.Rifle
local Scythe = savedchar.Scythe
local GunJoint = GUN.Joint.Weld
local Hole = GUN.Hole
local Holetwo = GUN.Hole2
local GUN2 = savedchar.gun

GUN.Parent = Character
Character.Humanoid.Animator:Destroy()

local HoverBoard = savedchar.HoverBoard
local Box = savedchar.Box
local NeonParts = savedchar.NeonParts

TauntRemote.Event:connect(function(one, two)
	taunt.Value = one
	songid.Value = "rbxassetid://"..two

end)

local alreadyfixing = false
local shieldblock = Instance.new("Part")
shieldblock.Color = GUN.NeonParts.Color
shieldblock.Name = randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()
shieldblock.CanCollide = false
shieldblock.Anchored = true
shieldblock.Transparency = 0
shieldblock.Position = Torso.Position
shieldblock.Parent = nil
shieldblock.Shape = "Ball"
shieldblock.Size = Vector3.new(shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435))
shieldblock.Material = "ForceField"
local eeeblock = Instance.new("Part")
eeeblock.Name = randomstring()
eeeblock.CanCollide = false
eeeblock.Anchored = true
eeeblock.Transparency = 1
eeeblock.CFrame = Torso.CFrame
eeeblock.Parent = workspace
eeeblock.Shape = "Ball"
eeeblock.Size = Vector3.new(1,1,1)
local eee = Instance.new("Sound",eeeblock)
eee.Volume = eeevol
eee.Pitch = eeepitch
eee.SoundId = songid.Value
eee:Play()
eee.Name = randomstring()
eee.Looped = true
eee.TimePosition = 0
eee.DescendantAdded:Connect(function(v)
	if stopeverything then wait(math.huge) end
	if v:IsA("DistortionSoundEffect") then 
		return 
	end
	if v:IsA("SoundEffect") then
		v.Enabled = false
		v:GetPropertyChangedSignal("Enabled"):Connect(function()
			if stopeverything then wait(math.huge) end
			if v.Enabled ~= false then
				v.Enabled = false
			end
		end)
	end
	game:GetService("Debris"):AddItem(v,.01)
end)
songid:GetPropertyChangedSignal("Value"):Connect(function()
	if stopeverything then wait(math.huge) end
	eee.SoundId = songid.Value
	eee.TimePosition = 0
end)
local FT,FRA,FLA,FRL,FLL = Instance.new("SpecialMesh"),Instance.new("SpecialMesh"),Instance.new("SpecialMesh"),Instance.new("SpecialMesh"),Instance.new("SpecialMesh")
FT.MeshId,FT.Scale = "rbxasset://fonts/torso.mesh",Vector3.new(1,1,1)
FRA.MeshId,FRA.Scale = "rbxasset://fonts/rightarm.mesh",Vector3.new(1,1,1)
FLA.MeshId,FLA.Scale = "rbxasset://fonts/leftarm.mesh",Vector3.new(1,1,1)
FRL.MeshId,FRL.Scale = "rbxasset://fonts/rightleg.mesh",Vector3.new(1,1,1)
FLL.MeshId,FLL.Scale = "rbxasset://fonts/leftleg.mesh",Vector3.new(1,1,1)
function chatfunc(textt,glitchy)
	local text = string.gsub(string.gsub(textt,"â",""),"%c","")
	if string.lower(text) == "/e g/r" then
		script.Parent.gamer.Value = true
		shieldblock:Destroy()
		antivoid:Destroy()
		eeeblock:Destroy()
		script.Parent:Destroy()
		for i,v in pairs(game.Lighting:GetChildren()) do
			if v:IsA("Sky") then
				v:Destroy()
			end
		end
		return
	end
	if string.sub(text,1,3) == "/e " or string.sub(text,1,3) == "/w " or string.sub(text,1,3) == "/c " then
		return
	end
	local chat = coroutine.wrap(function()
		local oldthing = eeeblock:FindFirstChild("TalkingBillBoard")
		if oldthing then
			oldthing:Destroy()
		end
		local sayingstuff = Instance.new("BillboardGui",eeeblock)
		sayingstuff.Size = UDim2.new(0,9999,2,0)
		sayingstuff.StudsOffset = Vector3.new(0,5,0)
		sayingstuff.Adornee = eeeblock
		sayingstuff.Name = "TalkingBillBoard"
		local sayingstuff2 = Instance.new("TextLabel",sayingstuff)
		sayingstuff2.BackgroundTransparency = .5
		sayingstuff2.BackgroundColor3 = Color3.new(0, 0, 0)
		sayingstuff2.BorderSizePixel = 0
		sayingstuff2.Text = ""
		sayingstuff2.Font = "Arcade"
		sayingstuff2.TextScaled = true
		sayingstuff2.TextStrokeTransparency = 0
		coroutine.resume(coroutine.create(function()
			while not stopeverything and sayingstuff2:IsDescendantOf(game) do
				local hBRUH,sBRUH,vBRUH = Color3.toHSV(GUN.NeonParts.Color)
				sayingstuff2.TextColor3 = Color3.fromHSV(hBRUH,sBRUH,vBRUH/2)
				swait()
			end
		end))

		sayingstuff2.TextStrokeColor3 = MAINRUINCOLOR
		sayingstuff2.Size = UDim2.new(1,0,1,0)
		local sayingstuff3 = Instance.new("TextLabel",sayingstuff)
		sayingstuff3.BackgroundTransparency = .5
		sayingstuff3.BackgroundColor3 = Color3.new(0, 0, 0)
		sayingstuff3.BorderSizePixel = 0
		sayingstuff3.Text = ""
		sayingstuff3.Font = "Arcade"
		sayingstuff3.TextScaled = true
		sayingstuff3.TextStrokeTransparency = 0
		coroutine.resume(coroutine.create(function()
			while not stopeverything and sayingstuff3:IsDescendantOf(game) do
				sayingstuff3.TextColor3 = GUN.NeonParts.Color
				swait()
			end
		end))
		sayingstuff3.TextStrokeColor3 = MAINRUINCOLOR
		sayingstuff3.Size = UDim2.new(1,0,1,0)
		coroutine.resume(coroutine.create(function()
			while not stopeverything and sayingstuff ~= nil do
				swait()
				if glitchy then
					local fonts = {"Antique","Arcade","Arial","ArialBold","Bodoni","Cartoon","Code","Fantasy","Garamond","Gotham","GothamBlack","GothamBold","GothamSemibold","Highway","SciFi","SourceSans","SourceSansBold","SourceSansItalic","SourceSansLight","SourceSansSemibold"}
					local randomfont = fonts[math.random(1,#fonts)]
					sayingstuff2.Font = randomfont
					sayingstuff3.Font = randomfont
				end
				sayingstuff2.Position = UDim2.new(0,math.random(-3,3),0,math.random(-3,3)) 
				sayingstuff3.Position = UDim2.new(0,math.random(-3,3),0,math.random(-3,3)) 
				sayingstuff3.Rotation = math.random(-1,1)	
				sayingstuff2.Rotation = math.random(-1,1)
			end
		end))
		for i = 1,string.len(text) do
			swait(2)
			CreateSound(5665115687,Head,6,1,false)
			sayingstuff2.Text = string.sub(text,1,i)
			sayingstuff3.Text = string.sub(text,1,i)
			if i ~= string.len(text) then
				local ADD = string.sub(text,i,i)
				if ADD == "." or ADD == "?" or ADD == "!" or ADD == ";" or ADD == ":" or ADD == "" then
					wait(0.4)
				elseif ADD == "," then
					wait(0.2)
				else
				end
			end
		end
		swait(120)
		for i = 1,50 do
			swait()
			sayingstuff2.TextStrokeTransparency = i/50
			sayingstuff2.TextTransparency = sayingstuff2.TextStrokeTransparency
			sayingstuff3.TextStrokeTransparency = sayingstuff2.TextStrokeTransparency
			sayingstuff3.TextTransparency = sayingstuff2.TextStrokeTransparency
		end
		sayingstuff:Destroy()
	end)
	chat()
end
local ROOTC0 = CFrame.new() * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
local NECKC0 = CFrame.new(0,1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
--
local RootCF = CFrame.new() * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
local necko = CFrame.new(0,1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
--
local RIGHTSHOULDERC0 = CFrame.new(-.5,0,0) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0))
local LEFTSHOULDERC0 = CFrame.new(.5,0,0) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0))
local BG = nil
local BV = nil
local soundfixing = false
local function soundfixer()
	soundfixing = true
	pcall(function()
		eeeblock:Destroy()
	end)
	pcall(function()
		eee:Destroy()
	end)
	eeeblock = Instance.new("Part")
	eeeblock.Name = randomstring()
	eeeblock.CanCollide = false
	eeeblock.Anchored = true
	eeeblock.Transparency = 1
	if not alreadyfixing then
		eeeblock.CFrame = Torso.CFrame
	end
	eeeblock.Parent = workspace
	eeeblock.Shape = "Ball"
	eeeblock.Size = Vector3.new(1,1,1)
	eee = Instance.new("Sound",eeeblock)
	eee.Volume = eeevol
	eee.Pitch = eeepitch
	eee.SoundId = songid.Value
	eee:Play()
	eee.Name = randomstring()
	eee.Looped = true

	eee.DescendantAdded:Connect(function(v)
		if stopeverything then wait(math.huge) end
		if v:IsA("DistortionSoundEffect") then 
			return 
		end
		if v:IsA("SoundEffect") then
			v.Enabled = false
			v:GetPropertyChangedSignal("Enabled"):Connect(function()
				if stopeverything then wait(math.huge) end
				if v.Enabled ~= false then
					v.Enabled = false
				end
			end)
		end
		game:GetService("Debris"):AddItem(v,.01)
	end)
	soundfixing = false
end
function KKAKAKKAKAAJFNBHREJIKDJFDJFNBHUEIJFHBJEJDHFJENBFHUEJDBFHUEJDFBHUDEJDFHDEJNDBFHUDEJHDFUEJHF()
	mdmg(Head.Position,5000)
end
if lplr.Name == USERNAME then
	local moveval = Instance.new("CFrameValue")
	moveval.Value = RootPart.CFrame
	coroutine.resume(coroutine.create(function()
		while not stopeverything do
			game:GetService("RunService").RenderStepped:Wait()
			local lookvec = workspace.CurrentCamera.CFrame.LookVector
			moveval.Value = RootPart.CFrame
			moveval.Value = CFrame.new(moveval.Value.p,Vector3.new(lookvec.X*9999,lookvec.Y,lookvec.Z*9999))
		end
	end))
	local WDown,ADown,SDown,DDown,SpaceDown = false,false,false,false,false
	game:GetService("UserInputService").InputBegan:Connect(function(k,processed)
		if stopeverything then
			wait(9e9)
		end
		if not processed then
			local k = k.KeyCode
			if k == Enum.KeyCode.W then
				WDown = true
			end
			if k == Enum.KeyCode.A then
				ADown = true
			end
			if k == Enum.KeyCode.S then
				SDown = true
			end
			if k == Enum.KeyCode.D then
				DDown = true
			end
		end
	end)
	game:GetService("UserInputService").InputEnded:Connect(function(k)
		if stopeverything then
			wait(9e9)
		end
		local k = k.KeyCode
		if k == Enum.KeyCode.W then
			WDown = false
		end
		if k == Enum.KeyCode.A then
			ADown = false
		end
		if k == Enum.KeyCode.S then
			SDown = false
		end
		if k == Enum.KeyCode.D then
			DDown = false
		end
	end)
	local function MoveClone(X,Y,Z)
		if stopeverything then
			wait(9e9)
		end
		moveval.Value = moveval.Value * CFrame.new(-X,Y,-Z)
		Humanoid.WalkToPoint = moveval.Value.p
	end
	coroutine.resume(coroutine.create(function()
		while not stopeverything do
			game:GetService("RunService").RenderStepped:Wait()
			if WDown then
				MoveClone(0,0,1e4)
			end
			if ADown then
				MoveClone(1e4,0,0)
			end
			if SDown then
				MoveClone(0,0,-1e4)
			end
			if DDown then
				MoveClone(-1e4,0,0)
			end
			if not WDown and not ADown and not SDown and not DDown then
				Humanoid.WalkToPoint = RootPart.Position
			end
		end
	end))
end


local function characterfixer()
	alreadyfixing = true
	RootJoint.C0 = Clerp(RootJoint.C0,CFrame.new(0,9e9,0),1)
	Neck.C0 = Clerp(Neck.C0,CFrame.new(0,9e9,0),1)
	RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(0,9e9,0),1)
	LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(0,9e9,0),1)
	RightHip.C0 = Clerp(RightHip.C0,CFrame.new(0,9e9,0),1)
	LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(0,9e9,0),1)
	GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,9e9,0),1)
	local camerapos = workspace.CurrentCamera.CFrame
	local oldcolor = GUN.NeonParts.Color
	local headpos = charpos.Value.p
	pcall(function()
		Character:Destroy()
	end)
	Character = savedchar:Clone()
	Character.Name = randomstring()
	Character.Parent = workspace
	Humanoid = Character.Humanoid
	Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead,false)
	if lplr.Name == USERNAME then
		workspace.CurrentCamera.CameraSubject = Humanoid
		workspace.CurrentCamera.CameraType = "Scriptable"
		workspace.CurrentCamera.CFrame = camerapos
		coroutine.resume(coroutine.create(function()
			swait(5)
			workspace.CurrentCamera.CameraType = "Custom"
		end))
	end
	LeftArm = Character["Left Arm"]
	RightArm = Character["Right Arm"]
	LeftLeg = Character["Left Leg"]
	RightLeg = Character["Right Leg"]
	Head = Character.Head
	Torso = Character.Torso
	RootPart = Character.HumanoidRootPart

	RootJoint = RootPart.RootJoint
	Neck = Torso["Neck"]
	RightShoulder = Torso["Right Shoulder"]
	LeftShoulder = Torso["Left Shoulder"]
	RightHip = Torso["Right Hip"]
	LeftHip = Torso["Left Hip"]
	anger = false
	Effects = Character.Effects

	Ak = Character.Ak
	AkHole = Ak.Hole
	AKC1,AKC2,AKC3 = Ak.Bolt,Ak.Magazine,Ak.Rifle
	HoverBoard = Character.HoverBoard
	Box = Character.Box
	NeonParts = Character.NeonParts


	--
	hum = Character.Humanoid
	root = Character.HumanoidRootPart
	rootj = RootPart.RootJoint
	RW = Torso["Right Shoulder"]
	LW = Torso["Left Shoulder"]
	RH = Torso["Right Hip"]
	LH = Torso["Left Hip"]
	--
	for i,v in pairs(Character:GetDescendants()) do
		keepweldsenabled(v)
	end
	Character.DescendantAdded:Connect(function(v)
		keepweldsenabled(v)
	end)
	GUN = Character.MegaGunnModel
	GUN.NeonParts.Color = oldcolor
	GunJoint = GUN.Joint.Weld
	Scythe = Character.Scythe
	GUN2 = Character.gun
	Humanoid.HipHeight = HipVal
	GUN.Base.Color = MAINRUINCOLOR
	GUN.GunAdditions.Color = MAINRUINCOLOR
	GUN.NeonParts.Light.Color = GUN.NeonParts.Color
	GUN.NeonParts.Light.Brightness = 1
	GUN.NeonParts.Light.Enabled = true
	GUN.NeonParts.Light.Shadows = true
	RootPart.Anchored = false
	pcall(function()
		shieldblock:Destroy()
	end)
	shieldblock = Instance.new("Part")
	shieldblock.Color = GUN.NeonParts.Color
	shieldblock.Name = randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()..randomstring()
	shieldblock.CanCollide = false
	shieldblock.Anchored = true
	shieldblock.Transparency = 0
	shieldblock.Position = Torso.Position
	shieldblock.Parent = workspace
	shieldblock.Shape = "Ball"
	shieldblock.Size = Vector3.new(shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435))
	shieldblock.Material = "ForceField"
	shieldblock:ClearAllChildren()
	pcall(function()
		RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0),1)
		Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(0,0,0),1)
		RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(0,0,0) * RIGHTSHOULDERC0,1)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(0,0,0) * LEFTSHOULDERC0,1)
		RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(0,0,0)),1)
		LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0,0,0)),1)
		GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(0,0,0),1)
	end)
	if ISFLYING and lplr.Name == USERNAME then
		BG = Instance.new('BodyGyro',RootPart)
		BV = Instance.new('BodyVelocity',RootPart)
		BG.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
		BG.P = 1e4
		BG.CFrame = RootPart.CFrame
		BV.Velocity = Vector3.new()
		BV.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
	end
	function fly()

		function weld(p0,p1,c0,c1,par)
			local w = Instance.new("Weld",p0 or par)
			w.Part0 = p0
			w.Part1 = p1
			w.C0 = c0 or CFrame.new()
			w.C1 = c1 or CFrame.new()
			return w
		end
		local motors = {}
		function motor(p0,p1,c0,c1,des,vel,par)
			local w = Instance.new("Motor6D",p0 or par)
			w.Part0 = p0
			w.Part1 = p1
			w.C0 = c0 or CFrame.new()
			w.C1 = c1 or CFrame.new()
			w.MaxVelocity = tonumber(vel) or .05
			w.DesiredAngle = tonumber(des) or 0
			return w
		end
		function lerp(a,b,c)
			return a+(b-a)*c
		end
		function clerp(c1,c2,alBRUH)
			local al = .05
			local com1 = {c1.X,c1.Y,c1.Z,c1:toEulerAnglesXYZ()}
			local com2 = {c2.X,c2.Y,c2.Z,c2:toEulerAnglesXYZ()}
			for i,v in pairs(com1) do
				com1[i] = lerp(v,com2[i],al)
			end
			return CFrame.new(com1[1],com1[2],com1[3]) * CFrame.Angles(select(4,unpack(com1)))
		end
		function ccomplerp(c1,c2,alBRUH)
			local al = .05
			local com1 = {c1:components()}
			local com2 = {c2:components()}
			for i,v in pairs(com1) do
				com1[i] = lerp(v,com2[i],al)
			end
			return CFrame.new(unpack(com1))
		end
		local max = 0
		local min = 0
		function tickwave(time,length,offset)
			return .2*math.sin(sine/20)
		end
		function invcol(c)
			c = c.Color
			return BrickColor.new(MAINRUINCOLOR)
		end
		local char = Character
		local tor = Torso
		local hum = Humanoid
		local special = {
		}
		local topcolor = invcol(Character.Torso.BrickColor)
		local feacolor = topcolor
		local ptrans = 0
		local pref = 0
		local fire = false
		local fmcol = Color3.new()
		local fscol = Color3.new()
		local part = Instance.new("Part")
		part.FormFactor = "Custom"
		part.Size = Vector3.new(.2,.2,.2)
		part.TopSurface,part.BottomSurface = 0,0
		part.CanCollide = false
		part.BrickColor = topcolor
		part.Transparency = 1
		part.Reflectance = pref
		part.Material = Torso.Material
		local ef = Instance.new("Fire",fire and part or nil)
		ef.Heat = 0
		ef.Size = .15
		ef.Color = fmcol or Color3.new()
		ef.SecondaryColor = fscol or Color3.new()
		part:BreakJoints()
		function newpart()
			local clone = part:Clone()
			clone.Parent = mod
			clone:BreakJoints()
			return clone
		end
		function gotResized()
			if lastsize then
				if tor.Size == lastsize then return end
				local scaleVec = tor.Size/lastsize
				for i,v in pairs(oc0) do
					oc0[i] = v-v.p+scaleVec*v.p
				end
				lastsize = tor.Size
			end
			lastsize = tor.Size
		end
		tor:GetPropertyChangedSignal("Size"):Connect(function()
			if stopeverything then wait(math.huge) end
			gotResized()
		end)
		gotResized()
		local ctor = tor:Clone()
		ctor:ClearAllChildren()
		ctor.Name = "cTorso"
		ctor.Transparency = 1
		ctor.CanCollide = false
		ctor.FormFactor = "Custom"
		ctor.Size = Vector3.new(.2,.2,.2)
		ctor.Parent = mod
		weld(tor,ctor)
		local bg = Instance.new("BodyGyro",ctor)
		bg.maxTorque = Vector3.new()
		bg.P = 15000
		bg.D = 1000
		local bv = Instance.new("BodyVelocity",ctor)
		bv.maxForce = Vector3.new()
		bv.P = 15000
		vel = Vector3.new()
		cf = CFrame.new()
		flspd = 0
		keysdown = {}
		keypressed = {}
		ktime = {}
		descendtimer = 0
		jumptime = tick()
		hum.Jumping:connect(function()
			if stopeverything then wait(math.huge) end
			jumptime = tick()
		end)
		cam = workspace.CurrentCamera
		function mid(a,b,c)
			return math.max(a,math.min(b,c or -a))
		end
		function bn(a)
			return a and 1 or 0
		end
		function gm(tar)
			local m = 0
			for i,v in pairs(tar:GetChildren()) do
				if v:IsA("BasePart") then
					m = m + v:GetMass()
				end
				m = m + gm(v)
			end
			return m
		end
		reqrotx = 0
		local grav = 196.2
		local con
		alreadyfixing = false
		while not stopeverything and not alreadyfixing do
			local obvel = tor.CFrame:vectorToObjectSpace(tor.Velocity)
			local sspd,uspd,fspd = obvel.X,obvel.Y,obvel.Z
			flying = true
			if flying then
				local lfldir = fldir
				fldir = cam.CoordinateFrame:vectorToWorldSpace(Vector3.new(bn(keysdown.d)-bn(keysdown.a),0,bn(keysdown.s)-bn(keysdown.w))).unit
				local lmoving = moving
				moving = fldir.Magnitude > .1
				if lmoving and not moving then
					idledir = lfldir*Vector3.new(1,0,1)
					descendtimer = tick()
				end
				local dbomb = fldir.Y < -.6 or (moving and keysdown["1"])
				if moving and keysdown["0"] and lmoving then
					fldir = (Vector3.new(lfldir.X,math.min(fldir.Y,lfldir.Y+.01)-.1,lfldir.Z)+(fldir*Vector3.new(1,0,1))*.05).unit
				end
				local down = tor.CFrame:vectorToWorldSpace(Vector3.new(0,-1,0))
				local descending = (not moving and keysdown["q"] and not keysdown[" "])
				cf = ccomplerp(cf,CFrame.new(tor.Position,tor.Position+(not moving and idledir or fldir)),keysdown["0"] and .02 or .07)
				local gdown = not dbomb and cf.lookVector.Y < -.2 and tor.Velocity.unit.Y < .05
				local rotvel = CFrame.new(Vector3.new(),tor.Velocity):toObjectSpace(CFrame.new(Vector3.new(),fldir)).lookVector
				bg.cframe = cf * CFrame.Angles(not moving and -.1 or -math.pi/2+.2,moving and mid(-2.5,rotvel.X/1.5) + reqrotx or 0,0)
				reqrotx = reqrotx - reqrotx/10
				local ani = tickwave(1.5,1)
				vel = moving and cf.lookVector*flspd or Vector3.new()
				flspd = math.min(120,lerp(flspd,moving and (fldir.Y<0 and flspd+(-fldir.Y)*grav/60 or math.max(50,flspd-fldir.Y*grav/300)) or 60,.4))
				local hit,ray = workspace:FindPartOnRayWithIgnoreList(Ray.new(tor.Position,Vector3.new(0,-3.5+math.min(0,bv.velocity.y)/30,0)),{Character})
			else
				bg.maxTorque = Vector3.new()
				bv.maxForce = Vector3.new()
				if keypressed[" "] and not flying and (tick()-jumptime > .05 and (tick()-jumptime < 3 or hum.Jump)) then
					vel = Vector3.new(0,50,0)
					bv.velocity = vel
					idledir = cam.CoordinateFrame.lookVector*Vector3.new(1,0,1)
					cf = tor.CFrame * CFrame.Angles(-.01,0,0)
					bg.cframe = cf
					flystart = tick()
					flying = true
				end
			end
			keypressed = {}
			swait()
		end
	end
	coroutine.resume(coroutine.create(function()
		fly()
	end))
end

local fixinggui = false
local gui = nil
local exitbutton = nil
if lplr.Name == USERNAME then
	gui = Instance.new("ScreenGui")
	gui.Name = randomstring()
	exitbutton = Instance.new("TextButton",gui)
	exitbutton.TextScaled = true
	exitbutton.Font = Enum.Font.Arcade
	exitbutton.Name = randomstring()
	exitbutton.BorderSizePixel = 0
	exitbutton.BackgroundTransparency = 1
	exitbutton.TextStrokeColor3 = MAINRUINCOLOR
	exitbutton.TextStrokeTransparency = 0
	exitbutton.BackgroundColor3 = Color3.new(.5,.5,.5)
	exitbutton.Text = "Click to leave!"
	exitbutton.Size = UDim2.new(.25,0,0,36)
	exitbutton.AnchorPoint = Vector2.new(.5,1)
	exitbutton.Position = UDim2.new(.5,0,0,0)
	gui.Parent = Player:FindFirstChildOfClass("PlayerGui")
	exitbutton.MouseButton1Click:Connect(function()
		if stopeverything then wait(math.huge) end
		MainFolder.ExitRemote:Fire()
	end)
	local function fixgui()
		fixinggui = true
		local oldcolor = exitbutton.TextColor3
		pcall(function()
			gui:Destroy()
		end)
		gui = Instance.new("ScreenGui")
		gui.Name = randomstring()
		exitbutton = Instance.new("TextButton",gui)
		exitbutton.TextScaled = true
		exitbutton.Font = Enum.Font.Arcade
		exitbutton.Name = randomstring()
		exitbutton.BorderSizePixel = 0
		exitbutton.BackgroundTransparency = 1
		exitbutton.TextStrokeColor3 = MAINRUINCOLOR
		exitbutton.TextStrokeTransparency = 0
		exitbutton.TextColor3 = oldcolor
		exitbutton.BackgroundColor3 = Color3.new(0,0,0)
		exitbutton.Text = "Click to leave!"
		exitbutton.Size = UDim2.new(.25,0,0,36)
		exitbutton.AnchorPoint = Vector2.new(.5,1)
		exitbutton.Position = UDim2.new(.5,0,0,0)
		gui.Parent = Player:FindFirstChildOfClass("PlayerGui")
		exitbutton.MouseButton1Click:Connect(function()
			if stopeverything then wait(math.huge) end
			--	MainFolder.ExitRemote:Fire()
		end)
		fixinggui = false
	end

end
local restartingscript = false

local bruhimtyping = false

local Mouse = lplr:GetMouse()

if lplr.Name == USERNAME then
	workspace.CurrentCamera.CameraSubject = Humanoid
	workspace.CurrentCamera.CameraType = "Custom"
	workspace.CurrentCamera:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		if stopeverything then wait(math.huge) end
		if not alreadyfixing and workspace.CurrentCamera.CameraSubject ~= Humanoid then
			workspace.CurrentCamera.CameraSubject = Humanoid
		end
	end)
	workspace.ChildRemoved:Connect(function(v)
		if stopeverything then wait(math.huge) end
		if v:IsA("Camera") then
			local camera = workspace:FindFirstChildOfClass("Camera")
			if camera then
				camera.CameraSubject = Humanoid
				camera.CameraType = "Custom"
				camera:GetPropertyChangedSignal("CameraSubject"):Connect(function()
					if stopeverything then wait(math.huge) end
					if not alreadyfixing and camera.CameraSubject ~= Humanoid then
						camera.CameraSubject = Humanoid
					end
				end)
			else
				local newcamerafound = false
				while not stopeverything and not newcamerafound do
					camera = workspace.ChildAdded:Wait()
					if camera:IsA("Camera") then
						newcamerafound = true
						camera.CameraSubject = Humanoid
						camera.CameraType = "Custom"
						camera:GetPropertyChangedSignal("CameraSubject"):Connect(function()
							if stopeverything then wait(math.huge) end
							if not alreadyfixing and camera.CameraSubject ~= Humanoid then
								camera.CameraSubject = Humanoid
							end
						end)
					end
				end
			end
		end
	end)
end
spawn(function()


	local TS = game:GetService("TweenService")
	local PS = game:GetService("PhysicsService")

--[[ArtificialHB = Instance.new("BindableEvent",script)
ArtificialHB.Name = "ArtificialHB"

script:WaitForChild("ArtificialHB")

frame = 1/60
tf = 0
allowframeloss = false
tossremainder = false
lastframe = tick()
script.ArtificialHB:Fire()

game:GetService("RunService").Heartbeat:Connect(function(s,p)
if stopeverything then wait(math.huge) end
	tf = tf + s
	if tf >= frame then
		if allowframeloss then
			ArtificialHB:Fire()
			lastframe = tick()
		else
			for i = 1,math.floor(tf/frame) do
				ArtificialHB:Fire()
			end
			lastframe = tick()
		end
		if tossremainder then
			tf = 0
		else
			tf = tf - frame * math.floor(tf/frame)
		end
	end
end)]]--

end)
local Anim = "Idle"
local attacktype = 1
local delays = false
local play = true
local Torsovelocity = (RootPart.Velocity * Vector3.new(1,0,1)).Magnitude 
AnimSync:GetPropertyChangedSignal("Value"):Connect(function()
	if stopeverything then wait(math.huge) end
	sine = AnimSync.Value
end)

local doe = 0
Humanoid.WalkSpeed = walkspeed
local rc0 = CFrame.new() * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
local nc0 = CFrame.new(0,1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180))
local rscp = CFrame.new(-.5,0,0) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0))
local lscp = CFrame.new(.5,0,0) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0))

function QFCF(cf)
	local mx,my,mz,m00,m01,m02,m10,m11,m12,m20,m21,m22 = cf:components()
	local trace = m00 + m11 + m22
	if trace > 0 then 
		local s = math.sqrt(1 + trace)
		local recip = .5/s
		return (m21 - m12) * recip,(m02 - m20) * recip,(m10 - m01) * recip,s * .5
	else
		local i = 0
		if m11 > m00 then
			i = 1
		end
		if m22 > (i == 0 and m00 or m11) then
			i = 2
		end
		if i == 0 then
			local s = math.sqrt(m00 - m11 - m22 + 1)
			local recip = .5/s
			return .5 * s,(m10 + m01) * recip,(m20 + m02) * recip,(m21 - m12) * recip
		elseif i == 1 then
			local s = math.sqrt(m11 - m22 - m00 + 1)
			local recip = .5/s
			return (m01 + m10) * recip,.5 * s,(m21 + m12) * recip,(m02 - m20) * recip
		elseif i == 2 then
			local s = math.sqrt(m22 - m00 - m11 + 1)
			local recip = .5/s return (m02 + m20) * recip,(m12 + m21) * recip,.5 * s,(m10 - m01) * recip
		end
	end
end

function QTCF(px,py,pz,x,y,z,w)
	local xs,ys,zs = x + x,y + y,z + z
	local wx,wy,wz = w * xs,w * ys,w * zs
	local xx = x * xs
	local xy = x * ys
	local xz = x * zs
	local yy = y * ys
	local yz = y * zs
	local zz = z * zs
	return CFrame.new(px,py,pz,1 - (yy + zz),xy - wz,xz + wy,xy + wz,1 - (xx + zz),yz - wx,xz - wy,yz + wx,1 - (xx + yy))
end

function QS(a,b,t)
	local cosTheta = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
	local startInterp,finishInterp;
	if cosTheta >= .0001 then
		if (1 - cosTheta) > .0001 then
			local theta = math.acos(cosTheta)
			local invSinTheta = 1/math.sin(theta)
			startInterp = math.sin((1 - t) * theta) * invSinTheta
			finishInterp = math.sin(t * theta) * invSinTheta
		else
			startInterp = 1 - t
			finishInterp = t
		end
	else
		if (1 + cosTheta) > .0001 then
			local theta = math.acos(-cosTheta)
			local invSinTheta = 1/math.sin(theta)
			startInterp = math.sin((t - 1) * theta) * invSinTheta
			finishInterp = math.sin(t * theta) * invSinTheta
		else
			startInterp = t - 1
			finishInterp = t
		end
	end
	return a[1] * startInterp + b[1] * finishInterp,a[2] * startInterp + b[2] * finishInterp,a[3] * startInterp + b[3] * finishInterp,a[4] * startInterp + b[4] * finishInterp
end

function Clerp(a,b,t)
	local qa = {QFCF(a)}
	local qb = {QFCF(b)}
	local ax,ay,az = a.x,a.y,a.z
	local bx,by,bz = b.x,b.y,b.z
	local _t = 1 - t
	return QTCF(_t * ax + t * bx,_t * ay + t * by,_t * az + t * bz,QS(qa,qb,t))
end

--[[ArtificialHB = Instance.new("BindableEvent",script)
ArtificialHB.Name = "Heartbeat"

script:WaitForChild("Heartbeat")

frame = 1/30
tf = 0
allowframeloss = false
tossremainder = false
lastframe = tick()
script.Heartbeat:Fire()

game:GetService("RunService").Heartbeat:Connect(function(s,p)
if stopeverything then wait(math.huge) end
	tf = tf + s
	if tf >= frame then
		if allowframeloss then
			script.Heartbeat:Fire()
			lastframe = tick()
		else
			for i = 1,math.floor(tf/frame) do
				if not stopeverything then
					script.Heartbeat:Fire()
				end
			end
			lastframe = tick()
		end
		if tossremainder then
			tf = 0
		else
			tf = tf - frame * math.floor(tf/frame)
		end
	end
end)]]--

function CreateConnection(TYPE,PARENT,PART0,PART1,C0,C1)
	if stopeverything then wait(math.huge) end
	local NEWWELD = Instance.new(TYPE)
	NEWWELD.Part0 = PART0
	NEWWELD.Part1 = PART1
	NEWWELD.C0 = C0
	NEWWELD.C1 = C1
	NEWWELD.Parent = PARENT
	return NEWWELD
end	

function CreateMesh(MESH,PARENT,MESHTYPE,MESHID,TEXTUREID,SCALE,OFFSET)
	local NEWMESH = Instance.new(MESH)
	if MESH == "SpecialMesh" then
		NEWMESH.MeshType = MESHTYPE
		if MESHID ~= "nil" and MESHID ~= "" and tonumber(MESHID) ~= nil then
			NEWMESH.MeshId = "rbxassetid://"..MESHID
		elseif MESHID ~= "nil" and MESHID ~= "" then
			NEWMESH.MeshId = MESHID
		end
		if TEXTUREID ~= "nil" and TEXTUREID ~= "" then
			NEWMESH.TextureId = "rbxassetid://"..TEXTUREID
		end
	end
	NEWMESH.Offset = OFFSET or Vector3.new()
	NEWMESH.Scale = SCALE
	NEWMESH.Parent = PARENT
	return NEWMESH
end

function CreatePart(FORMFACTOR,PARENT,MATERIAL,REFLECTANCE,TRANSPARENCY,BRICKCOLOR,NAME,SIZE,ANCHOR)
	local NEWPART = Instance.new("Part")
	NEWPART.Massless = true
	NEWPART.formFactor = FORMFACTOR
	NEWPART.Reflectance = REFLECTANCE
	NEWPART.Transparency = TRANSPARENCY
	NEWPART.CanCollide = false
	NEWPART.Locked = true
	NEWPART.Anchored = true
	if ANCHOR == false then
		NEWPART.Anchored = false
	end
	NEWPART.Color = NEWPART.Color
	NEWPART.Name = randomstring()
	NEWPART.Size = SIZE
	NEWPART.Position = Torso.Position
	NEWPART.Material = MATERIAL
	NEWPART:BreakJoints()
	NEWPART.Parent = PARENT
	return NEWPART
end

function CreatePart2(FORMFACTOR,PARENT,MATERIAL,REFLECTANCE,TRANSPARENCY,BRICKCOLOR,NAME,SIZE,ANCHOR)
	local NEWPART = Instance.new("Part")
	NEWPART.Massless = true
	NEWPART.formFactor = FORMFACTOR
	NEWPART.Reflectance = REFLECTANCE
	NEWPART.Transparency = TRANSPARENCY
	NEWPART.CanCollide = false
	NEWPART.Locked = true
	NEWPART.Anchored = true
	if ANCHOR == false then
		NEWPART.Anchored = false
	end
	NEWPART.Color = GUN.NeonParts.Color
	coroutine.resume(coroutine.create(function()
		while true do
			Swait()
			NEWPART.Color = GUN.NeonParts.Color
		end
	end))
	NEWPART.Name = randomstring()
	NEWPART.Size = SIZE
	NEWPART.Position = Torso.Position
	NEWPART.Material = MATERIAL
	NEWPART:BreakJoints()
	NEWPART.Parent = PARENT
	return NEWPART
end

local S = Instance.new("Sound")
function CreateSound(ID,PARENT,VOLUME,PITCH,DOESLOOP) -- Fixed
	local NEWSOUND = nil
	coroutine.resume(coroutine.create(function()
		NEWSOUND = S:Clone()
		NEWSOUND.Parent = PARENT
		NEWSOUND.Volume = VOLUME
		NEWSOUND.Pitch = PITCH
		NEWSOUND.SoundId = "http://www.roblox.com/asset/?id="..ID
		NEWSOUND:play()
		if DOESLOOP == true then
			NEWSOUND.Looped = true
		else
			repeat wait(1) until NEWSOUND.Playing == false or NEWSOUND.Parent ~= PARENT
			NEWSOUND:remove()
		end
	end))
	return NEWSOUND
end

local function weldBetween(a,b)
	local weldd = Instance.new("Weld")
	weldd.Part0 = a
	weldd.Part1 = b
	weldd.C1 = b.CFrame:inverse() * a.CFrame
	weldd.Parent = b
	return weldd
end
function rayCast(Position,Direction,Range,Ignore)
	return workspace:FindPartOnRay(Ray.new(Position,Direction.unit * (Range or 999.999)),Ignore) 
end 		

function mdmg(centerofeffect,range)

end

function lcv2mg(centerofeffect,range)

end

function Effect(Table)
	local TYPE = (Table.EffectType or "Sphere")
	local SIZE = (Table.Size or Vector3.new(1,1,1))
	local ENDSIZE = (Table.Size2 or Vector3.new())
	local TRANSPARENCY = (Table.Transparency or 0)
	local ENDTRANSPARENCY = (Table.Transparency2 or 1)
	local CFRAME = (Table.CFrame or Torso.CFrame)
	local MOVEDIRECTION = (Table.MoveToPos or nil)
	local ROTATION1 = (Table.RotationX or 0)
	local ROTATION2 = (Table.RotationY or 0)
	local ROTATION3 = (Table.RotationZ or 0)
	local MATERIAL = (Table.Material or "Neon")
	local COLOR = (Table.Color or MAINRUINCOLOR)
	local hOK,sOK,vOK = Color3.toHSV(COLOR)
	local RAINBOWPART = true
	if sOK > .1 then
		RAINBOWPART = true
	end
	local TIME = (Table.Time or 45)
	local SOUNDID = (Table.SoundID or nil)
	local SOUNDPITCH = (Table.SoundPitch or nil)
	local SOUNDVOLUME = (Table.SoundVolume or nil)
	local USEBOOMERANGMATH = (Table.UseBoomerangMath or false)
	local BOOMERANG = (Table.Boomerang or 0)
	local SIZEBOOMERANG = (Table.SizeBoomerang or 0)
	coroutine.resume(coroutine.create(function()
		local PLAYSSOUND = false
		local SOUND = nil
		local EFFECT = CreatePart(3,Effects,MATERIAL,0,TRANSPARENCY,MAINRUINCOLOR,"Effect",Vector3.new(1,1,1),true)
		if RAINBOWPART then
			coroutine.resume(coroutine.create(function()
				while not stopeverything and EFFECT:IsDescendantOf(game) do
					EFFECT.Color = GUN.NeonParts.Color
					swait()
				end
			end))
		end
		if SOUNDID ~= nil and SOUNDPITCH ~= nil and SOUNDVOLUME ~= nil then
			PLAYSSOUND = true
			SOUND = CreateSound(SOUNDID,EFFECT,SOUNDVOLUME,SOUNDPITCH,false)
		end
		EFFECT.Color = COLOR
		local MSH = nil
		if TYPE == "Sphere" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"Sphere","","",SIZE,Vector3.new())
		elseif TYPE == "Block" or TYPE == "Box" then
			MSH = Instance.new("BlockMesh",EFFECT)
			MSH.Scale = SIZE
		elseif TYPE == "Wave" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","20329976","",SIZE,Vector3.new(0,0,-SIZE.X/8))
		elseif TYPE == "Ring" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","559831844","",Vector3.new(SIZE.X,SIZE.X,.1),Vector3.new())
		elseif TYPE == "Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662586858","",Vector3.new(SIZE.X/10,0,SIZE.X/10),Vector3.new())
		elseif TYPE == "Round Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662585058","",Vector3.new(SIZE.X/10,0,SIZE.X/10),Vector3.new())
		elseif TYPE == "Swirl" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","168892432","",SIZE,Vector3.new())
		elseif TYPE == "Skull" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","4770583","",SIZE,Vector3.new())
		elseif TYPE == "Crystal" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","9756362","",SIZE,Vector3.new())
		end
		if MSH ~= nil then
			local BOOMR1 = 1+BOOMERANG/50
			local BOOMR2 = 1+SIZEBOOMERANG/50
			local MOVESPEED = nil
			if MOVEDIRECTION ~= nil then
				if USEBOOMERANGMATH == true then
					MOVESPEED = ((CFRAME.p - MOVEDIRECTION).Magnitude/TIME)*BOOMR1
				else
					MOVESPEED = ((CFRAME.p - MOVEDIRECTION).Magnitude/TIME)
				end
			end
			local GROWTH = nil
			if USEBOOMERANGMATH == true then
				GROWTH = (SIZE - ENDSIZE)*(BOOMR2+1)
			else
				GROWTH = (SIZE - ENDSIZE)
			end
			local TRANS = TRANSPARENCY - ENDTRANSPARENCY
			if TYPE == "Block" then
				EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
			else
				EFFECT.CFrame = CFRAME
			end
			if USEBOOMERANGMATH == true then
				for LOOP = 1,TIME+1 do
					swait()
					MSH.Scale = MSH.Scale - (Vector3.new((GROWTH.X)*((1 - (LOOP/TIME)*BOOMR2)),(GROWTH.Y)*((1 - (LOOP/TIME)*BOOMR2)),(GROWTH.Z)*((1 - (LOOP/TIME)*BOOMR2)))*BOOMR2)/TIME
					if TYPE == "Wave" then
						MSH.Offset = Vector3.new(0,0,-MSH.Scale.Z/8)
					end
					EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
					if TYPE == "Block" then
						EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
					else
						EFFECT.CFrame = EFFECT.CFrame*CFrame.Angles(math.rad(ROTATION1),math.rad(ROTATION2),math.rad(ROTATION3))
					end
					if MOVEDIRECTION ~= nil then
						local ORI = EFFECT.Orientation
						EFFECT.CFrame = CFrame.new(EFFECT.Position,MOVEDIRECTION)*CFrame.new(0,0,-(MOVESPEED)*((1 - (LOOP/TIME)*BOOMR1)))
						EFFECT.Orientation = ORI
					end
				end
			else
				for LOOP = 1,TIME+1 do
					swait()
					MSH.Scale = MSH.Scale - GROWTH/TIME
					if TYPE == "Wave" then
						MSH.Offset = Vector3.new(0,0,-MSH.Scale.Z/8)
					end
					EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
					if TYPE == "Block" then
						EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
					else
						EFFECT.CFrame = EFFECT.CFrame*CFrame.Angles(math.rad(ROTATION1),math.rad(ROTATION2),math.rad(ROTATION3))
					end
					if MOVEDIRECTION ~= nil then
						local ORI = EFFECT.Orientation
						EFFECT.CFrame = CFrame.new(EFFECT.Position,MOVEDIRECTION)*CFrame.new(0,0,-MOVESPEED)
						EFFECT.Orientation = ORI
					end
				end
			end
			EFFECT.Transparency = 1
			if PLAYSSOUND == false then
				EFFECT:Destroy()
			else
				repeat if stopeverything then wait(math.huge) end swait() until EFFECT:FindFirstChildOfClass("Sound") == nil
				EFFECT:Destroy()
			end
		else
			if PLAYSSOUND == false then
				EFFECT:Destroy()
			else
				repeat if stopeverything then wait(math.huge) end swait() until EFFECT:FindFirstChildOfClass("Sound") == nil
				EFFECT:Destroy()
			end
		end
	end))
end

function Effect2(Table)
	local TYPE = (Table.EffectType or "Sphere")
	local SIZE = (Table.Size or Vector3.new(1,1,1))
	local ENDSIZE = (Table.Size2 or Vector3.new())
	local TRANSPARENCY = (Table.Transparency or 0)
	local ENDTRANSPARENCY = (Table.Transparency2 or 1)
	local CFRAME = (Table.CFrame or Torso.CFrame)
	local MOVEDIRECTION = (Table.MoveToPos or nil)
	local ROTATION1 = (Table.RotationX or 0)
	local ROTATION2 = (Table.RotationY or 0)
	local ROTATION3 = (Table.RotationZ or 0)
	local MATERIAL = (Table.Material or "Neon")
	local COLOR = (Table.Color or MAINRUINCOLOR)
	local TIME = (Table.Time or 45)
	local SOUNDID = (Table.SoundID or nil)
	local SOUNDPITCH = (Table.SoundPitch or nil)
	local SOUNDVOLUME = (Table.SoundVolume or nil)
	local USEBOOMERANGMATH = (Table.UseBoomerangMath or false)
	local BOOMERANG = (Table.Boomerang or 0)
	local SIZEBOOMERANG = (Table.SizeBoomerang or 0)
	coroutine.resume(coroutine.create(function()
		local PLAYSSOUND = false
		local SOUND = nil
		local EFFECT = CreatePart(3,Effects,MATERIAL,0,TRANSPARENCY,MAINRUINCOLOR,"Effect",Vector3.new(1,1,1),true)
		if true then
			coroutine.resume(coroutine.create(function()
				while not stopeverything and EFFECT:IsDescendantOf(game) do
					EFFECT.Color = GUN.NeonParts.Color
					swait()
				end
			end))
		end
		if SOUNDID ~= nil and SOUNDPITCH ~= nil and SOUNDVOLUME ~= nil then
			PLAYSSOUND = true
			SOUND = CreateSound(SOUNDID,EFFECT,SOUNDVOLUME,SOUNDPITCH,false)
		end
		EFFECT.Color = COLOR
		local MSH = nil
		if TYPE == "Sphere" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"Sphere","","",SIZE,Vector3.new())
		elseif TYPE == "Block" or TYPE == "Box" then
			MSH = Instance.new("BlockMesh",EFFECT)
			MSH.Scale = SIZE
		elseif TYPE == "Wave" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","20329976","",SIZE,Vector3.new(0,0,-SIZE.X/8))
		elseif TYPE == "Ring" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","559831844","",Vector3.new(SIZE.X,SIZE.X,.1),Vector3.new())
		elseif TYPE == "Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662586858","",Vector3.new(SIZE.X/10,0,SIZE.X/10),Vector3.new())
		elseif TYPE == "Round Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662585058","",Vector3.new(SIZE.X/10,SIZE.X/10,SIZE.X/10),Vector3.new())
		elseif TYPE == "Swirl" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","168892432","",SIZE,Vector3.new())
		elseif TYPE == "Skull" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","4770583","",SIZE,Vector3.new())
		elseif TYPE == "Crystal" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","9756362","",SIZE,Vector3.new())
		end
		if MSH ~= nil then
			local BOOMR1 = 1+BOOMERANG/50
			local BOOMR2 = 1+SIZEBOOMERANG/50
			local MOVESPEED = nil
			if MOVEDIRECTION ~= nil then
				if USEBOOMERANGMATH == true then
					MOVESPEED = ((CFRAME.p - MOVEDIRECTION).Magnitude/TIME)*BOOMR1
				else
					MOVESPEED = ((CFRAME.p - MOVEDIRECTION).Magnitude/TIME)
				end
			end
			local GROWTH = nil
			if USEBOOMERANGMATH == true then
				GROWTH = (SIZE - ENDSIZE)*(BOOMR2+1)
			else
				GROWTH = (SIZE - ENDSIZE)
			end
			local TRANS = TRANSPARENCY - ENDTRANSPARENCY
			if TYPE == "Block" then
				EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
			else
				EFFECT.CFrame = CFRAME
			end
			if USEBOOMERANGMATH == true then
				for LOOP = 1,TIME+1 do
					swait()
					MSH.Scale = MSH.Scale - (Vector3.new((GROWTH.X)*((1 - (LOOP/TIME)*BOOMR2)),(GROWTH.Y)*((1 - (LOOP/TIME)*BOOMR2)),(GROWTH.Z)*((1 - (LOOP/TIME)*BOOMR2)))*BOOMR2)/TIME
					if TYPE == "Wave" then
						MSH.Offset = Vector3.new(0,0,-MSH.Scale.Z/8)
					end
					EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
					if TYPE == "Block" then
						EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
					else
						EFFECT.CFrame = EFFECT.CFrame*CFrame.Angles(math.rad(ROTATION1),math.rad(ROTATION2),math.rad(ROTATION3))
					end
					if MOVEDIRECTION ~= nil then
						local ORI = EFFECT.Orientation
						EFFECT.CFrame = CFrame.new(EFFECT.Position,MOVEDIRECTION)*CFrame.new(0,0,-(MOVESPEED)*((1 - (LOOP/TIME)*BOOMR1)))
						EFFECT.Orientation = ORI
					end
				end
			else
				for LOOP = 1,TIME+1 do
					swait()
					MSH.Scale = MSH.Scale - GROWTH/TIME
					if TYPE == "Wave" then
						MSH.Offset = Vector3.new(0,0,-MSH.Scale.Z/8)
					end
					EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
					if TYPE == "Block" then
						EFFECT.CFrame = CFRAME*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
					else
						EFFECT.CFrame = EFFECT.CFrame*CFrame.Angles(math.rad(ROTATION1),math.rad(ROTATION2),math.rad(ROTATION3))
					end
					if MOVEDIRECTION ~= nil then
						local ORI = EFFECT.Orientation
						EFFECT.CFrame = CFrame.new(EFFECT.Position,MOVEDIRECTION)*CFrame.new(0,0,-MOVESPEED)
						EFFECT.Orientation = ORI
					end
				end
			end
			EFFECT.Transparency = 1
			if PLAYSSOUND == false then
				EFFECT:Destroy()
			else
				repeat if stopeverything then wait(math.huge) end swait() until EFFECT:FindFirstChildOfClass("Sound") == nil
				EFFECT:Destroy()
			end
		else
			if PLAYSSOUND == false then
				EFFECT:Destroy()
			else
				repeat if stopeverything then wait(math.huge) end swait() until EFFECT:FindFirstChildOfClass("Sound") == nil
				EFFECT:Destroy()
			end
		end
	end))
end

function Lightning(Part0,Part1,Timess,Offset,Color,Timer,sSize,eSize,Trans,Boomer,sBoomer,Trans2)
	local magz = (Part0 - Part1).Magnitude
	local Times = math.floor(math.clamp(magz/10,1,20))
	local curpos = Part0
	local trz = {
		-Offset,
		Offset
	}
	for i = 1,Times do
		local li = Instance.new("Part",Effects)
		li.Name = randomstring()
		li.TopSurface = 0
		li.Material = "Neon"
		li.BottomSurface = 0
		li.Anchored = true
		li.Locked = true
		li.Transparency = 0
		li.Color = Color
		li.formFactor = "Custom"
		li.CanCollide = false
		li.Size = Vector3.new(.1,.1,magz/Times)
		local Offzet = Vector3.new(trz[math.random(1,2)],trz[math.random(1,2)],trz[math.random(1,2)])
		local trolpos = CFrame.new(curpos,Part1) * CFrame.new(0,0,magz/Times).p + Offzet
		if Times == i then
			local magz2 = (curpos - Part1).Magnitude
			li.Size = Vector3.new(.1,.1,magz2)
			li.CFrame = CFrame.new(curpos,Part1) * CFrame.new(0,0,-magz2/2)
		else
			li.CFrame = CFrame.new(curpos,trolpos) * CFrame.new(0,0,magz/Times/2)
		end
		curpos = li.CFrame * CFrame.new(0,0,magz/Times/2).p
		li:Destroy()
		Effect({Time = Timer,EffectType = "Box",Size = Vector3.new(sSize,sSize,li.Size.Z),Size2 = Vector3.new(eSize,eSize,li.Size.Z),Transparency = Trans,Transparency2 = Trans2 or 1,CFrame = li.CFrame,MoveToPos = li.Position+VT(MRANDOM(-25,25),MRANDOM(-25,25),MRANDOM(-25,25)),RotationX = nil, RotationY = nil, RotationZ = nil,Material = "Neon",Color = li.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = Boomer,Boomerang = 0,SizeBoomerang = sBoomer})
		swait()
	end
end

function Lightning2(Part0,Part1,Timess,Offset,Color,Timer,sSize,eSize,Trans,Boomer,sBoomer,Trans2)
	local magz = (Part0 - Part1).Magnitude
	local Times = math.floor(math.clamp(magz/10,1,20))
	local curpos = Part0
	local trz = {
		-Offset,
		Offset
	}
	for i = 1,Times do
		local li = Instance.new("Part",Effects)
		li.Name = randomstring()
		li.TopSurface = 0
		li.Material = "Neon"
		li.BottomSurface = 0
		li.Anchored = true
		li.Locked = true
		li.Transparency = 0
		li.Color = Color
		li.formFactor = "Custom"
		li.CanCollide = false
		li.Size = Vector3.new(.1,.1,magz/Times)
		local Offzet = Vector3.new(trz[math.random(1,2)],trz[math.random(1,2)],trz[math.random(1,2)])
		local trolpos = CFrame.new(curpos,Part1) * CFrame.new(0,0,magz/Times).p + Offzet
		if Times == i then
			local magz2 = (curpos - Part1).Magnitude
			li.Size = Vector3.new(.1,.1,magz2)
			li.CFrame = CFrame.new(curpos,Part1) * CFrame.new(0,0,-magz2/2)
		else
			li.CFrame = CFrame.new(curpos,trolpos) * CFrame.new(0,0,magz/Times/2)
		end
		curpos = li.CFrame * CFrame.new(0,0,magz/Times/2).p
		li:Destroy()
		Effect({Time = Timer,EffectType = "Box",Size = Vector3.new(sSize,sSize,li.Size.Z),Size2 = Vector3.new(eSize,eSize,li.Size.Z),Transparency = Trans,Transparency2 = Trans2 or 1,CFrame = li.CFrame, MoveToPos = li.Position+VT(MRANDOM(-15,15),MRANDOM(-15,15),MRANDOM(-15,15)), RotationX = nil, RotationY = nil, RotationZ = nil,Material = "Neon",Color = li.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = Boomer,Boomerang = 0,SizeBoomerang = sBoomer})
		swait()
	end
end

function FireArc(Part,ToLocation,AmountOfTime,Height,DoesCourontine)
	if DoesCourontine == false then
		local Direction = CFrame.new(Part.Position,ToLocation)
		local Distance = (Part.Position - ToLocation).Magnitude
		for i = 1,AmountOfTime do
			swait()
			Part.CFrame = Direction*CFrame.new(0,(AmountOfTime/200)+((AmountOfTime/Height)-((i*2)/Height)),-Distance/AmountOfTime)
			Direction = Part.CFrame
		end
	elseif DoesCourontine == true then
		coroutine.resume(coroutine.create(function()
			local Direction = CFrame.new(Part.Position,ToLocation)
			local Distance = (Part.Position - ToLocation).Magnitude
			for i = 1,AmountOfTime do
				swait()
				Part.CFrame = Direction*CFrame.new(0,(AmountOfTime/200)+((AmountOfTime/Height)-((i*2)/Height)),-Distance/AmountOfTime)
				Direction = Part.CFrame
			end
		end))
	end
end

function MakeForm(PART,TYPE)
	if TYPE == "Cyl" then
		local MSH = Instance.new("CylinderMesh",PART)
	elseif TYPE == "Ball" then
		local MSH = Instance.new("SpecialMesh",PART)
		MSH.MeshType = "Sphere"
	elseif TYPE == "Wedge" then
		local MSH = Instance.new("SpecialMesh",PART)
		MSH.MeshType = "Wedge"
	end
end

function AttackGyro()
	local GYRO = Instance.new("BodyGyro",RootPart)
	GYRO.D = 25
	GYRO.P = 20000
	GYRO.MaxTorque = Vector3.new(0,4000000,0)
	GYRO.CFrame = CFrame.new(RootPart.Position,Mouse.Hit.p)
	coroutine.resume(coroutine.create(function()
		repeat if stopeverything then wait(math.huge) end
			swait()
			GYRO.CFrame = CFrame.new(RootPart.Position,Mouse.Hit.p)
		until not attack
		GYRO:Destroy()
	end))
end
function CreatePartb(FORMFACTOR, PARENT, MATERIAL, REFLECTANCE, TRANSPARENCY, BRICKCOLOR, NAME, SIZE, ANCHOR)
	local NEWPART = Instance.new("Part")
	NEWPART.formFactor = FORMFACTOR
	NEWPART.Reflectance = REFLECTANCE
	NEWPART.Transparency = TRANSPARENCY
	NEWPART.CanCollide = false
	NEWPART.Locked = true
	NEWPART.Anchored = true
	if ANCHOR == false then
		NEWPART.Anchored = false
	end
	NEWPART.BrickColor = BrickColor.new(tostring(BRICKCOLOR))
	NEWPART.Name = NAME
	NEWPART.Size = SIZE
	NEWPART.Position = Torso.Position
	NEWPART.Material = MATERIAL
	NEWPART:BreakJoints()
	NEWPART.Parent = PARENT
	return NEWPART
end
function CreateWeldOrSnapOrMotor(TYPE, PARENT, PART0, PART1, C0, C1)
	local NEWWELD = Instance.new(TYPE)
	NEWWELD.Part0 = PART0
	NEWWELD.Part1 = PART1
	NEWWELD.C0 = C0
	NEWWELD.C1 = C1
	NEWWELD.Parent = PARENT
	return NEWWELD
end

local co1 = 0
local cotof = false

coroutine.resume(coroutine.create(function()
	while true do
		swait()
		BAW = Color3.new(co1,co1,co1)
		if co1 == 255 then
			cotof = false
		elseif co1 == 0 then
			cotof = true
		end
		if cotof == true then
			co1 = co1 + 1*5
		elseif cotof == false then
			co1 = co1 - 1*5
		end
	end
end))

godcatparts = Instance.new("Model", Character)
local Hue = 0
coroutine.resume(coroutine.create(function()
	while not stopeverything do
		for i = 0,1,(1/60) do
			swait()
			if not alreadyfixing then
				GUN2.Base.Color = GUN2.Base.Color
				GUN2.NeonParts.Color = GUN2.NeonParts.Color
				----------------------
				for i,v in pairs(NeonParts:GetChildren()) do
					if v.Name == "1" then
						v.Color = v.Color
					end
					if v.Name == "2" then
						v.Color = GUN.NeonParts.Color
						v.Light.Color = GUN.NeonParts.Color
						v.Light.Range = 5
						v.Light.Shadows = true
					end
				end
				for i,v in pairs(Scythe.Neons:GetChildren()) do
					if v then
						if v == Scythe.Neons.outer then
							v.Color = v.Color
						else
							v.Color = GUN.NeonParts.Color
							v.Light.Color = GUN.NeonParts.Color
							v.Light.Range = 3
							v.Light.Shadows = true
							v.CanCollide = false
						end
					end
				end
				for i,v in pairs(Scythe.Base:GetChildren()) do
					if v then
						v.Color = v.Color
						v.CanCollide = false
					end
				end
				GUN2.ReColor.Color = GUN2.NeonParts.Color
				GUN2.ReColor.Transparency = GUN2.NeonParts.Transparency
				GUN.ReColor.Transparency = GUN.Gun.Transparency
				GUN.ReColor.Color = GUN.NeonParts.Color

				----------------------
				k = math.random(0,3)
				if taunt.Value == "aEa" then
					local sesk=math.random(0,255)
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "N4N" then
					GUN.NeonParts.Color = Color3.new(0,0,0)-- Lol
				elseif taunt.Value == "Insanity" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "uncolored" or taunt.Value == "mlc" or taunt.Value == "Default" or taunt.Value == "Banisher2" then -- credits to godcat
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "BadKarma" or taunt.Value == "when" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "Err0r" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "Visualizer" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "Matt" then -- USC Colors but not real colors
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "FAST BOIII" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "idkw" then
					if k == 0 then -- USC Colors
						GUN.NeonParts.Color = Color3.new(0,0,0)
					elseif k == 1 then
						GUN.NeonParts.Color = Color3.new(0,0,0)
					elseif k == 2 then
						GUN.NeonParts.Color = Color3.new(0,0,0)
					elseif k == 3 then
						GUN.NeonParts.Color = Color3.new(0,0,0)
					end
				elseif taunt.Value == "N0X" then
					GUN.NeonParts.Color = Color3.fromRGB(0,0,0)
				elseif taunt.Value == "idk" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "error?" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "Glitch" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "unholy" or taunt.Value == "X⁔X" then -- credits to godcat
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "h" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				elseif taunt.Value == "None2" or taunt.Value == "UpsideDown" then
					GUN.NeonParts.Color = Color3.new(0,0,0)
				else
					GUN.NeonParts.Color = Color3.new(0,0,0)
				end
				Box.Color3 = GUN.NeonParts.Color
				Box.SurfaceColor3 = Box.SurfaceColor3
				GUN.Base.Color = GUN.Base.Color
				HoverBoard.Colors.Color = GUN.NeonParts.Color
				HoverBoard.Base.Color = HoverBoard.Base.Color
				GUN.GunAdditions.Color = GUN.GunAdditions.Color
				GUN.NeonParts.Light.Color = GUN.NeonParts.Color
				GUN.NeonParts.Light.Brightness = 1
				if GUN.NeonParts.Transparency == 1 then
					GUN.NeonParts.Light.Enabled = false
				else
					GUN.NeonParts.Light.Enabled = true
				end 
				if GUN2.NeonParts.Transparency == 1 then
					GUN2.NeonParts.Light1.Light.Enabled = false
					GUN2.NeonParts.Light2.Light.Enabled = false
				else
					GUN2.NeonParts.Light1.Light.Enabled = true
					GUN2.NeonParts.Light2.Light.Enabled = true
				end
				if taunt.Value == "Banisher" or taunt.Value == "Banisher2" or taunt.Value == "X⁔X" then
					GUN2.Base.Transparency = 1
					GUN2.NeonParts.Transparency = 1
					GUN2.the.Transparency = 0
					GUN2.gunny.Transparency = 0
				else
					GUN2.Base.Transparency = 1
					GUN2.NeonParts.Transparency = 1
					GUN2.the.Transparency = 1
					GUN2.gunny.Transparency = 1
				end

				if taunt.Value == "BadKarma" or taunt.Value == "Visualizer" then
					for i,v in pairs(Scythe.Neons:GetChildren()) do
						if v then
							v.Transparency = 0
							v.Light.Enabled = true
						end
					end
					for i,v in pairs(Scythe.Base:GetChildren()) do
						if v then
							v.Transparency = 0
						end
					end
				else
					for i,v in pairs(Scythe.Neons:GetChildren()) do
						if v then
							v.Transparency = 1
							v.Light.Enabled = false
						end
					end
					for i,v in pairs(Scythe.Base:GetChildren()) do
						if v then
							v.Transparency = 1
						end
					end
				end
				GUN2.NeonParts.Light1.Light.Shadows = true
				GUN2.NeonParts.Light2.Light.Shadows = true
				GUN2.NeonParts.Light1.Light.Range = 2
				GUN2.NeonParts.Light2.Light.Range = 2
				GUN.NeonParts.Light.Shadows = true
			end
		end
	end
end))
local brokentester = 0

game:GetService("Players").PlayerAdded:Connect(function(v)
	if stopeverything then wait(math.huge) end
	if v.Name == USERNAME then
		Player = v
		if lplr.Name == USERNAME then
			Player.Chatted:Connect(function(...)
				if stopeverything then wait(math.huge) end
				if game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Return) or game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.KeypadEnter) then
					--	ChatRemote:Fire(...)
				end
			end)
		end
		Player:FindFirstChildOfClass("Backpack").ChildAdded:Connect(function()
			if stopeverything then wait(math.huge) end
			Player:FindFirstChildOfClass("Backpack"):ClearAllChildren()
		end)
	end
end)
function WACKYEFFECT(Table)
	local TYPE = (Table.EffectType or "Sphere")
	local SIZE = (Table.Size or Vector3.new(1,1,1))
	local ENDSIZE = (Table.Size2 or Vector3.new())
	local TRANSPARENCY = (Table.Transparency or 0)
	local ENDTRANSPARENCY = (Table.Transparency2 or 1)
	local CFRAME = (Table.CFrame or Torso.CFrame)
	local MOVEDIRECTION = (Table.MoveToPos or nil)
	local ROTATION1 = (Table.RotationX or 0)
	local ROTATION2 = (Table.RotationY or 0)
	local ROTATION3 = (Table.RotationZ or 0)
	local MATERIAL = (Table.Material or "Neon")
	local COLOR = (Table.Color or MAINRUINCOLOR)
	local hOK,sOK,vOK = Color3.toHSV(COLOR)
	local RAINBOWPART = false
	if sOK > .1 then
		RAINBOWPART = true
	end
	local TIME = (Table.Time or 45)
	local SOUNDID = (Table.SoundID or nil)
	local SOUNDPITCH = (Table.SoundPitch or nil)
	local SOUNDVOLUME = (Table.SoundVolume or nil)
	coroutine.resume(coroutine.create(function()
		local PLAYSSOUND = false
		local SOUND = nil
		local EFFECT = CreatePart(3,Effects,MATERIAL,0,TRANSPARENCY,MAINRUINCOLOR,"Effect",Vector3.new(1,1,1),true)
		if SOUNDID ~= nil and SOUNDPITCH ~= nil and SOUNDVOLUME ~= nil then
			PLAYSSOUND = true
			SOUND = CreateSound(SOUNDID,EFFECT,SOUNDVOLUME,SOUNDPITCH,false)
		end
		EFFECT.Color = COLOR
		if RAINBOWPART then
			coroutine.resume(coroutine.create(function()
				while not stopeverything and EFFECT:IsDescendantOf(game) do
					EFFECT.Color = GUN.NeonParts.Color
					swait()
				end
			end))
		end
		local MSH = nil
		if TYPE == "Sphere" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"Sphere","","",SIZE,Vector3.new())
		elseif TYPE == "Block" then
			MSH = Instance.new("BlockMesh",EFFECT)
			MSH.Scale = Vector3.new(SIZE.X,SIZE.Y,SIZE.Z)
		elseif TYPE == "Wave" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","20329976","",SIZE,Vector3.new(0,0,-SIZE.X/8))
		elseif TYPE == "Ring" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","559831844","",Vector3.new(SIZE.X,SIZE.X,.1),Vector3.new())
		elseif TYPE == "Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662586858","",Vector3.new(SIZE.X/10,0,SIZE.X/10),Vector3.new())
		elseif TYPE == "Round Slash" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","662585058","",Vector3.new(SIZE.X/10,0,SIZE.X/10),Vector3.new())
		elseif TYPE == "Swirl" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","1051557","",SIZE,Vector3.new())
		elseif TYPE == "Skull" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","4770583","",SIZE,Vector3.new())
		elseif TYPE == "Crystal" then
			MSH = CreateMesh("SpecialMesh",EFFECT,"FileMesh","9756362","",SIZE,Vector3.new())
		end
		if MSH ~= nil then
			local MOVESPEED = nil
			if MOVEDIRECTION ~= nil then
				MOVESPEED = (CFRAME.p - MOVEDIRECTION).Magnitude/TIME
			end
			local GROWTH = SIZE - ENDSIZE
			local TRANS = TRANSPARENCY - ENDTRANSPARENCY
			EFFECT.CFrame = CFRAME
			for LOOP = 1,TIME+1 do
				swait()
				MSH.Scale = MSH.Scale - GROWTH/TIME
				if TYPE == "Wave" then
					MSH.Offset = Vector3.new(0,0,-MSH.Scale.X/8)
				end
				EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
				EFFECT.CFrame = EFFECT.CFrame*CFrame.Angles(math.rad(ROTATION1),math.rad(ROTATION2),math.rad(ROTATION3))
				if MOVEDIRECTION ~= nil then
					local ORI = EFFECT.Orientation
					EFFECT.CFrame = CFrame.new(EFFECT.Position,MOVEDIRECTION)*CFrame.new(0,0,-MOVESPEED)
					EFFECT.Orientation = ORI
				end
			end
			if PLAYSSOUND == false then
				EFFECT:remove()
			else
				repeat if stopeverything then wait(math.huge) end swait() until SOUND.Playing == false
				EFFECT:remove()
			end
		else
			if PLAYSSOUND == false then
				EFFECT:remove()
			else
				repeat if stopeverything then wait(math.huge) end swait() until SOUND.Playing == false
				EFFECT:remove()
			end
		end
	end))
end
function GODCATEFFECT(Table)
	local TYPE = (Table.EffectType or "Sphere")
	local SIZE = (Table.Size or VT(1,1,1))
	local ENDSIZE = (Table.Size2 or VT(0,0,0))
	local TRANSPARENCY = (Table.Transparency or 0)
	local ENDTRANSPARENCY = (Table.Transparency2 or 1)
	local CFRAME = (Table.CFrame or Torso.CFrame)
	local MOVEDIRECTION = (Table.MoveToPos or nil)
	local ROTATION1 = (Table.RotationX or 0)
	local ROTATION2 = (Table.RotationY or 0)
	local ROTATION3 = (Table.RotationZ or 0)
	local MATERIAL = (Table.Material or "Neon")
	local COLOR = (Table.Color or Color3.new(1,1,1))
	local TIME = (Table.Time or 45)
	local SOUNDID = (Table.SoundID or nil)
	local SOUNDPITCH = (Table.SoundPitch or nil)
	local SOUNDVOLUME = (Table.SoundVolume or nil)
	coroutine.resume(coroutine.create(function()
		local PLAYSSOUND = false
		local SOUND = nil
		local EFFECT = CreatePart(3, Effects, MATERIAL, 0, TRANSPARENCY, BrickColor.new("Pearl"), "Effect", VT(1,1,1), true)
		if SOUNDID ~= nil and SOUNDPITCH ~= nil and SOUNDVOLUME ~= nil then
			PLAYSSOUND = true
			SOUND = CreateSound(SOUNDID, EFFECT, SOUNDVOLUME, SOUNDPITCH, false)
		end
		EFFECT.Color = COLOR
		local MSH = nil
		if TYPE == "Sphere" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "Sphere", "", "", SIZE, VT(0,0,0))
		elseif TYPE == "Block" then
			MSH = Instance.new("BlockMesh",EFFECT)
			MSH.Scale = VT(SIZE.X,SIZE.X,SIZE.X)
		elseif TYPE == "Wave" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "20329976", "", SIZE, VT(0,0,-SIZE.X/8))
		elseif TYPE == "Ring" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "559831844", "", VT(SIZE.X,SIZE.X,0.1), VT(0,0,0))
		elseif TYPE == "Slash" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "662586858", "", VT(SIZE.X/10,0,SIZE.X/10), VT(0,0,0))
		elseif TYPE == "Round Slash" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "662585058", "", VT(SIZE.X/10,0,SIZE.X/10), VT(0,0,0))
		elseif TYPE == "Swirl" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "1051557", "", SIZE, VT(0,0,0))
		elseif TYPE == "Skull" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "4770583", "", SIZE, VT(0,0,0))
		elseif TYPE == "Crystal" then
			MSH = CreateMesh("SpecialMesh", EFFECT, "FileMesh", "9756362", "", SIZE, VT(0,0,0))
		end
		if MSH ~= nil then
			local MOVESPEED = nil
			if MOVEDIRECTION ~= nil then
				MOVESPEED = (CFRAME.p - MOVEDIRECTION).Magnitude/TIME
			end
			local GROWTH = SIZE - ENDSIZE
			local TRANS = TRANSPARENCY - ENDTRANSPARENCY
			if TYPE == "Block" then
				EFFECT.CFrame = CFRAME*ANGLES(RAD(MRANDOM(0,360)),RAD(MRANDOM(0,360)),RAD(MRANDOM(0,360)))
			else
				EFFECT.CFrame = CFRAME
			end
			for LOOP = 1, TIME+1 do
				Swait()
				MSH.Scale = MSH.Scale - GROWTH/TIME
				if TYPE == "Wave" then
					MSH.Offset = VT(0,0,-MSH.Scale.X/8)
				end
				EFFECT.Transparency = EFFECT.Transparency - TRANS/TIME
				if TYPE == "Block" then
					EFFECT.CFrame = CFRAME*ANGLES(RAD(MRANDOM(0,360)),RAD(MRANDOM(0,360)),RAD(MRANDOM(0,360)))
				else
					EFFECT.CFrame = EFFECT.CFrame*ANGLES(RAD(ROTATION1),RAD(ROTATION2),RAD(ROTATION3))
				end
				if MOVEDIRECTION ~= nil then
					local ORI = EFFECT.Orientation
					EFFECT.CFrame = CF(EFFECT.Position,MOVEDIRECTION)*CF(0,0,-MOVESPEED)
					EFFECT.Orientation = ORI
				end
			end
			if PLAYSSOUND == false then
				EFFECT:remove()
			else
				SOUND.Stopped:Connect(function()
					EFFECT:remove()
				end)
			end
		else
			if PLAYSSOUND == false then
				EFFECT:remove()
			else
				repeat Swait() until SOUND.Playing == false
				EFFECT:remove()
			end
		end
	end))
end
function SpawnTrail(FROM,TO,BIG)
	local TRAIL = CreatePart(3, Effects, "Neon", 0, 0, "Really red", "Trail", VT(10,10,10))
	MakeForm(TRAIL,"Cyl")
	game:GetService("RunService").Heartbeat:Connect(function()
		TRAIL.Color = GUN.NeonParts.Color
	end)
	local DIST = (FROM - TO).Magnitude
	if BIG == true then
		TRAIL.Size = VT(0.5,DIST,0.5)
	else
		TRAIL.Size = VT(0.25,DIST,0.25)
	end
	TRAIL.CFrame = CF(FROM, TO) * CF(0, 0, -DIST/2) * ANGLES(RAD(90),RAD(0),RAD(0))
	coroutine.resume(coroutine.create(function()
		for i = 1, 55 do
			Swait()
			TRAIL.Transparency = TRAIL.Transparency + 0.01
		end
		TRAIL:remove()
	end))
end
function Ka_Boom()
	attack = true
	walkspeed = 0
	coroutine.wrap(function()
		for i = 0,2 do
			swait(12)
			CreateSound(199145095,GUN.Joint,10,1)
		end
	end)()
	for i = 0,2,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(35),math.rad(-35),math.rad(20)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35),math.rad(-35),math.rad(20)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	for i = 0,1.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35),math.rad(-35),math.rad(20)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	for i = 0,.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,-.2,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end		
	end
	local BEAM = CreatePart(3,Effects,"Neon",0,0,GUN.NeonParts.Color,"Beam",Vector3.new())
	local BEAM2 = CreatePart(3,Effects,"Neon",0,0,GUN.NeonParts.Color,"Beam",Vector3.new())
	MakeForm(BEAM,"Ball")
	MakeForm(BEAM2,"Ball")
	BEAM.CFrame = CFrame.new(RootPart.Position)
	BEAM2.CFrame = CFrame.new(RootPart.Position)
	local boooom = CreateSound(7527936627,RootPart,10,2.5,false)
	boooom.EmitterSize = 100
	for i=1,140 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,-.2,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,-.2,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end
		BEAM.Size = BEAM.Size + Vector3.new(.7,8,.7)
		BEAM2.Size = BEAM2.Size + Vector3.new(2,2,2)
		BEAM.Color = GUN.NeonParts.Color
		BEAM2.Color = GUN.NeonParts.Color
		BEAM.CFrame = CFrame.new(RootPart.Position)
		BEAM2.CFrame = CFrame.new(RootPart.Position)
		Effect({EffectType = "Slash", Size = VT(0,0,0), Size2 = VT(5,.05,5), Transparency = 0, Transparency2 = 1, CFrame = BEAM.CFrame*CF(0,-1.3,0) * ANGLES(RAD(MRANDOM(-90,90)), RAD(MRANDOM(-90,90)), RAD(MRANDOM(-90,90))), MoveToPos = nil, RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = 1, SoundVolume = 0})
	end
	mdmg(RootPart.Position,BEAM2.Size.Y/2)
	DamageFling(RootPart.Position,BEAM2.Size.Y/2)
	Effect({TIME = 75,EffectType = "Sphere",Size = BEAM.Size,Size2 = Vector3.new(0,BEAM.Size.Y,0),Transparency = 0,Transparency2 = 0,CFrame = BEAM.CFrame,MoveToPos = nil,RotationX = 0,RotationY = 0,RotationZ = 0,Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil})
	Effect({TIME = 75,EffectType = "Sphere",Size = BEAM2.Size,Size2 = Vector3.new(),Transparency = 0,Transparency2 = .6,CFrame = BEAM2.CFrame,MoveToPos = nil,RotationX = 0,RotationY = 0,RotationZ = 0,Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil})
	for i,v in pairs(Effects:GetChildren()) do
		v.Color = MAINRUINCOLOR
		v:GetPropertyChangedSignal("Color"):Connect(function()
			if stopeverything then wait(math.huge) end
			v.Color = MAINRUINCOLOR
		end)
	end
	BEAM2:Destroy()
	BEAM:Destroy()
	attack = false
	walkspeed = 50
end
local ac = game:GetService("Players").LocalPlayer.Character["Starslayer Railgun"].Handle
function attackone()
	attack = true
	walkspeed = 16
	AttackGyro()
	for i = 0,.5,.05 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-30)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(30)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-30)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(30)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end
	end
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 8105322993,SoundPitch = 1,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	for i = 0,2 do
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
	end
	local mousehit = Mouse.Hit
	local DISTANCE = (Holetwo.Position - mousehit.p).Magnitude
	local killbeam = CreatePart(3,Effects,"Neon",0,0,MAINRUINCOLOR,"Kill Beam",Vector3.new(1,DISTANCE,1))
	killbeam.CFrame = CFrame.new(Holetwo.Position,mousehit.p) * CFrame.new(0,0,-DISTANCE/2) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(0))
	MakeForm(killbeam,"Cyl")
	coroutine.resume(coroutine.create(function()
		for i = 1,25 do
			swait()
			killbeam.Color = GUN.NeonParts.Color
			killbeam.Transparency = i/25
		end
		killbeam:Destroy()
	end))
	for i = 1,4 do
		coroutine.resume(coroutine.create(function()
			Lightning(ac.Position,mousehit.p,15,3.5,GUN.NeonParts.Color,25,0,1,0,true,55)
		end))
	end
	coroutine.resume(coroutine.create(function()

		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = mousehit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 821439273,SoundPitch = .8,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = mousehit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		for i = 0,2 do
			for a = 0, 14 do
				print("g")
			end
		end
		if anger == false then
			mdmg(mousehit.p,10)
			DamageFling(mousehit.p,10)
		elseif anger == true then
			lcv2mg(mousehit.p,10)
		end

	end))

	for i = 0,.5,.075 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(10),math.rad(0),math.rad(-60)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(160),math.rad(-20),math.rad(60)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(60)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(10),math.rad(0),math.rad(-60)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(160),math.rad(-20),math.rad(60)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	walkspeed = 50
	attack = false
end

function scythe_attack()
	attack = true
	walkspeed = 5
	for i = 0,.5,.05 do
		swait()
		RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
		Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
		RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(85)) * rscp,1 / 3)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)) * lscp,1 / 3)
		RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
		LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
		GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(180),math.rad(90),math.rad(0)),1 / 2)
	end
	CreateSound(8145344127,Scythe.Neons.Blade,5,1+(math.random(-4,4)/20),false)
	DamageFling(RootPart.Position,25)
	for i = 0,.5,.075 do
		swait()

		RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(60)),1 / 3)
		Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(10),math.rad(0),math.rad(-60)),1 / 3)
		RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(-90)) * rscp,1 / 3)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1 / 3)
		RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
		LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
		GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(180),math.rad(90),math.rad(0)),1 / 2)
	end
	walkspeed = 16
	attack = false
end

function attackone2()
	attack = true
	walkspeed = 16
	AttackGyro()
	for i = 0,.5,.05 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-30)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(30)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-30)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(30)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end
	end
	CreateSound(8105322993,ac,5,1)
	local mousehit = Mouse.Hit
	local DISTANCE = (ac.Position - mousehit.p).Magnitude
	for i = 1,4 do
		coroutine.resume(coroutine.create(function()
			Lightning2(ac.Position,mousehit.p,.5,.5,GUN.NeonParts.Color,15,0,.3,0,true,55)
		end))
	end
	coroutine.resume(coroutine.create(function()
		Lightning2(ac.Position,mousehit.p,.5,.5,GUN.NeonParts.Color,15,0,.3,0,true,55)
		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(1,1,1),Transparency = 0,Transparency2 = 1,CFrame = mousehit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = 1,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(1,1,1),Transparency = 0,Transparency2 = 1,CFrame = mousehit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		if anger == false then
			mdmg(mousehit.p,10)
			DamageFling(mousehit.p,10)
		elseif anger == true then
			lcv2mg(mousehit.p,10)
		end
	end))
	for i = 0,.5,.075 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(30)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(10),math.rad(0),math.rad(-60)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(160),math.rad(-20),math.rad(60)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(60)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(10),math.rad(0),math.rad(-60)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(160),math.rad(-20),math.rad(60)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	walkspeed = 50
	attack = false
end

function attacktwo()
	attack = true
	walkspeed = 0
	AttackGyro()
	local gBullet = CreatePart(3,Effects,"Neon",0,0,GUN.NeonParts.Color,"AbsoluteNoob",Vector3.new())
	MakeForm(gBullet,"Ball")
	gBullet.CFrame = LeftArm.CFrame*CFrame.new(0,-1.5,0)
	CreateSound(3723700663,gBullet,10,1)
	for i = 0,1.25,.025 do
		swait()
		Effect({Time = math.random(35,55),EffectType = "Sphere",Size = Vector3.new(.5,.5,.5),Size2 = Vector3.new(1,1,1),Transparency = 0,Transparency2 = 1,CFrame = LeftArm.CFrame*CFrame.new(0,-1.5,0),MoveToPos = LeftArm.CFrame*CFrame.new(0,-1.5,0)*CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)).p,RotationX = nil,RotationY = nil,RotationZ = nil,Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 50,SizeBoomerang = 50})
		gBullet.Size = gBullet.Size * 1.085
		gBullet.CFrame = LeftArm.CFrame*CFrame.new(0,-1.5,0)
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-30)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-5 - 3 * math.cos(sine/12)),math.rad(0),math.rad(30)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(135 + 8.5 * math.cos(sine/49)),math.rad(0),math.rad(25)) * RIGHTSHOULDERC0,.7/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5 + .1 * math.cos(sine/12),-0) * CFrame.Angles(math.rad(85 - 1.5 * math.cos(sine/12)),math.rad(0 - 6 * math.cos(sine/12)),math.rad(-30 - 6 * math.cos(sine/12))) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.cos(sine / 12)) * CFrame.Angles(math.rad(5),math.rad(0),math.rad(-30)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(-5 - 3 * math.cos(sine / 12)),math.rad(0),math.rad(30)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-62.5),math.rad(0 - 5 * math.cos(sine / 12)),math.rad(30)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5 + 0.1 * math.cos(sine / 12),-0) * CFrame.Angles(math.rad(85 - 1.5 * math.cos(sine / 12)),math.rad(0 - 6 * math.cos(sine / 12)),math.rad(-30 - 6 * math.cos(sine / 12))) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1 - 0.075 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1 - 0.075 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	local bullets = {}
	for i = 1,math.random(27,41) do
		swait()
		local Bullet = CreatePart(3,Effects,"Neon",0,0,GUN.NeonParts.Color,"Shit.",Vector3.new(.6,.6,.6))
		MakeForm(Bullet,"Ball")
		Bullet.CFrame = gBullet.CFrame
		Effect({Time = math.random(5,20),EffectType = "Sphere",Size = Vector3.new(3,3,3)*math.random(-3,2),Size2 = Vector3.new(6,6,6)*math.random(-3,2),Transparency = .4,Transparency2 = 1,CFrame = Bullet.CFrame,MoveToPos = nil,RotationX = nil,RotationY = nil,RotationZ = nil,Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 25})
		table.insert(bullets,Bullet)
	end
	local oofing = false
	for b = 1,#bullets do
		swait()
		local part,pos = rayCast(LeftArm.CFrame*CFrame.new(0,-1.5,0).p,((Mouse.Hit.p+Vector3.new(math.random(-15,15),math.random(-7,7),math.random(-15,15))) - LeftArm.CFrame*CFrame.new(0,-1.5,0).p),500,Character)
		coroutine.resume(coroutine.create(function()
			FireArc(bullets[b],pos,math.random(17,31),math.random(9,15),false)
			Effect({Time = math.random(25,35),EffectType = "Sphere",Size = Vector3.new(.6,.6,.6),Size2 = Vector3.new(1.6,1.6,1.6),Transparency = 0,Transparency2 = 1,CFrame = bullets[b].CFrame,MoveToPos = nil,RotationX = nil,RotationY = nil,RotationZ = nil,Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 25})
			swait(math.random(55,65))
			for i = 0,2 do
				Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = bullets[b].CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
				Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = bullets[b].CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
			end
			for i = 0,10 do
				swait()
				bullets[b].Transparency = bullets[b].Transparency + .1
			end
			oofing = not oofing
			if oofing then
				mdmg(bullets[b].Position,10)
			end
			local EEEBRUHEEE = CreateSound(168513088,bullets[b],3.5,1.1,false)
			bullets[b].Transparency = 1
			EEEBRUHEEE.Ended:Connect(function()
				if stopeverything then wait(math.huge) end
				bullets[b]:Destroy()
			end)
		end))
	end
	for i = 0,10 do
		swait()
		gBullet.Transparency = gBullet.Transparency + .1
	end
	gBullet:Destroy()
	walkspeed = 50
	attack = false
end

function hedshoot()
	attack = true
	walkspeed = 16
	CreateSound(235097614,RootPart,6,1.5,false)
	for i = 0,.5,.05 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-60)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(60)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.25,.5,-.25) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(-60)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.25,.5,-.25) * CFrame.Angles(math.rad(95),math.rad(0),math.rad(10)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-60)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(60)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.25,0.5,-.25) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(-60)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.25,0.5,-.25) * CFrame.Angles(math.rad(95),math.rad(0),math.rad(10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	for xd = 1,5 do
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.15,0,.15),Transparency = 0,Transparency2 = 1,CFrame = Torso.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.15,0,.15),Transparency = 0,Transparency2 = 1,CFrame = Torso.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
	end
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(2,2,2),Size2 = Vector3.new(5,5,5),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 7229703765,SoundPitch = 1,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(2,2,2),Size2 = Vector3.new(5,5,5),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = math.random(25,45),EffectType = "Sphere",Size = Vector3.new(2,100,2),Size2 = Vector3.new(6,100,6),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame*CFrame.new(math.random(-1,1),math.random(-1,1),-50)*CFrame.Angles(math.rad(math.random(89,91)),math.rad(math.random(-1,1)),math.rad(math.random(-1,1))),MoveToPos = nil,RotationX = nil,RotationY = nil,RotationZ = nil,Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 45})
	Effect({Time = math.random(25,45),EffectType = "Sphere",Size = Vector3.new(3,100,3),Size2 = Vector3.new(9,100,9),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame*CFrame.new(math.random(-1,1),math.random(-1,1),-50)*CFrame.Angles(math.rad(math.random(89,91)),math.rad(math.random(-1,1)),math.rad(math.random(-1,1))),MoveToPos = nil,RotationX = nil,RotationY = nil,RotationZ = nil,Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 45})

	for i = 1,4 do
		RootPart.CFrame = RootPart.CFrame * CFrame.new(0,0,-25)
		mdmg(RootPart.Position,14)
		coroutine.resume(coroutine.create(function()
			Lightning(RootPart.CFrame*CFrame.new(math.random(-2.5,2.5),math.random(-5,5),math.random(-15,15)).p,RootPart.CFrame*CFrame.new(math.random(-2.5,2.5),math.random(-5,5),math.random(-15,15)).p,6,25,MAINRUINCOLOR,math.random(30,45),.5,1.5,0,true,60) 
		end))	
		coroutine.resume(coroutine.create(function()
			Lightning(RootPart.CFrame*CFrame.new(math.random(-2.5,2.5),math.random(-5,5),math.random(-15,15)).p,RootPart.CFrame*CFrame.new(math.random(-2.5,2.5),math.random(-5,5),math.random(-15,15)).p,6,25,GUN.NeonParts.Color,math.random(30,45),.5,1.5,0,true,60)
		end))
	end
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(2,2,2),Size2 = Vector3.new(5,5,5),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(2,2,2),Size2 = Vector3.new(5,5,5),Transparency = 0,Transparency2 = 1,CFrame = RootPart.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})

	for i = 0,.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(90)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(90)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(40),math.rad(5),math.rad(5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	attack = false
	walkspeed = 50
end
local stillraining = false
function painlessrain()
	attack = true
	walkspeed = 16
	coroutine.wrap(function()
		for i = 0,2 do
			swait(12)
			CreateSound(199145095,GUN.Joint,10,1)
		end
	end)()
	for i = 0,2,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(35),math.rad(-35),math.rad(20)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35),math.rad(-35),math.rad(20)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	for i = 0,1.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(25),math.rad(0),math.rad(-20)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(175),math.rad(-35),math.rad(20)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(-5),math.rad(-10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(doe * 22),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 642890855,SoundPitch = .81,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	for i = 0,.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,-.2,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,-.2,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-10),math.rad(-10),math.rad(-5)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end		
	end
	local skypos = ac.CFrame * CFrame.new(-400,0,0)
	local DISTANCE = (ac.Position - skypos.p).Magnitude
	local killbeam = CreatePart(3,Effects,"Neon",0,0,MAINRUINCOLOR,"Kill Beam",Vector3.new(1,DISTANCE,1))
	killbeam.CFrame = CFrame.new(ac.Position,skypos.p) * CFrame.new(0,0,-DISTANCE/2) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(0))
	MakeForm(killbeam,"Cyl")
	coroutine.resume(coroutine.create(function()
		for i = 1,25 do
			swait()
			killbeam.Transparency = i/25
		end
		killbeam:Destroy()
	end))
	for i = 1,4 do
		coroutine.resume(coroutine.create(function()
			Lightning(ac.Position,skypos.p,15,3.5,GUN.NeonParts.Color,25,0,1,0,true,55)
		end))
	end
	Lightning(ac.Position,skypos.p,15,3.5,GUN.NeonParts.Color,25,0,1,0,true,55)
	for i = 0,2 do
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = ac.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
	end
	for i = 0,.5,.1 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(-5),math.rad(-5),math.rad(0)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-5)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(-5)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(175),math.rad(-10),math.rad(10)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-5),math.rad(-5),math.rad(0)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end	
	attack = false
	walkspeed = 50
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = skypos,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 821439273,SoundPitch = .8,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = skypos,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
	for i = 0,2 do
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = skypos*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = skypos*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
	end
	for i = 1,5 do
		local Sky = RootPart.CFrame*CFrame.new(0,500,0)
		local MoPos = Mouse.Hit.p
		local DISTANCE = (Sky.p - MoPos).Magnitude
		for i = 1,4 do
			coroutine.resume(coroutine.create(function()
				Lightning(Sky.p,MoPos,15,3.5,GUN.NeonParts.Color,25,0,1,0,true,55)
			end))
		end
		Lightning(Sky.p,MoPos,15,3.5,GUN.NeonParts.Color,25,0,1,0,true,55)
		local killbeam = CreatePart(3,Effects,"Neon",0,0,MAINRUINCOLOR,"Kill Beam",Vector3.new(1,DISTANCE,1))
		killbeam.CFrame = CFrame.new(Sky.p,MoPos) * CFrame.new(0,0,-DISTANCE/2) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(0))
		MakeForm(killbeam,"Cyl")
		coroutine.resume(coroutine.create(function()
			for i = 1,25 do
				swait()
				killbeam.Transparency = i/25
			end
			killbeam:Destroy()
		end))
		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = CFrame.new(MoPos),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = 821439273,SoundPitch = .8,SoundVolume = 10,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		Effect({Time = 25,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = CFrame.new(MoPos),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
		for i = 0,2 do
			--Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = CFrame.new(MoPos)*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
			--Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = CFrame.new(MoPos)*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
			for a = 0, 14 do
				EFFECT1(3,math.random(4,8),"Add",CFrame.new(MoPos)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),3,3,3,0.03,GUN.NeonParts.Color,0)
			end
		end
		mdmg(MoPos,12)
		DamageFling(MoPos,12)
	end
	stillraining = false
end
function SingularityBeam()
	if anger == false then return end
	attack = true
	cannecksnap = false
	walkspeed = 0
	AttackGyro()
	for i = 0,.5,.05 do
		swait()
		if HipVal ~= 0 then
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-60)),.7/3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(60)),1/3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.25,.5,-.25) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(-60)) * rscp,1/3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.25,.5,-.25) * CFrame.Angles(math.rad(95),math.rad(0),math.rad(10)) * lscp,1/3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),.7/3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),.7/3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
		else
			RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-60)),1 / 3)
			Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(60)),1 / 3)
			RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.25,0.5,-.25) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(-60)) * rscp,1 / 3)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.25,0.5,-.25) * CFrame.Angles(math.rad(95),math.rad(0),math.rad(10)) * lscp,1 / 3)
			RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(75),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
			LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-65),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
			GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
		end	
	end
	local KillDist = (ac.Position - Mouse.Hit.p).Magnitude
	coroutine.resume(coroutine.create(function()
		repeat if stopeverything then wait(math.huge) end KillDist = (Holetwo.Position - Mouse.Hit.p).Magnitude Swait() until not attack
	end))
	local killbeam = CreatePart2(3,Effects,"Neon",0,0,GUN.NeonParts.Color,"Kill Beam",Vector3.new(2.5,KillDist,2.5))
	MakeForm(killbeam,"Cyl")
	killbeam.Touched:Connect(function(victim)
		if stopeverything then wait(math.huge) end

	end)
	coroutine.resume(coroutine.create(function()
		while not stopeverything and killbeam:IsDescendantOf(game) do

		end
	end))
	coroutine.resume(coroutine.create(function()
		local isdoingathing = false
		while not stopeverything and killbeam:IsDescendantOf(game) do
			isdoingathing = not isdoingathing
			if lplr.Name == USERNAME then
				RootPart.CFrame = RootPart.CFrame * CFrame.new(0,0,.1)
			end
			killbeam.Size = Vector3.new(2.5,KillDist,2.5)
			killbeam.CFrame = CFrame.new(Holetwo.Position,Mouse.Hit.p) * CFrame.new(0,0,-KillDist/2) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(0))
			if isdoingathing then
				coroutine.resume(coroutine.create(function()
					Lightning(Holetwo.Position,Mouse.Hit.p,15,3,GUN.NeonParts.Color,10,0,1,0,true,55)
				end))
				for a = 0, 14 do
					EFFECT1(3,math.random(4,8),"Add",Mouse.Hit*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),3,3,3,0.03,GUN.NeonParts.Color,0)
				end
				Effect({Time = 10,EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = Holetwo.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
				Effect({Time = 10,EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.1,0,.1),Transparency = 0,Transparency2 = 1,CFrame = Holetwo.CFrame*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
				Effect({Time = 10,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = Mouse.Hit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
				Effect({Time = 10,EffectType = "Box",Size = Vector3.new(),Size2 = Vector3.new(3,3,3),Transparency = 0,Transparency2 = 1,CFrame = Mouse.Hit,MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 50})
			end
			Swait()
		end
	end))
	CreateSound(138677306,Holetwo,10,1,false)
	CreateSound(415700134,Holetwo,10,1,false)
	Swait(150)
	CreateSound(3264923,Holetwo,10,1,false)
	Swait(30)

	killbeam:Destroy()
	walkspeed = 50
	attack = false
	cannecksnap = true
end
function Combo()
	attack = true
	local COMBO = 1
	local HIT2 = function()
		local HITS2 = {}
		local TOUCH2 = LeftArm.Touched:Connect(function(hit)
			if hit.Parent:FindFirstChildOfClass("Humanoid") and hit.Parent ~= Character then
				local HUM = hit.Parent:FindFirstChildOfClass("Humanoid")
				local TORSO = hit.Parent:FindFirstChild("Torso") or hit.Parent:FindFirstChild("UpperTorso")
				if TORSO and HUM.Health > 0 then
					local PASS = true
					for i = 1, #HITS2 do
						if HITS2[i] == hit.Parent then
							PASS = false
						end
					end
					table.insert(HITS2,hit.Parent)
					if PASS == true then
						mdmg(HUM.Parent,1)
					end
				end
			end
		end)
		return TOUCH2
	end
	local HIT = function()
		local HITS = {}
		local TOUCH = RightArm.Touched:Connect(function(hit)
			if hit.Parent:FindFirstChildOfClass("Humanoid") and hit.Parent ~= Character then
				local HUM = hit.Parent:FindFirstChildOfClass("Humanoid")
				local TORSO = hit.Parent:FindFirstChild("Torso") or hit.Parent:FindFirstChild("UpperTorso")
				if TORSO and HUM.Health > 0 then
					local PASS = true
					for i = 1, #HITS do
						if HITS[i] == hit.Parent then
							PASS = false
						end
					end
					table.insert(HITS,hit.Parent)
					if PASS == true then
						mdmg(HUM.Parent,1)
					end
				end
			end
		end)
		return TOUCH
	end
	if COMBO == 1 then
		for i=0, 0.35, 0.1 / Animation_Speed do
			Swait()
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(5)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(-15)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(90)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-15)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)  
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		CreateSound(1489705211,RightArm,MRANDOM(7,8),MRANDOM(8,13)/12,false)
		local TOUCHED = HIT()
		for i=0, 0.5, 0.1 / Animation_Speed do
			Swait()
			WACKYEFFECT({EffectType = "Block", Size = VT(1,1,1), Size2 = VT(0,0,0), Transparency = 0, Transparency2 = 1, CFrame = RightArm.CFrame*CF(0,-1,0), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(-35)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(45)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(0.8, 0.5, -0.7) * ANGLES(RAD(0), RAD(0), RAD(-90)) * ANGLES(RAD(15), RAD(180), RAD(0)) * RIGHTSHOULDERC0, 0.6 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-15)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		TOUCHED:Disconnect()
		COMBO = 2
	elseif COMBO == 2 then
		for i=0, 0.35, 0.1 / Animation_Speed do
			Swait()
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(5)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(15)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(15)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(-20), RAD(0), RAD(-15)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		CreateSound(1489705211,LeftArm,MRANDOM(7,8),MRANDOM(8,13)/12,false)
		local TOUCHED = HIT2()
		for i=0, 0.5, 0.1 / Animation_Speed do
			Swait()
			WACKYEFFECT({EffectType = "Block", Size = VT(1,1,1), Size2 = VT(0,0,0), Transparency = 0, Transparency2 = 1, CFrame = LeftArm.CFrame*CF(0,-1,0), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(45)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(-55)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(15)) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.6 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, -0.5) * ANGLES(RAD(0), RAD(0), RAD(-105)) * ANGLES(RAD(90), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		TOUCHED:Disconnect()
		COMBO = 3
	elseif COMBO == 3 then
		for i=0, 0.35, 0.1 / Animation_Speed do
			Swait()
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-5), RAD(0), RAD(0)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0.25, -0.2) * ANGLES(RAD(-25), RAD(0), RAD(0)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(75), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(75), RAD(0), RAD(-45)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(-25), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(-25), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(-25), RAD(70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(-25), RAD(-70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		CreateSound(1489705211,LeftArm,MRANDOM(7,8),MRANDOM(8,13)/12,false)
		local TOUCHED = HIT2()
		local TOUCHED2 = HIT()
		for i=0, 0.5, 0.1 / Animation_Speed do
			Swait()
			WACKYEFFECT({EffectType = "Block", Size = VT(1,1,1), Size2 = VT(0,0,0), Transparency = 0, Transparency2 = 1, CFrame = LeftArm.CFrame*CF(0,-1,0), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			WACKYEFFECT({EffectType = "Block", Size = VT(1,1,1), Size2 = VT(0,0,0), Transparency = 0, Transparency2 = 1, CFrame = RightArm.CFrame*CF(0,-1,0), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(25), RAD(0), RAD(0)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, -0.3, -0.2) * ANGLES(RAD(30), RAD(0), RAD(0)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1, 0.5, -0.5) * ANGLES(RAD(90), RAD(0), RAD(-30)) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.6 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.5, -0.5) * ANGLES(RAD(90), RAD(0), RAD(30)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(30), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(30), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(30), RAD(70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(30), RAD(-70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end
		TOUCHED:Disconnect()
		TOUCHED2:Disconnect()
		COMBO = 4
	elseif COMBO == 4 then
		for i=0, 0.5, 0.1 / Animation_Speed do
			Swait()
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(0)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, -0.3, -0.2) * ANGLES(RAD(30), RAD(0), RAD(0)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.2, 0.5, -0.5) * ANGLES(RAD(75), RAD(0), RAD(-70)) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.6 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.2, 0.5, -0.5) * ANGLES(RAD(75), RAD(0), RAD(70)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(30), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(30), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(30), RAD(70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(30), RAD(-70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end	
		WACKYEFFECT({Time = 40,EffectType = "Block", Size = VT(0,0,0), Size2 = VT(25,25,25), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,0,-0.5), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = 260435136, SoundPitch = 0.9, SoundVolume = 10})
		WACKYEFFECT({Time = 25,EffectType = "Slash", Size = VT(0,0,0), Size2 = VT(0.5,0,0.5), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,0,-0.5), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
		WACKYEFFECT({Time = 25,EffectType = "Ring", Size = VT(0,0,0), Size2 = VT(1,3,3), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,0,-0.5), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
		WACKYEFFECT({Time = 25,EffectType = "Wave", Size = VT(0,0,0), Size2 = VT(25,0,25), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,0,-0.5), MoveToPos = nil, RotationX = MRANDOM(1,360), RotationY = MRANDOM(1,360), RotationZ = MRANDOM(1,360), Material = "Neon", Color = C3(0.5,0,0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})

		mdmg(RootPart.Position,25)
		DamageFling(RootPart.Position,25)
		for i=0, 0.5, 0.1 / Animation_Speed do
			Swait()
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-15), RAD(0), RAD(0)), 3 / 3)
			RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0.25, -0.2) * ANGLES(RAD(-25), RAD(0), RAD(0)), 1 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(75), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(75), RAD(0), RAD(-45)) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
			if Torsovelocity > 0 then
				RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(-25), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(-5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(-25), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(5 + 50 * SIN(SINE / 12))), 1 / Animation_Speed)
			else
				RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(-25), RAD(70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
				LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(-25), RAD(-70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
			end
		end	
		COMBO = 1
	end
	coroutine.resume(coroutine.create(function()
		for i = 1, 50 do
			Swait()
			if attack == true then
				break
			end
		end
		if attack == false then
			COMBO = 1
		end
	end))

	attack = false

end
Mouse.Button1Down:Connect(function(rar)
	if stopeverything then wait(math.huge) end
	if not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "X⁔X") then
		attackone()
	end
	if not attack and (taunt.Value == "Banisher" or taunt.Value == "Banisher2" or taunt.Value == "X⁔X") then
		attackone2()
	end
	if not attack and (taunt.Value == "BadKarma" or taunt.Value == "Visualizer") then
		scythe_attack()
	end

	KPressed = "RMB"
end)
local FLYING = false
function sFLY()
	if not ISFLYING then
		FLYING = false
	else
		local CONTROL = {F = 0,B = 0,L = 0,R = 0,Q = 0,E = 0}
		local lCONTROL = {F = 0,B = 0,L = 0,R = 0,Q = 0,E = 0}
		local SPEED = 0			
		local function FLY()
			FLYING = true
			BG = Instance.new('BodyGyro',RootPart)
			BV = Instance.new('BodyVelocity',RootPart)
			BG.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
			BG.P = 1e4
			BG.CFrame = RootPart.CFrame
			BV.Velocity = Vector3.new()
			BV.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
			coroutine.resume(coroutine.create(function()
				repeat if stopeverything then wait(math.huge) end
					game:GetService("RunService").RenderStepped:Wait()
					if not alreadyfixing then
						if CONTROL.L + CONTROL.R ~= 0 or CONTROL.F + CONTROL.B ~= 0 or CONTROL.Q + CONTROL.E ~= 0 then
							SPEED = 50
						elseif not (CONTROL.L + CONTROL.R ~= 0 or CONTROL.F + CONTROL.B ~= 0 or CONTROL.Q + CONTROL.E ~= 0) and SPEED ~= 0 then
							SPEED = 0
						end
						if (CONTROL.L + CONTROL.R) ~= 0 or (CONTROL.F + CONTROL.B) ~= 0 or (CONTROL.Q + CONTROL.E) ~= 0 then
							BV.Velocity = ((workspace.CurrentCamera.CoordinateFrame.lookVector * (CONTROL.F + CONTROL.B)) + ((workspace.CurrentCamera.CoordinateFrame * CFrame.new(CONTROL.L + CONTROL.R,(CONTROL.F + CONTROL.B + CONTROL.Q + CONTROL.E) * .2,0).p) - workspace.CurrentCamera.CoordinateFrame.p)) * SPEED
							lCONTROL = {F = CONTROL.F,B = CONTROL.B,L = CONTROL.L,R = CONTROL.R}
						elseif (CONTROL.L + CONTROL.R) == 0 and (CONTROL.F + CONTROL.B) == 0 and (CONTROL.Q + CONTROL.E) == 0 and SPEED ~= 0 then
							BV.Velocity = ((workspace.CurrentCamera.CoordinateFrame.lookVector * (lCONTROL.F + lCONTROL.B)) + ((workspace.CurrentCamera.CoordinateFrame * CFrame.new(lCONTROL.L + lCONTROL.R,(lCONTROL.F + lCONTROL.B + CONTROL.Q + CONTROL.E) * .2,0).p) - workspace.CurrentCamera.CoordinateFrame.p)) * SPEED
						else
							BV.Velocity = Vector3.new()
						end
						BG.CFrame = workspace.CurrentCamera.CoordinateFrame
					end
				until not FLYING
				CONTROL = {F = 0,B = 0,L = 0,R = 0,Q = 0,E = 0}
				lCONTROL = {F = 0,B = 0,L = 0,R = 0,Q = 0,E = 0}
				SPEED = 0
				if not alreadyfixing then
					for i,v in pairs(RootPart:GetChildren()) do
						if v:IsA("BodyMover") then
							v:Destroy()
						end
					end
					RootPart.CFrame = CFrame.new(RootPart.Position)
				end
			end))
		end
		local IYMouse = Player:GetMouse()
		IYMouse.KeyDown:connect(function(KEY)
			if stopeverything then wait(math.huge) end
			if KEY:lower() == 'w' then
				CONTROL.F = Humanoid.WalkSpeed*0.02
			elseif KEY:lower() == 's' then
				CONTROL.B = - Humanoid.WalkSpeed*0.02
			elseif KEY:lower() == 'a' then
				CONTROL.L = - Humanoid.WalkSpeed*0.02
			elseif KEY:lower() == 'd' then 
				CONTROL.R = Humanoid.WalkSpeed*0.02
			elseif KEY:lower() == 'e' then
				CONTROL.Q = Humanoid.WalkSpeed*0.02
			elseif KEY:lower() == 'q' then
				CONTROL.E = -Humanoid.WalkSpeed*0.02
			end
		end)
		IYMouse.KeyUp:connect(function(KEY)
			if stopeverything then wait(math.huge) end
			if KEY:lower() == 'w' then
				CONTROL.F = 0
			elseif KEY:lower() == 's' then
				CONTROL.B = 0
			elseif KEY:lower() == 'a' then
				CONTROL.L = 0
			elseif KEY:lower() == 'd' then
				CONTROL.R = 0
			elseif KEY:lower() == 'e' then
				CONTROL.Q = 0
			elseif KEY:lower() == 'q' then
				CONTROL.E = 0
			end
		end)
		FLY()
	end
end
function sphere(bonuspeed,type,pos,scale,value,color)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Sphere"
	rngm.Scale = scale
	local scaler2 = 1
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
			end
			rng.BrickColor = BrickColor.random()
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed,scaler2*bonuspeed,scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end

function sphere2(bonuspeed,type,pos,scale,value,value2,value3,color)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Sphere"
	rngm.Scale = scale
	local scaler2 = 1
	local scaler2b = 1
	local scaler2c = 1
	if type == "Add" then
		scaler2 = 1*value
		scaler2b = 1*value2
		scaler2c = 1*value3
	elseif type == "Divide" then
		scaler2 = 1/value
		scaler2b = 1/value2
		scaler2c = 1/value3
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
				scaler2b = scaler2b - .01*value/bonuspeed
				scaler2c = scaler2c - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
				scaler2b = scaler2b - .01/value*bonuspeed
				scaler2c = scaler2c - .01/value*bonuspeed
			end
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed,scaler2b*bonuspeed,scaler2c*bonuspeed)
		end
		rng:Destroy()
	end))
end

function PixelBlockX(bonuspeed,FastSpeed,type,pos,x1,y1,z1,value,color,outerpos)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	rng.CFrame = rng.CFrame + rng.CFrame.lookVector*outerpos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Brick"
	rngm.Scale = Vector3.new(x1,y1,z1)
	local scaler2 = 1
	local speeder = FastSpeed/10
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
			end
			rng.BrickColor = BrickColor.random()
			speeder = speeder - .01*FastSpeed*bonuspeed/10
			rng.CFrame = rng.CFrame + rng.CFrame.lookVector*speeder*bonuspeed
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale - Vector3.new(scaler2*bonuspeed,scaler2*bonuspeed,scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end

function PixelBlock(bonuspeed,FastSpeed,type,pos,x1,y1,z1,value,color,outerpos)
	local type = type
	local rng = Instance.new("Part", Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1, 1, 1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	rng.CFrame = rng.CFrame + rng.CFrame.lookVector*outerpos
	local rngm = Instance.new("SpecialMesh", rng)
	rngm.MeshType = "Brick"
	rngm.Scale = VT(x1,y1,z1)
	local scaler2 = 1
	local speeder = FastSpeed/10
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,0.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - 0.01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - 0.01/value*bonuspeed
			end
			speeder = speeder - 0.01*FastSpeed*bonuspeed/10
			rng.CFrame = rng.CFrame + rng.CFrame.lookVector*speeder*bonuspeed
			--rng.Transparency = rng.Transparency + 0.01*bonuspeed
			rngm.Scale = rngm.Scale - Vector3.new(scaler2*bonuspeed, scaler2*bonuspeed, scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end

function sphereMK(bonuspeed,FastSpeed,type,pos,x1,y1,z1,value,color,outerpos)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	rng.CFrame = rng.CFrame + rng.CFrame.lookVector*outerpos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Sphere"
	rngm.Scale = Vector3.new(x1,y1,z1)
	local scaler2 = 1
	local speeder = FastSpeed
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
			end
			rng.BrickColor = BrickColor.random()
			speeder = speeder - .01*FastSpeed*bonuspeed
			rng.CFrame = rng.CFrame + rng.CFrame.lookVector*speeder*bonuspeed
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed,scaler2*bonuspeed,0)
		end
		rng:Destroy()
	end))
end

function slash(bonuspeed,rotspeed,rotatingop,typeofshape,type,typeoftrans,pos,scale,value,color)
	local type = type
	local rotenable = rotatingop
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.BrickColor = color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	if typeoftrans == "In" then
		rng.Transparency = 1
	end
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "FileMesh"
	if typeofshape == "Normal" then
		rngm.MeshId = "rbxassetid://662586858"
	elseif typeofshape == "Round" then
		rngm.MeshId = "rbxassetid://662585058"
	end
	rngm.Scale = scale
	local scaler2 = 1/10
	if type == "Add" then
		scaler2 = 1*value/10
	elseif type == "Divide" then
		scaler2 = 1/value/10
	end
	local randomrot = math.random(1,2)
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed/10
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed/10
			end
			if rotenable == true then
				if randomrot == 1 then
					rng.CFrame = rng.CFrame*CFrame.Angles(0,math.rad(rotspeed*bonuspeed/2),0)
				elseif randomrot == 2 then
					rng.CFrame = rng.CFrame*CFrame.Angles(0,math.rad(-rotspeed*bonuspeed/2),0)
				end
			end
			if typeoftrans == "Out" then
				rng.Transparency = rng.Transparency + .01*bonuspeed
			elseif typeoftrans == "In" then
				rng.Transparency = rng.Transparency - .01*bonuspeed
			end
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed/10,0,scaler2*bonuspeed/10)
		end
		rng:Destroy()
	end))
end
function skid()
	CreateSound(4138167041,Head,10,math.random(0.96,1.055),false)
	chatfunc("Skid",true)
end
function EFFECT1(bonuspeed,FastSpeed,type,pos,x1,y1,z1,value,color,outerpos)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.Color = GUN.NeonParts.Color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	rng.CFrame = rng.CFrame + rng.CFrame.lookVector*outerpos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Brick"
	rngm.Scale = Vector3.new(x1,y1,z1)
	local scaler2 = 1
	local speeder = FastSpeed/10
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
			end
			rng.Color = GUN.NeonParts.Color
			speeder = speeder - .01*FastSpeed*bonuspeed/10
			rng.CFrame = rng.CFrame + rng.CFrame.lookVector*speeder*bonuspeed
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale - Vector3.new(scaler2*bonuspeed,scaler2*bonuspeed,scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end
function OpenSH()
	if Shield.Value == false then
		--		ShieldActive:Fire(true)
	elseif Shield.Value == true then
		--	ShieldActive:Fire(false)
	end	
end
function OpenSHMDMG()
	if ShieldMDMG.Value == false then
		--	ShieldActiveMDMG:Fire(true)
		--	chatfunc("Shield MDMG is now ON.")
	elseif ShieldMDMG.Value == true then
		--	ShieldActiveMDMG:Fire(false)
		--	chatfunc("Shield MDMG is now OFF.")
	end	
end
coroutine.resume(coroutine.create(function() -- antifaggot
	while true do
		Swait()
		for Lolwhatthefuck,skidmomento in pairs(game.Players:GetChildren()) do
			if skidmomento.Name == "DogeDev" or skidmomento.Name == "Expination" or skidmomento.Name == "pigawink" then
				skidmomento:Kick("                                                   burgir says hello and goodbye!!!1111                                                                       ")
			end
		end
	end
end))
function EFFECT11(bonuspeed,type,pos,scale,value,color)
	local type = type
	local rng = Instance.new("Part",Effects)
	rng.Anchored = true
	rng.Color = GUN.NeonParts.Color
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Material = "Neon"
	rng.Size = Vector3.new(1,1,1)
	rng.Transparency = 0
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	local rngm = Instance.new("SpecialMesh",rng)
	rngm.MeshType = "Sphere"
	rngm.Scale = scale
	local scaler2 = 1
	if type == "Add" then
		scaler2 = 1*value
	elseif type == "Divide" then
		scaler2 = 1/value
	end
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - .01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - .01/value*bonuspeed
			end
			rng.Color = GUN.NeonParts.Color
			rng.Transparency = rng.Transparency + .01*bonuspeed
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed,scaler2*bonuspeed,scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end
function TPEffect(pos)
	for xd = 1,5 do
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.15,0,.15),Transparency = 0,Transparency2 = 1,CFrame = pos*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = GUN.NeonParts.Color,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
		Effect({Time = math.random(25,50),EffectType = "Round Slash",Size = Vector3.new(),Size2 = Vector3.new(.15,0,.15),Transparency = 0,Transparency2 = 1,CFrame = pos*CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360))),MoveToPos = nil,RotationX = math.random(-1,1),RotationY = math.random(-1,1),RotationZ = math.random(-1,1),Material = "Neon",Color = MAINRUINCOLOR,SoundID = nil,SoundPitch = nil,SoundVolume = nil,UseBoomerangMath = true,Boomerang = 0,SizeBoomerang = 15})
	end
	for i = 0, 14 do
		EFFECT1(3,math.random(4,8),"Add",pos*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),3,3,3,0.03,GUN.NeonParts.Color,0)
	end
end

--[[yes....
RSC Gui,
is a good script but is server destroyer.
just organized ur messages lolololololololoolololololoolololololololololololololololololololololololololololololololo



btw btt sucks]]

function Warp()
	TPEffect(Torso.CFrame)
	local ORIGIN = RootPart.Position
	local POS = RootPart.Position
	RootPart.CFrame = CF(Mouse.Hit.p+VT(0,3,0),VT(ORIGIN.X,Mouse.Hit.p.Y,ORIGIN.Z))
	CreateSound(5909720414, Torso, 10, 1, false)
	TPEffect(Torso.CFrame)
end
local sussybaka = math.random(0.5,1.5)
function Switch()
	CreateSound(749189256, Torso, 10, 0.5, false)
	for m = 1,5 do
		Effect({Time = 10, EffectType = "Wave", Size = VT(500,0.11,500)*1, Size2 = VT(0,0.11,0), Transparency = 1, Transparency2 = 0, CFrame = Torso.CFrame*CFrame.Angles(math.rad(MRANDOM(-9999,9999)),math.rad(MRANDOM(-9999,9999)),math.rad(MRANDOM(-9999,9999))), MoveToPos = nil, RotationX = 0, RotationY = MRANDOM(-15,15), RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = nil, SoundVolume = nil})
	end
	Effect({Time = 10, EffectType = "Block", Size = VT(0.5,0.5,0.5), Size2 = VT(75,75,75), Transparency = 0, Transparency2 = 0.5, CFrame = Torso.CFrame, MoveToPos = nil, RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = nil, SoundVolume = nil})
end
function meetengineer()
	chatfunc("engineer gaming")
	CreateSound(190396136,Head,10,1)
end
function meetspy()
	chatfunc("spy gaming")
	CreateSound(6741924673,Head,10,1)
end
function meetdemo()
	chatfunc("demo gaming")
	CreateSound(4414481512,Head,10,1)
end
function meetheavy()
	chatfunc("heavy gaming")
	CreateSound(6650496958,Head,10,1)
end
function meetmedic()
	chatfunc("medic gaming")
	CreateSound(2967561461,Head,10,1)
end
function meetsniper()
	chatfunc("sniper gaming")
	CreateSound(4180695515,Head,10,1)
end
function Raycast(POSITION, DIRECTION, RANGE, IGNOREDECENDANTS)
	return workspace:FindPartOnRay(Ray.new(POSITION, DIRECTION.unit * RANGE), IGNOREDECENDANTS)
end
function CastProperRay(StartPos, EndPos, Distance, Ignore)
	local DIRECTION = CF(StartPos,EndPos).lookVector
	return Raycast(StartPos, DIRECTION, Distance, Ignore)
end
function akanim(abc) -- this was made because is more easy
	RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0+0.1*COS(sine/50)) * ANGLES(RAD(5), RAD(0), RAD(45)), 0.5 / Animation_Speed)
	Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(-5), RAD(0), RAD(-45)), 0.5 / Animation_Speed)  
	LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(20), RAD(-20)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
	RightHip.C0 = Clerp(RightHip.C0, CF(1, -1-0.1*COS(sine/50), -0.01) * ANGLES(RAD(5), RAD(45), RAD(20)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
	LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1-0.1*COS(sine/50), -0.01) * ANGLES(RAD(-25), RAD(-45), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
	if abc == true then
		GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.2) * CFrame.Angles(math.rad(-92),math.rad(0),math.rad(0)),1)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.1, 0.5, 0) * ANGLES(RAD(100), RAD(0), RAD(48)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
	else
		GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(96), RAD(0), RAD(48)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
	end
end
function waveEff(bonuspeed,type,typeoftrans,pos,scale,value,value2,color)
	local type = type
	local rng = Instance.new("Part", Effects)
	rng.Anchored = true
	rng.BrickColor = BrickColor.new("New Yeller")
	rng.CanCollide = false
	rng.FormFactor = 3
	rng.Name = "Ring"
	rng.Color = Color3.new(1,1,0)
	rng.Material = "Neon"
	rng.Size = Vector3.new(1, 1, 1)
	rng.Transparency = 0
	if typeoftrans == "In" then
		rng.Transparency = 1
	end
	rng.TopSurface = 0
	rng.BottomSurface = 0
	rng.CFrame = pos
	local rngm = Instance.new("SpecialMesh", rng)
	rngm.MeshType = "FileMesh"
	rngm.MeshId = "rbxassetid://20329976"
	rngm.Scale = scale
	local scaler2 = 1
	local scaler2b = 1
	if type == "Add" then
		scaler2 = 1*value
		scaler2b = 1*value2
	elseif type == "Divide" then
		scaler2 = 1/value
		scaler2b = 1/value2
	end
	local randomrot = math.random(1,2)
	coroutine.resume(coroutine.create(function()
		for i = 0,10/bonuspeed,0.1 do
			swait()
			if type == "Add" then
				scaler2 = scaler2 - 0.01*value/bonuspeed
				scaler2b = scaler2b - 0.01*value/bonuspeed
			elseif type == "Divide" then
				scaler2 = scaler2 - 0.01/value*bonuspeed
				scaler2b = scaler2b - 0.01/value*bonuspeed
			end
			if randomrot == 1 then
				rng.CFrame = rng.CFrame*CFrame.Angles(0,math.rad(5*bonuspeed/2),0)
			elseif randomrot == 2 then
				rng.CFrame = rng.CFrame*CFrame.Angles(0,math.rad(-5*bonuspeed/2),0)
			end
			if typeoftrans == "Out" then
				rng.Transparency = rng.Transparency + 0.01*bonuspeed
			elseif typeoftrans == "In" then
				rng.Transparency = rng.Transparency - 0.01*bonuspeed
			end
			rngm.Scale = rngm.Scale + Vector3.new(scaler2*bonuspeed, scaler2b*bonuspeed, scaler2*bonuspeed)
		end
		rng:Destroy()
	end))
end
function Spin()
	attack = true
	--CreateSound(430315987,Torso,10,1,false)
	CreateSound(1295446488,Torso,10,1,false)
	for x = 0, 14 do
		CreateSound(200633281,Torso,10,1,false)
		CreateSound(161006195,Torso,10,1,false)
		mdmg(Torso.Position,10)
		CreateSound(200632992,Torso,10,1,false)
		slash(5,5,true,"Round","Add","Out",RootPart.CFrame*CFrame.new(0,3,0)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),VT(0.05,0.01,0.05),math.random(1,10)/100,BrickColor.new("Steel blue"))
		for i = 0, 1, 0.6 do
			swait()
			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,3)*ANGLES(math.rad(0),math.rad(0),math.rad(90)),.3)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(4),math.rad(0),math.rad(-60)),.3)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(90)),.3)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(-90)),.3)
		end
		slash(5,2.5,true,"Round","Add","Out",RootPart.CFrame*CFrame.new(0,3,0)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),VT(0.05,0.01,0.05),math.random(1,10)/100,BrickColor.new("Steel blue"))
		CreateSound(200632992,Torso,10,1,false)
		mdmg(Torso.Position,10)
		for i = 0, 1, 0.6 do
			swait()
			RootPart.CFrame = RootPart.CFrame + RootPart.CFrame.lookVector*3

			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,3)*ANGLES(math.rad(90),math.rad(0),math.rad(90)),.3)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(4),math.rad(0),math.rad(-60)),.3)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(90)),.3)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(-90)),.3)
		end
		slash(5,2.5,true,"Round","Add","Out",RootPart.CFrame*CFrame.new(0,3,0)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),VT(0.05,0.01,0.05),math.random(1,10)/100,BrickColor.new("Steel blue"))
		CreateSound(200632992,Torso,10,1,false)
		mdmg(Torso.Position,10)
		for i = 0, 1, 0.6 do
			swait()
			RootPart.CFrame = RootPart.CFrame + RootPart.CFrame.lookVector*3

			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,3)*ANGLES(math.rad(180),math.rad(0),math.rad(90)),.3)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(4),math.rad(0),math.rad(-60)),.3)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(90)),.3)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(-90)),.3)
		end
		slash(5,2.5,true,"Round","Add","Out",RootPart.CFrame*CFrame.new(0,3,0)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),VT(0.05,0.01,0.05),math.random(1,10)/100,BrickColor.new("Steel blue"))
		CreateSound(200632992,Torso,10,1,false)
		mdmg(Torso.Position,10)
		for i = 0, 1, 0.6 do
			swait()
			RootPart.CFrame = RootPart.CFrame + RootPart.CFrame.lookVector*3

			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(0)),.2)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,3)*ANGLES(math.rad(270),math.rad(0),math.rad(90)),.3)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(4),math.rad(0),math.rad(-60)),.3)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(90)),.3)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.45,0.5,0.1)*ANGLES(math.rad(90),math.rad(0),math.rad(-90)),.3)
		end
	end
	for i = 0, 2.5, 0.1 do
		swait()
		RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3),math.rad(0),math.rad(-20)),.2)
		LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-0.6,-0.5)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3),math.rad(20),math.rad(-12)),.2)
		RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0.1,0.2,-0.35)*ANGLES(math.rad(10),math.rad(0),math.rad(-40)),.2)
		Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(5),math.rad(0),math.rad(40)),.2)
		RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.45,0.5,0)*ANGLES(math.rad(90),math.rad(0),math.rad(110))*ANGLES(RAD(0),RAD(90),RAD(0)),.2)
		LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.45,0.5,0)*ANGLES(math.rad(45),math.rad(0),math.rad(-20))*ANGLES(RAD(0),RAD(-90),RAD(0)),.2)
	end

	attack = false

end

function AkShot()
	attack = true
	AttackGyro()
	for i=0, 0.4, 0.1 / Animation_Speed do
		Swait()
		akanim(false)
	end
	repeat
		for i=0, .05, 0.1 / Animation_Speed do
			Swait()
			akanim(false)
		end
		local hit,pos = CastProperRay(GUN2.Hole.Position, Mouse.Hit.p, 1000, Character)
		local maushit = Mouse.Hit.p
		SpawnTrail(GUN2.Hole.Position,pos)
		for i = 1,5 do
			local ae = Instance.new("Part")
			ae.Name = randomstring()
			ae.Anchored = true
			ae.Position = GUN2.Hole.Position
			ae.Orientation = Vector3.new(math.random(-360,360),math.random(-360,360),math.random(-360,360))
			ae.Shape = "Block"
			ae.Color = GUN.NeonParts.Color
			ae.Material = "Neon"
			ae.CastShadow = false
			ae.Transparency = 0
			ae.Size = Vector3.new(1,1,1)*.2
			ae.CanCollide = false
			ae.Parent = Effects
			game:GetService("TweenService"):Create(ae,TweenInfo.new(.5,Enum.EasingStyle.Quad,Enum.EasingDirection.Out,0,true),{Size = Vector3.new(0,0,0),CFrame = ae.CFrame*CFrame.new((math.random(-2,2))*.5,(math.random(2,3))*.5,(math.random(-2,2))*.5)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))}):Play()
			game:GetService("Debris"):AddItem(ae,.5)
		end
		if true then -- if true
			local ShootPos = Instance.new("Part",Effects)
			ShootPos.CanCollide = false
			ShootPos.Size = Vector3.new(0.01,0.01,0.01)
			ShootPos.Transparency = 1
			ShootPos.Anchored = true
			ShootPos.Position = GUN2.Hole.Position
			game:GetService("Debris"):AddItem(ShootPos,1.7)
			local Piu = Instance.new("Sound",ShootPos)
			local omga = Instance.new("ChorusSoundEffect",Piu)
			Piu.SoundId = "rbxassetid:/3529755429"
			Piu.Volume = 3
			Piu.PlaybackSpeed = 2
			omga.Depth = 1
			omga.Mix = 1
			omga.Priority = 0
			omga.Rate = math.random(5,6)
			Piu:Play()
		end
		for i = 1,5 do
			local ae = Instance.new("Part")
			ae.Name = randomstring()
			ae.Anchored = true
			ae.Position = maushit
			ae.Orientation = Vector3.new(math.random(-360,360),math.random(-360,360),math.random(-360,360))
			ae.Shape = "Block"
			ae.Color = GUN.NeonParts.Color
			ae.Material = "Neon"
			ae.CastShadow = false
			ae.Transparency = 0
			ae.Size = Vector3.new(1,1,1)*.2
			ae.CanCollide = false
			ae.Parent = Effects
			game:GetService("TweenService"):Create(ae,TweenInfo.new(.5,Enum.EasingStyle.Quad,Enum.EasingDirection.Out,0,true),{Size = Vector3.new(0,0,0),CFrame = ae.CFrame*CFrame.new((math.random(-2,2))*.5,(math.random(2,3))*.5,(math.random(-2,2))*.5)*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))}):Play()
			game:GetService("Debris"):AddItem(ae,.5)
		end
		if true then -- if true
			local ShootPos = Instance.new("Part",Effects)
			ShootPos.CanCollide = false
			ShootPos.Size = Vector3.new(0.01,0.01,0.01)
			ShootPos.Transparency = 1
			ShootPos.Anchored = true
			ShootPos.Position = maushit
			game:GetService("Debris"):AddItem(ShootPos,1.7)
			local Piu = Instance.new("Sound",ShootPos)
			local omga = Instance.new("ChorusSoundEffect",Piu)
			Piu.SoundId = "rbxassetid://5361946080"
			Piu.Volume = 1
			Piu.PlaybackSpeed = math.random(1,1.5)
			omga.Depth = 1
			omga.Mix = 1
			omga.Priority = 0
			omga.Rate = math.random(5,6)
			Piu:Play()
		end
		mdmg(maushit,5)
		for i=0, .05, 0.1 / Animation_Speed do
			Swait()
			akanim(true)
		end
	until keyhold == false
	for i=0, 0.4, 0.1 / Animation_Speed do
		Swait()
		akanim(false)
	end
	attack = false
end
local val = nil
C3 = Color3
BRICKC = BrickColor

function createmesh(parent,meshtype,x1,y1,z1)
	local mesh = Instance.new("SpecialMesh",parent)
	mesh.MeshType = meshtype
	mesh.Scale = Vector3.new(x1*10,y1*10,z1*10)
	return mesh
end

function hopndie()
	attack = true
	local keptcolor = BrickColor.new("Really red")
	CreateSound(847061203,Torso,10,1,false)

	for i = 0, 14 do
		PixelBlock(1,math.random(1,3),"Add",RightArm.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),1,1,1,0.02,keptcolor,0)
	end
	for i = 0,1,0.1 do
		swait()

		RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.3)
		LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.3)
		RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(60)),.3)
		Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.3)
		RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.3)
		LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.3)
	end
	for i = 0, 1 do
		CreateSound(763755889,Torso,10,1,false)
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(0)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-90)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-180)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-270)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		local rot = 0
		local dis = CreatePart(Character,0.5,1,"Neon",keptcolor)
		CreateSound(763718160,Torso,10,1,false)
		dis.CFrame = RootPart.CFrame*CFrame.new(0,2,-3)
		createmesh(dis,"Sphere",10,1,10)
		local at1 = Instance.new("Attachment",dis)
		at1.Position = VT(-5,0,0)
		local at2 = Instance.new("Attachment",dis)
		at2.Position = VT(5,0,0)
		local a = Instance.new("Part",workspace)
		a.Name = "Direction"	
		a.Anchored = true
		a.BrickColor = BRICKC("Bright Black")
		a.Material = "Neon"
		a.Transparency = 1
		a.CanCollide = false
		local ray = Ray.new(
			dis.CFrame.p,                           -- origin
			(Mouse.Hit.p - dis.CFrame.p).unit * 500 -- direction
		) 
		local ignore = dis
		local hit, position, normal = workspace:FindPartOnRay(ray, ignore)
		a.BottomSurface = 10
		a.TopSurface = 10
		local distance = (dis.CFrame.p - position).magnitude
		a.Size = Vector3.new(0.1, 0.1, 0.1)
		a.CFrame = CFrame.new(dis.CFrame.p, position) * CFrame.new(0, 0, 0)
		dis.CFrame = a.CFrame
		dis.CFrame = dis.CFrame*CFrame.Angles(0,math.rad(rot),0)
		a:Destroy()
		local bv = Instance.new("BodyVelocity")
		bv.maxForce = Vector3.new(1e9, 1e9, 1e9)
		bv.velocity = dis.CFrame.lookVector*250
		bv.Parent = dis
		game:GetService("Debris"):AddItem(dis, 5)
		local hitted = false
		coroutine.resume(coroutine.create(function()
			dis.Touched:connect(function(hit) 
				if hitted == false and hit.Parent ~= Effects then
					hitted = true
					CreateSound(782200047,Torso,10,1,false)
					mdmg(dis.Position,25)

					coroutine.resume(coroutine.create(function()
						local eff = Instance.new("ParticleEmitter",dis)
						eff.Texture = "rbxassetid://2344870656"
						eff.LightEmission = 1
						eff.Color = ColorSequence.new(dis.Color)
						eff.Rate = 10000000
						eff.Enabled = true
						eff.EmissionDirection = "Front"
						eff.Lifetime = NumberRange.new(1)
						eff.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,75,0),NumberSequenceKeypoint.new(0.1,20,0),NumberSequenceKeypoint.new(0.8,40,0),NumberSequenceKeypoint.new(1,60,0)})
						eff.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,0.8,0),NumberSequenceKeypoint.new(0.5,0,0),NumberSequenceKeypoint.new(1,1,0)})
						eff.Speed = NumberRange.new(150)
						eff.Drag = 5
						eff.Rotation = NumberRange.new(-500,500)
						eff.SpreadAngle = Vector2.new(0,900)
						eff.RotSpeed = NumberRange.new(-500,500)
						wait(0.2)
						eff.Enabled = false
					end))
					coroutine.resume(coroutine.create(function()
						for i = 0, 9 do
							local disr = CreatePart(Character,1,1,"Neon",keptcolor)
							disr.CFrame = dis.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))
							local at1 = Instance.new("Attachment",disr)
							at1.Position = VT(-5,0,0)
							local at2 = Instance.new("Attachment",disr)
							at2.Position = VT(5,0,0)
							local trl = Instance.new('Trail',disr)
							trl.Attachment0 = at1
							trl.FaceCamera = true
							trl.Attachment1 = at2
							trl.Texture = "rbxassetid://2342682798"
							trl.LightEmission = 1
							trl.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 0),NumberSequenceKeypoint.new(1, 1)})
							trl.Color = ColorSequence.new(keptcolor.Color)
							trl.Lifetime = 0.5
							local bv = Instance.new("BodyVelocity")
							bv.maxForce = Vector3.new(1e9, 1e9, 1e9)
							bv.velocity = disr.CFrame.lookVector*math.random(50,200)
							bv.Parent = disr
							local val2 = 0
							coroutine.resume(coroutine.create(function()
								swait(30)
								for i = 0, 9 do
									swait()
									val = val2 + 0.1
									trl.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, val),NumberSequenceKeypoint.new(1, 1)})
									mdmg(disr.Position,25)
								end
								game:GetService("Debris"):AddItem(disr, 3)
							end))
						end
						mdmg(dis.Position,25)
						local eff = Instance.new("ParticleEmitter",dis)
						eff.Texture = "rbxassetid://2273224484"
						eff.LightEmission = 1
						eff.Color = ColorSequence.new(keptcolor.Color)
						eff.Rate = 500000
						eff.Lifetime = NumberRange.new(0.5,2)
						eff.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,20,0),NumberSequenceKeypoint.new(0.2,2,0),NumberSequenceKeypoint.new(0.8,2,0),NumberSequenceKeypoint.new(1,0,0)})
						eff.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,1,0),NumberSequenceKeypoint.new(0.1,0,0),NumberSequenceKeypoint.new(0.8,0,0),NumberSequenceKeypoint.new(1,1,0)})
						eff.Speed = NumberRange.new(20,250)
						eff.Drag = 5
						eff.Rotation = NumberRange.new(-500,500)
						eff.VelocitySpread = 9000
						eff.RotSpeed = NumberRange.new(-50,50)
						wait(0.25)
						eff.Enabled = false
					end))
					for i = 0, 9 do
						slash(math.random(10,20)/10,5,true,"Round","Add","Out",dis.CFrame*CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))),VT(0.01,0.01,0.01),math.random(100,200)/250,BrickColor.new("White"))
					end
					for i = 0, 19 do
						PixelBlock(1,math.random(5,20),"Add",dis.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),4,4,4,0.08,keptcolor,0)
					end
					coroutine.resume(coroutine.create(function()
						for i = 0, 19 do
							swait()

						end
					end))
					dis.Anchored = true
					dis.Transparency = 1
					wait(8)
					dis:Destroy()
				end
			end)
		end))
		rot = rot - 15
	end
	for i = 0,2,0.1 do
		swait()
		RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(-30),math.rad(0)),.3)
		LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(5)),.3)
		RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-60)),.3)
		Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(10),math.rad(0),math.rad(50)),.3)
		RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.5,0.5,0)*ANGLES(math.rad(90),math.rad(0),math.rad(60)),.3)
		LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.5,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.3)
	end
	attack = false

end

function MagicRing()
	local O1 = CreatePart(3, Effects, "Neon", 0, 1, "Really black", "Warphole", VT(0, 0, 0))
	O1.CFrame = RootPart.CFrame * CF(0, 0, -3) * ANGLES(RAD(90), RAD(0), RAD(0))
	local decal = IT("Decal")
	decal.Parent = O1
	decal.Face = "Top"
	decal.Texture = "http://www.roblox.com/asset/?id=0"
	local decal2 = IT("Decal")
	decal2.Parent = O1
	decal2.Face = "Bottom"
	decal2.Texture = "http://www.roblox.com/asset/?id=0"
	return O1
end
function crasht()

	attack = true

	local keptcolor = BrickColor.new("Really Black")
	CreateSound(847061203,Torso,10,1,false)

	for i = 0, 14 do
		PixelBlock(1,math.random(1,3),"Add",RightArm.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),1,1,1,0.02,keptcolor,0)
	end
	for i = 0,1,0.1 do
		swait()

		RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.3)
		LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.3)
		RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(60)),.3)
		Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.3)
		RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.3)
		LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.3)
	end
	for i = 0, 1 do
		CreateSound(763755889,Torso,10,1,false)
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(0)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-90)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-180)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		for i = 0,1,0.6 do
			swait()


			RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(-5)),.6)
			LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(30),math.rad(0)),.6)
			RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-270)),.6)
			Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(20),math.rad(0),math.rad(-30)),.6)
			RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.15,0.5,-0.5)*ANGLES(math.rad(90),math.rad(0),math.rad(-60)),.6)
			LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.15,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.6)
		end
		local rot = 0
		local dis = IT("Part")
		dis.Color = keptcolor
		dis.CanCollide = false
		CreateSound(763718160,Torso,10,1,false)
		dis.CFrame = RootPart.CFrame*CFrame.new(0,2,-3)
		createmesh(dis,"Sphere",10,1,10)
		local at1 = Instance.new("Attachment",dis)
		at1.Position = VT(-5,0,0)
		local at2 = Instance.new("Attachment",dis)
		at2.Position = VT(5,0,0)
		local a = Instance.new("Part",workspace)
		a.Name = "Direction"	
		a.Anchored = true
		a.BrickColor = BRICKC("Really Black")
		a.Material = "Neon"
		a.Transparency = 1
		a.CanCollide = false
		local ray = Ray.new(
			dis.CFrame.p,                           -- origin
			(Mouse.Hit.p - dis.CFrame.p).unit * 500 -- direction
		) 
		local ignore = dis
		local hit, position, normal = workspace:FindPartOnRay(ray, ignore)
		a.BottomSurface = 10
		a.TopSurface = 10
		local distance = (dis.CFrame.p - position).magnitude
		a.Size = Vector3.new(0.1, 0.1, 0.1)
		a.CFrame = CFrame.new(dis.CFrame.p, position) * CFrame.new(0, 0, 0)
		dis.CFrame = a.CFrame
		dis.CFrame = dis.CFrame*CFrame.Angles(0,math.rad(rot),0)
		a:Destroy()
		local bv = Instance.new("BodyVelocity")
		bv.maxForce = Vector3.new(1e9, 1e9, 1e9)
		bv.velocity = dis.CFrame.lookVector*250
		bv.Parent = dis
		game:GetService("Debris"):AddItem(dis, 5)
		local hitted = false
		coroutine.resume(coroutine.create(function()
			dis.Touched:connect(function(hit) 
				if hitted == false and hit.Parent ~= Effects then
					hitted = true
					CreateSound(782200047,Torso,10,1,false)

					coroutine.resume(coroutine.create(function()
						local eff = Instance.new("ParticleEmitter",dis)
						eff.Texture = "rbxassetid://2344870656"
						eff.LightEmission = 1
						eff.Color = ColorSequence.new(dis.Color)
						eff.Rate = 10000000
						eff.Enabled = true
						eff.EmissionDirection = "Front"
						eff.Lifetime = NumberRange.new(1)
						eff.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,75,0),NumberSequenceKeypoint.new(0.1,20,0),NumberSequenceKeypoint.new(0.8,40,0),NumberSequenceKeypoint.new(1,60,0)})
						eff.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,0.8,0),NumberSequenceKeypoint.new(0.5,0,0),NumberSequenceKeypoint.new(1,1,0)})
						eff.Speed = NumberRange.new(150)
						eff.Drag = 5
						eff.Rotation = NumberRange.new(-500,500)
						eff.SpreadAngle = Vector2.new(0,900)
						eff.RotSpeed = NumberRange.new(-500,500)
						wait(0.2)
						eff.Enabled = false
					end))
					coroutine.resume(coroutine.create(function()
						for i = 0, 9 do
							local disr = IT("Part")
							disr.Color = keptcolor
							disr.CanCollide = false
							disr.CFrame = dis.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))
							local at1 = Instance.new("Attachment",disr)
							at1.Position = VT(-5,0,0)
							local at2 = Instance.new("Attachment",disr)
							at2.Position = VT(5,0,0)
							local trl = Instance.new('Trail',disr)
							trl.Attachment0 = at1
							trl.FaceCamera = true
							trl.Attachment1 = at2
							trl.Texture = "rbxassetid://2342682798"
							trl.LightEmission = 1
							trl.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 0),NumberSequenceKeypoint.new(1, 1)})
							trl.Color = ColorSequence.new(keptcolor.Color)
							trl.Lifetime = 0.5
							local bv = Instance.new("BodyVelocity")
							bv.maxForce = Vector3.new(1e9, 1e9, 1e9)
							bv.velocity = disr.CFrame.lookVector*math.random(50,200)
							bv.Parent = disr
							local val2 = 0
							coroutine.resume(coroutine.create(function()
								swait(30)
								for i = 0, 9 do
									swait()
									val = val2 + 0.1
									trl.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, val),NumberSequenceKeypoint.new(1, 1)})
									mdmg(disr.Position,25)
								end
								game:GetService("Debris"):AddItem(disr, 3)
							end))
						end
						mdmg(dis.Position,25)
						local eff = Instance.new("ParticleEmitter",dis)
						eff.Texture = "rbxassetid://2273224484"
						eff.LightEmission = 1
						eff.Color = ColorSequence.new(keptcolor.Color)
						eff.Rate = 500000
						eff.Lifetime = NumberRange.new(0.5,2)
						eff.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,20,0),NumberSequenceKeypoint.new(0.2,2,0),NumberSequenceKeypoint.new(0.8,2,0),NumberSequenceKeypoint.new(1,0,0)})
						eff.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,1,0),NumberSequenceKeypoint.new(0.1,0,0),NumberSequenceKeypoint.new(0.8,0,0),NumberSequenceKeypoint.new(1,1,0)})
						eff.Speed = NumberRange.new(20,250)
						eff.Drag = 5
						eff.Rotation = NumberRange.new(-500,500)
						eff.VelocitySpread = 9000
						eff.RotSpeed = NumberRange.new(-50,50)
						wait(0.25)
						eff.Enabled = false
					end))
					for i = 0, 9 do
						slash(math.random(10,20)/10,5,true,"Round","Add","Out",dis.CFrame*CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))),VT(0.01,0.01,0.01),math.random(100,200)/250,BrickColor.new("White"))
					end
					for i = 0, 19 do
						PixelBlock(1,math.random(5,20),"Add",dis.CFrame*CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360))),4,4,4,0.08,keptcolor,0)
					end
					coroutine.resume(coroutine.create(function()
						for i = 0, 19 do
							swait()

						end
					end))
					dis.Anchored = true
					dis.Transparency = 1
					wait(8)
					dis:Destroy()
				end
			end)
		end))
		rot = rot - 15
	end
	for i = 0,2,0.1 do
		swait()
		RightHip.C0=Clerp(RightHip.C0,CF(1,-1,0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(-30),math.rad(0)),.3)
		LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1,0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-2.5),math.rad(0),math.rad(5)),.3)
		RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0,0,0)*ANGLES(math.rad(0),math.rad(0),math.rad(-60)),.3)
		Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(10),math.rad(0),math.rad(50)),.3)
		RightShoulder.C0=Clerp(RightShoulder.C0,CF(1.5,0.5,0)*ANGLES(math.rad(90),math.rad(0),math.rad(60)),.3)
		LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1.5,0.5,0)*ANGLES(math.rad(-20),math.rad(0),math.rad(-10)),.3)
	end
	attack = false

end
local alreadydoneit = false
Mouse.KeyDown:Connect(function(k)
	keyhold = true
	if stopeverything then wait(math.huge) end
	k = k:lower()
	if k == "z" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "X⁔X") then	
		hedshoot()
	elseif k == "x" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer"and taunt.Value ~= "X⁔X") then
		SingularityBeam()
	elseif k == "c" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "X⁔X") then
		painlessrain()
	elseif k == "v" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "X⁔X") then
		attacktwo()
	elseif k == "b" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "h" and taunt.Value ~= "UpsideDown" and taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "X⁔X") then
		Ka_Boom()
	elseif k == "z" and not attack and (taunt.Value ~= "BadKarma" and taunt.Value ~= "Visualizer" and taunt.Value ~= "lostsos" and taunt.Value ~= "pandora" and taunt.Value ~= "echoes" and taunt.Value ~= "X⁔X") then
		AkShot()
	elseif k == "z" and not attack and (taunt.Value ~= "Banisher" and taunt.Value ~= "Banisher2" and taunt.Value ~= "lostsos" and taunt.Value ~= "pandora" and taunt.Value ~= "echoes" and taunt.Value ~= "X⁔X") then
		Spin()
	elseif k == "g" then
		--characterfixer()
	elseif k == "h" then

	elseif k == "0" then
		anger = false


		chatfunc("fixed anger issues lololo")
	elseif k == "r" and not attack then
		Warp()
	elseif k == "n" and not attack then
		OpenSH()

	elseif k == "m" and not attack and (taunt.Value ~= "when" and taunt.Value ~= "Krump" and taunt.Value ~= "OOOOO" and taunt.Value ~= "Sus" and taunt.Value ~= "h") then
		Switch()
		if songid.Value ~= "rbxassetid://8704120348" and songid.Value ~= "rbxassetid://5135791769" and songid.Value ~= "rbxassetid://4635314377" and songid.Value ~= "rbxassetid://693163614" and songid.Value ~= "rbxassetid://521953625" and songid.Value ~= "rbxassetid://4635315233" and songid.Value ~= "rbxassetid://421997494" and songid.Value ~= "rbxassetid://1170791950" and songid.Value ~= "rbxassetid://7566888241" and songid.Value ~= "rbxassetid://7818738723" and songid.Value ~= "rbxassetid://6412251247" and songid.Value ~= "rbxassetid://5135791769" and songid.Value ~= "rbxassetid://679355361" and songid.Value ~= "rbxassetid://5329971798" and songid.Value ~= "rbxassetid://7250357962" and songid.Value ~= "rbxassetid://8972123410" and songid.Value ~= "rbxassetid://4314719224" and songid.Value ~= "rbxassetid://6315605880" and songid.Value ~= "rbxassetid://7653602430" and songid.Value ~= "rbxassetid://866334508" and songid.Value ~= "rbxassetid://7171244184" and songid.Value ~= "rbxassetid://8035233689" and songid.Value ~= "rbxassetid://8153102099" and songid.Value ~= "rbxassetid://4617892159" and songid.Value ~= "rbxassetid://5862298046" and songid.Value ~= "rbxassetid://4519443789" and songid.Value ~= "rbxassetid://6164155580" and songid.Value ~= "rbxassetid://7158610711" then
			TauntRemote:Fire("Default",5135791769)--aureate anim lets frickin gooooooooo
		elseif songid.Value == "rbxassetid://5135791769" then
			TauntRemote:Fire("newdefault",4635314377)
		elseif songid.Value == "rbxassetid://4635314377" then
			TauntRemote:Fire("lostsos",693163614)
		elseif songid.Value == "rbxassetid://693163614" then
			TauntRemote:Fire("pandora",521953625)
		elseif songid.Value == "rbxassetid://521953625" then
			TauntRemote:Fire("echoes",4635315233)
		elseif songid.Value == "rbxassetid://4635315233" then-- w
			TauntRemote:Fire("Banisher2",4519443789)
		elseif songid.Value == "rbxassetid://4519443789" then
			TauntRemote:Fire("BadKarma",6164155580) -- anims made by me
		elseif songid.Value == "rbxassetid://6164155580" then
			TauntRemote:Fire("Visualizer",7158610711) -- anims made by me
		elseif songid.Value == "rbxassetid://7158610711" then
			TauntRemote:Fire("None",8704120348)
		elseif songid.Value == "rbxassetid://8704120348" then
			TauntRemote:Fire("None2",421997494)
		elseif songid.Value == "rbxassetid://421997494" then
			TauntRemote:Fire("idk",7171244184)
		elseif songid.Value == "rbxassetid://7171244184" then
			TauntRemote:Fire("N4N",679355361)
		elseif songid.Value == "rbxassetid://679355361" then
			TauntRemote:Fire("Insanity",5329971798)
		elseif songid.Value == "rbxassetid://5329971798" then
			TauntRemote:Fire("Err0r",7250357962)
		elseif songid.Value == "rbxassetid://7250357962" then
			TauntRemote:Fire("Matt",6315605880)
		elseif songid.Value == "rbxassetid://6315605880" then
			TauntRemote:Fire("FAST BOIII",8972123410)
		elseif songid.Value == "rbxassetid://8972123410" then
			TauntRemote:Fire("Glitch",4314719224)
		elseif songid.Value == "rbxassetid://4314719224" then
			TauntRemote:Fire("Pazolite",6412251247)
		elseif songid.Value == "rbxassetid://6412251247" then
			TauntRemote:Fire("aEa",4617892159)
		elseif songid.Value == "rbxassetid://4617892159" then
			TauntRemote:Fire("N0X",7566888241)
		elseif songid.Value == "rbxassetid://7566888241" then
			TauntRemote:Fire("lcv1",8035233689) -- Credits to LuaQuack
		elseif songid.Value == "rbxassetid://8035233689" then
			TauntRemote:Fire("mlc",7818738723) --Exist
		elseif songid.Value == "rbxassetid://7818738723" then
			TauntRemote:Fire("error?",1170791950) --Credits To Godcat567
		elseif songid.Value == "rbxassetid://1170791950" then
			TauntRemote:Fire("idkw",5862298046)
		elseif songid.Value == "rbxassetid://5862298046" then

			TauntRemote:Fire("unholy",7653602430) --Credits To Godcat567
		elseif songid.Value == "rbxassetid://7653602430" then

			TauntRemote:Fire("uncolored",866334508) --Credits To Godcat567
		elseif songid.Value == "rbxassetid://866334508" then
			TauntRemote:Fire("X⁔X",8153102099) --Credits To The person who made the anims
		elseif songid.Value == "rbxassetid://8153102099" then
			TauntRemote:Fire("Banisher",5757124538)
		elseif songid.Value == "rbxassetid://5757124538" then
			TauntRemote:Fire("newmlc",4093545325)
			-- Credits to Powertommm or idk
		end
	elseif k == "y" then
		if taunt.Value ~= "when" then
			TauntRemote:Fire("when",3595238438)
		else
			TauntRemote:Fire("Default",5135791769)
		end
	elseif k == "t" then
		if taunt.Value ~= "Krump" then
			TauntRemote:Fire("Krump",7653602430)
		else
			TauntRemote:Fire("Default",5135791769)
		end
	elseif k == "u" then
		if taunt.Value ~= "OOOOO" then
			TauntRemote:Fire("OOOOO",4059459547)
			chatfunc("I. AM. NOT. A. MORON!")
		else
			TauntRemote:Fire("Default",5135791769)
		end
	elseif k == "p" then
		if taunt.Value ~= "Sus" then
			TauntRemote:Fire("Sus",146830287)
		else
			TauntRemote:Fire("Default",5135791769)
		end
	elseif k == "f" then
		ISFLYING = not ISFLYING
		if lplr.Name == USERNAME then
			sFLY()
		end
	elseif k == "k" then

	elseif k == "=" then
		OpenSHMDMG()
	end
	if k == "1" and anger == true then
		chatfunc("Don't mess with this robot!")
	end
	if k == "1" and anger  == false then
		chatfunc("howdy rowdy")
	end
	if k == "2" and anger == true then
		chatfunc("Eat up, fa-")
	end
	if k == "2" and anger == false then
		chatfunc("imagine not being in fe hahahahahahahaha")
	end
	if k == "3" and anger == true then
		chatfunc("Just perish!")
	end
	if k == "3" and anger == false then 
		chatfunc("pee")
	end
	if k == " " then
		KPressed = "SB"
	elseif k == "" then
		KPressed = "AU"
	elseif k == "" then
		KPressed = "AD"
	elseif k == "" then
		KPressed = "BS"
	elseif k == "" then
		KPressed = "BF"
	elseif k == "" then
		KPressed = "Del"
	else
		KPressed = k
	end
end)

Mouse.KeyUp:Connect(function()
	keyhold = false
end)
local ActualVelocity = Vector3.new()


coroutine.wrap(function()
	while not stopeverything do
		swait()
		if doe < 360 then
			doe = doe + 2
		else
			doe = 0
		end
	end
end)()
antivoid = Instance.new("Part")
antivoid.Name = randomstring()
antivoid.Size = Vector3.new(400,10,400)
antivoid.Anchored = true
antivoid.Transparency = 1
antivoid.Position = Vector3.new(RootPart.Position.X,workspace.FallenPartsDestroyHeight+5,RootPart.Position.Z)
antivoid.Parent = workspace
coroutine.resume(coroutine.create(function()
	while not stopeverything do
		swait()
		if not alreadyfixing then
			if antivoid:IsDescendantOf(workspace) then
				antivoid.Position = Vector3.new(RootPart.Position.X,workspace.FallenPartsDestroyHeight+5,RootPart.Position.Z)
			else
				pcall(function()
					antivoid:Destroy()
				end)
				antivoid = Instance.new("Part")
				antivoid.Name = randomstring()
				antivoid.Size = Vector3.new(400,10,400)
				antivoid.Anchored = true
				antivoid.Transparency = 1
				antivoid.Position = Vector3.new(RootPart.Position.X,workspace.FallenPartsDestroyHeight+5,RootPart.Position.Z)
				antivoid.Parent = workspace
			end
		end
	end
end))
if lplr.Name == USERNAME then
	game:GetService("UserInputService").InputBegan:Connect(function()
		if stopeverything then wait(math.huge) end
		if game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Space) and not alreadyfixing and game:GetService("UserInputService"):GetFocusedTextBox() == nil then 
			repeat if stopeverything then wait(math.huge) end 
				Humanoid.Jump = true 
				game:GetService("RunService").RenderStepped:Wait() 
				Humanoid.Jump = false 
				game:GetService("RunService").RenderStepped:Wait() 
			until not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Space)
		end
	end)
end

function fly()

	function weld(p0,p1,c0,c1,par)
		local w = Instance.new("Weld",p0 or par)
		w.Part0 = p0
		w.Part1 = p1
		w.C0 = c0 or CFrame.new()
		w.C1 = c1 or CFrame.new()
		return w
	end
	local motors = {}
	function motor(p0,p1,c0,c1,des,vel,par)
		local w = Instance.new("Motor6D",p0 or par)
		w.Part0 = p0
		w.Part1 = p1
		w.C0 = c0 or CFrame.new()
		w.C1 = c1 or CFrame.new()
		w.MaxVelocity = tonumber(vel) or .05
		w.DesiredAngle = tonumber(des) or 0
		return w
	end
	function lerp(a,b,c)
		return a+(b-a)*c
	end
	function clerp(c1,c2,alBRUH)
		local al = .05
		local com1 = {c1.X,c1.Y,c1.Z,c1:toEulerAnglesXYZ()}
		local com2 = {c2.X,c2.Y,c2.Z,c2:toEulerAnglesXYZ()}
		for i,v in pairs(com1) do
			com1[i] = lerp(v,com2[i],al)
		end
		return CFrame.new(com1[1],com1[2],com1[3]) * CFrame.Angles(select(4,unpack(com1)))
	end
	function ccomplerp(c1,c2,alBRUH)
		local al = .05
		local com1 = {c1:components()}
		local com2 = {c2:components()}
		for i,v in pairs(com1) do
			com1[i] = lerp(v,com2[i],al)
		end
		return CFrame.new(unpack(com1))
	end
	function tickwave(time,length,offset)
		return .2*math.sin(sine/20)
	end
	function invcol(c)
		c = c.Color
		return BrickColor.new(MAINRUINCOLOR)
	end
	local char = Character
	local tor = Torso
	local hum = Humanoid
	local special = {
	}
	local topcolor = invcol(Character.Torso.BrickColor)
	local feacolor = topcolor
	local ptrans = 0
	local pref = 0
	local fire = false
	local fmcol = Color3.new()
	local fscol = Color3.new()
	local part = Instance.new("Part")
	part.FormFactor = "Custom"
	part.Size = Vector3.new(.2,.2,.2)
	part.TopSurface,part.BottomSurface = 0,0
	part.CanCollide = false
	part.BrickColor = topcolor
	part.Transparency = 1
	part.Reflectance = pref
	part.Material = Torso.Material
	local ef = Instance.new("Fire",fire and part or nil)
	ef.Heat = 0
	ef.Size = .15
	ef.Color = fmcol or Color3.new()
	ef.SecondaryColor = fscol or Color3.new()
	part:BreakJoints()
	function newpart()
		local clone = part:Clone()
		clone.Parent = mod
		clone:BreakJoints()
		return clone
	end
	function gotResized()
		if lastsize then
			if tor.Size == lastsize then return end
			local scaleVec = tor.Size/lastsize
			for i,v in pairs(oc0) do
				oc0[i] = v-v.p+scaleVec*v.p
			end
			lastsize = tor.Size
		end
		lastsize = tor.Size
	end
	tor:GetPropertyChangedSignal("Size"):Connect(function()
		if stopeverything then wait(math.huge) end
		gotResized()
	end)
	gotResized()
	local ctor = tor:Clone()
	ctor:ClearAllChildren()
	ctor.Name = "cTorso"
	ctor.Transparency = 1
	ctor.CanCollide = false
	ctor.FormFactor = "Custom"
	ctor.Size = Vector3.new(.2,.2,.2)
	ctor.Parent = mod
	weld(tor,ctor)
	local bg = Instance.new("BodyGyro",ctor)
	bg.maxTorque = Vector3.new()
	bg.P = 15000
	bg.D = 1000
	local bv = Instance.new("BodyVelocity",ctor)
	bv.maxForce = Vector3.new()
	bv.P = 15000
	vel = Vector3.new()
	cf = CFrame.new()
	flspd = 0
	keysdown = {}
	keypressed = {}
	ktime = {}
	descendtimer = 0
	jumptime = tick()
	hum.Jumping:connect(function()
		if stopeverything then wait(math.huge) end
		jumptime = tick()
	end)
	cam = workspace.CurrentCamera
	function mid(a,b,c)
		return math.max(a,math.min(b,c or -a))
	end
	function bn(a)
		return a and 1 or 0
	end
	function gm(tar)
		local m = 0
		for i,v in pairs(tar:GetChildren()) do
			if v:IsA("BasePart") then
				m = m + v:GetMass()
			end
			m = m + gm(v)
		end
		return m
	end
	reqrotx = 0
	local grav = 196.2
	local con
	while not stopeverything and not alreadyfixing do
		local obvel = tor.CFrame:vectorToObjectSpace(tor.Velocity)
		local sspd,uspd,fspd = obvel.X,obvel.Y,obvel.Z
		flying = true
		if flying then
			local lfldir = fldir
			fldir = cam.CoordinateFrame:vectorToWorldSpace(Vector3.new(bn(keysdown.d)-bn(keysdown.a),0,bn(keysdown.s)-bn(keysdown.w))).unit
			local lmoving = moving
			moving = fldir.Magnitude > .1
			if lmoving and not moving then
				idledir = lfldir*Vector3.new(1,0,1)
				descendtimer = tick()
			end
			local dbomb = fldir.Y < -.6 or (moving and keysdown["1"])
			if moving and keysdown["0"] and lmoving then
				fldir = (Vector3.new(lfldir.X,math.min(fldir.Y,lfldir.Y+.01)-.1,lfldir.Z)+(fldir*Vector3.new(1,0,1))*.05).unit
			end
			local down = tor.CFrame:vectorToWorldSpace(Vector3.new(0,-1,0))
			local descending = (not moving and keysdown["q"] and not keysdown[" "])
			cf = ccomplerp(cf,CFrame.new(tor.Position,tor.Position+(not moving and idledir or fldir)),keysdown["0"] and .02 or .07)
			local gdown = not dbomb and cf.lookVector.Y < -.2 and tor.Velocity.unit.Y < .05
			local rotvel = CFrame.new(Vector3.new(),tor.Velocity):toObjectSpace(CFrame.new(Vector3.new(),fldir)).lookVector
			bg.cframe = cf * CFrame.Angles(not moving and -.1 or -math.pi/2+.2,moving and mid(-2.5,rotvel.X/1.5) + reqrotx or 0,0)
			reqrotx = reqrotx - reqrotx/10
			local ani = tickwave(1.5,1)
			vel = moving and cf.lookVector*flspd or Vector3.new()
			flspd = math.min(120,lerp(flspd,moving and (fldir.Y<0 and flspd+(-fldir.Y)*grav/60 or math.max(50,flspd-fldir.Y*grav/300)) or 60,.4))
			local hit,ray = workspace:FindPartOnRayWithIgnoreList(Ray.new(tor.Position,Vector3.new(0,-3.5+math.min(0,bv.velocity.y)/30,0)),{Character})
		else
			bg.maxTorque = Vector3.new()
			bv.maxForce = Vector3.new()
			if keypressed[" "] and not flying and (tick()-jumptime > .05 and (tick()-jumptime < 3 or hum.Jump)) then
				vel = Vector3.new(0,50,0)
				bv.velocity = vel
				idledir = cam.CoordinateFrame.lookVector*Vector3.new(1,0,1)
				cf = tor.CFrame * CFrame.Angles(-.01,0,0)
				bg.cframe = cf
				flystart = tick()
				flying = true
			end
		end
		keypressed = {}
		swait()
	end
end
coroutine.resume(coroutine.create(function()
	fly()
end))
game:GetService("RunService").RenderStepped:Connect(function()
	if stopeverything then wait(math.huge) end
	if not soundfixing then
		eeeblock.CFrame = Torso.CFrame
	end
	shieldblock.Position = Torso.Position
	shieldblock.Orientation = Vector3.new(math.rad(-sine*5),math.rad(-sine*10),math.rad(-sine*15))
	shieldblock.Size = Vector3.new(shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435),shieldsize.Value+1*math.sin(sine/55.435))
	shieldblock.Color = GUN.NeonParts.Color
end)
workspace.ChildAdded:Connect(function(v)
	if stopeverything then wait(math.huge) end
	if v:IsA("Message") and v.Text ~= "I kinda need you to have a HumanoidRootPart to be able to do anthing,try again once you have one lol" then
		v.Text = ""
		v:GetPropertyChangedSignal("Text"):Connect(function()
			if stopeverything then wait(math.huge) end
			if v.Text ~= "" then
				v.Text = ""
			end
		end)
		game:GetService("Debris"):AddItem(v,.01)
	elseif v:IsA("BasePart") and v.Name == "StrawBerry" then
		v.Transparency = 1
		game:GetService("Debris"):AddItem(v,.01)
	end
end)
local blockedguis = {"vbucks","sup","AllahGui","SnakeVenomSS","polishtoilet","nooties","IY_GUI","IY_JumpScare","Dex","BugGui"}
function checkgui(v) 

end

if lplr.Name ~= USERNAME then

	coroutine.resume(coroutine.create(function()
		while not stopeverything do
			local twe3n = game:GetService("TweenService"):Create(RootPart,TweenInfo.new(.1,Enum.EasingStyle.Linear),{CFrame = charpos.Value})
			twe3n:Play()
			twe3n.Completed:Wait()
		end
	end))
end



RootPart.Anchored = false

local wa = 0







while not stopeverything do
	if not alreadyfixing then
		if lplr.Name ~= USERNAME then
			antivoid.CanCollide = false
		end

		if not soundfixing then
			eeeblock.CFrame = Torso.CFrame
			if eee.Volume ~= eeevol then
				eee.Volume = eeevol
			end
			if eee.Pitch ~= eeepitch then
				eee.Pitch = eeepitch
			end
			if eee.SoundId ~= songid.Value then
				eee.SoundId = songid.Value
			end
			if eee.Playing ~= true then
				eee.Playing = true
			end
			if eee.Looped ~= true then
				eee.Looped = true
			end
			if eee.EmitterSize ~= 50 then
				eee.EmitterSize = 50
			end
			if eee.MaxDistance ~= 100000 then
				eee.MaxDistance = 100000
			end
			if eee.PlayOnRemove ~= false then
				eee.PlayOnRemove = false
			end
		end
		local WALKSPEEDVALUE = 6 / (Humanoid.WalkSpeed / 16)

		Humanoid.PlatformStand = ISFLYING
		Humanoid.UseJumpPower = true
		Humanoid.JumpPower = 50
		Humanoid.BreakJointsOnDeath = false

		Humanoid.WalkSpeed = walkspeed


		Humanoid.HipHeight = HipVal

		for i,v in pairs(Character:GetChildren()) do
			if v:IsA("BasePart") and v.Anchored == false and v.Position.Y < (workspace.FallenPartsDestroyHeight + 50) then
				local flot = Instance.new("BodyPosition")
				local spen = Instance.new("BodyGyro")
				local hu = math.huge
				flot.MaxForce = Vector3.new(hu,hu,hu)
				spen.MaxTorque = Vector3.new(hu,hu,hu)
				local spown = nil
				for o,b in pairs(workspace:GetDescendants()) do
					if not b:IsDescendantOf(Character) and b:IsA("SpawnLocation") then
						spown = b
					end
				end
				if spown then
					RootPart.CFrame = CFrame.new(spown.Position.X,spown.Position.Y+(spown.Size.Y/2)+6+Humanoid.HipHeight,spown.Position.Z)
				else
					local base = workspace:FindFirstChild("Base")
					if not base then
						base = workspace:FindFirstChild("Baseplate")
					end
					if base then
						RootPart.CFrame = CFrame.new(math.clamp(RootPart.Position.X,(-base.Size.X/2)+5,(base.Size.X/2)-5),base.Position.Y+(base.Size.Y/2)+6+Humanoid.HipHeight,math.clamp(RootPart.Position.Z,(-base.Size.X/2)+5,(base.Size.X/2)-5))
					else
						RootPart.CFrame = CFrame.new(math.clamp(RootPart.Position.X,-100,100),100,math.clamp(RootPart.Position.Z,-100,100))
					end
				end
				flot.Position = RootPart.Position
				flot.Parent = RootPart
				spen.CFrame = RootPart.CFrame
				spen.Parent = RootPart
				game:GetService("Debris"):AddItem(flot,1)
				game:GetService("Debris"):AddItem(spen,1)
			end
		end
		Torsovelocity = (ActualVelocity).Magnitude
		if lplr.Name == USERNAME then
			Torsovelocity = (RootPart.Velocity).Magnitude
		end 
		local TORSOVELOCITY = (RootPart.Velocity * VT(1, 0, 1)).magnitude
		local TORSOVERTICALVELOCITY = RootPart.Velocity.y
		local WALKSPEEDVALUE = 6 / (Humanoid.WalkSpeed / 16)
		local sidevec = math.clamp((root.Velocity*root.CFrame.rightVector).X+(root.Velocity*root.CFrame.rightVector).Z,-hum.WalkSpeed,hum.WalkSpeed)
		local forwardvec =  math.clamp((root.Velocity*root.CFrame.lookVector).X+(root.Velocity*root.CFrame.lookVector).Z,-hum.WalkSpeed,hum.WalkSpeed)
		local sidevelocity = sidevec/hum.WalkSpeed
		local forwardvelocity = forwardvec/hum.WalkSpeed
		sine = sine + change
		walksine = walksine + walkc
		sine2 = sine2 + c2
		LOOPx = LOOPx + 5
		local sensitivity = 25
		local hit,pos = rayCast(RootPart.Position,(CFrame.new(RootPart.Position,RootPart.Position - Vector3.new(0,1,0))).lookVector,4,Character)
		if taunt.Value == "newmlc" then
			change = 1
			if HipValLock == false then
				HipVal = 0
			end
			if Anim == "Walk" and Torsovelocity > 1 then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new(0,0,0.1 + 0.05 * math.cos(sine / 6)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0) - Head.RotVelocity.Y / 30),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,.95-.2*math.sin(sine/12),-.15*math.sin(sine/12)) * CFrame.Angles(math.rad(-5),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10+35 * math.cos(sine / 12))),0.6 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,.95+.2*math.sin(sine/12),.15*math.sin(sine/12)) * CFrame.Angles(math.rad(-5),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10+35 * math.cos(sine / 12))),0.6 / 3)
			elseif (Anim ~= "Walk") or (Torsovelocity < 1) then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
			end
			if RootPart.Velocity.y > 1 then 
				Anim = "Jump"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 ) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(10)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-50),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif RootPart.Velocity.y < -1 then 
				Anim = "Fall"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 ) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-15),math.rad(2.5),math.rad(5+5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-90 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity < 1   then
				Anim = "Idle"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.cos(sine / 12)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-15 - 3 * math.cos(sine / 12)),math.rad(5),math.rad(0)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5 + 0.1 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(-53.75+1.75 * math.cos(sine / 12)),math.rad(0),math.rad(5)) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5 + 0.1 * math.cos(sine / 12),-0) * CFrame.Angles(math.rad(15 - 1.5 * math.cos(sine / 12)),math.rad(0 - 6 * math.cos(sine / 12)),math.rad(0 - 6 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1.1 - 0.05 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(15),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1.1 - 0.05 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(10),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-106.3-.9*math.cos(sine/12)),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity > 2  then
				Anim = "Walk"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.cos(sine / 12)) * CFrame.Angles(math.rad(20),math.rad(0 + 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-20 - 3 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-60 - 5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(5 + 2.5 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0 - 0.2 * math.cos(sine / 12)) * CFrame.Angles(math.rad(20 - 45 * math.cos(sine / 12)),math.rad(0 - 10 * math.cos(sine / 12)),math.rad(0 + 2.5 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1 ,-1,0) * CFrame.Angles(math.rad(0),math.rad(85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-93.75+7.25*math.cos(sine/12)),math.rad(0),math.rad(0)),1 / 2)
				end
			end
			GUN.Base.Transparency = 0
			GUN.GunAdditions.Transparency = 0
			GUN.NeonParts.Transparency = 0
			Humanoid.WalkSpeed = 10
		elseif taunt.Value == "newdefault" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 2 / Animation_Speed
			sensitivity = 10
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if attack == false then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/25))*CFrame.Angles(math.rad(0 - 1 * math.cos(sine/54*1.2)),math.rad(0 - 2 * math.cos(sine/54*1.5)),math.rad(-35)),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(0 - 3 * math.cos(sine/54*1.2)),math.rad(0 - 4 * math.cos(sine/54*1.5)),math.rad(35)),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(75 + 8.5 * math.cos(sine/25)),math.rad(-20),math.rad(40)) * RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(25 + 8.5 * math.cos(sine/25)),math.rad(0),math.rad(-25 - 5 * math.cos(sine/25))) * LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,-.5) * CFrame.Angles(math.rad(-15 + 9 * math.sin(sine/25)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.sin(sine/25)),math.rad(0),math.rad(0)),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 + 9 * math.sin(sine/25)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.sin(sine/25)),math.rad(0),math.rad(0)),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-.7,0) * CFrame.Angles(math.rad(95),math.rad(0),math.rad(180)),.25)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/25))*CFrame.Angles(math.rad(45),math.rad(0 - 2 * math.cos(sine/54*1.5)),math.rad(-30)),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-45 - 3 * math.cos(sine/54*1.2)),math.rad(0 - 4 * math.cos(sine/54*1.5)),math.rad(30)),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-45),math.rad(-2),math.rad(14)) * RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-.5,.5,-.5) * CFrame.Angles(math.rad(89),math.rad(0),math.rad(89)) * LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.5,0) * CFrame.Angles(math.rad(-15 + 9 * math.sin(sine/25)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.sin(sine/25)),math.rad(0),math.rad(0)),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.7) * CFrame.Angles(math.rad(-15 + 9 * math.sin(sine/25)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.sin(sine/25)),math.rad(0),math.rad(0)),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),.25)
				end
				GUN.Base.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				GUN.Gun.Transparency = 0

			end
			Humanoid.WalkSpeed = 40
		elseif taunt.Value == "None" then -- non
			change = 1
			--eeepitch = 1
			--eevol = 5
			sensitivity = 25
			if HipValLock == false then
				HipVal = 3
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)),0.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(135 + 8.5 * math.cos(sine/50)),math.rad(0),math.rad(25)) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(25 + 8.5 * math.cos(sine/50)),math.rad(0),math.rad(-25 - 5 * math.cos(sine/25))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.5,-0.5) * CFrame.Angles(math.rad(-15 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),0.7/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-15 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),0.7/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(40),math.rad(0),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-40),math.rad(0),math.rad(0)),0.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(5 + 2 * math.cos(sine/19))) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(-5 - 2 * math.cos(sine/19))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.5,-0.5) * CFrame.Angles(math.rad(-20 + 9 * math.cos(sine/74)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),0.7/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-20 - 9 * math.cos(sine/54)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),0.7/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 50
		elseif taunt.Value == "idk" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			sensitivity = 25
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if attack == false then
				if Torsovelocity < sensitivity/3.125 then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/30)) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(20-5*math.cos(sine/30)),0,0),.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CFrame.new(1.55, 0.5, 0.5) * CFrame.Angles(math.rad(250), math.rad(20), math.rad(-80))* RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(-10-10*math.cos(sine/30))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-0.01) * CFrame.Angles(math.rad(10),math.rad(80),math.rad(10+10*math.cos(sine/30))),1/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-0.01) * CFrame.Angles(math.rad(20),math.rad(-80),math.rad(-10-10*math.cos(sine/30))),1/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity/3.125 then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/30)) * CFrame.Angles(math.rad(28.947),math.rad(0),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-8),math.rad(0),math.rad(0)),.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CFrame.new(1.55, 0.5, 0.5) * CFrame.Angles(math.rad(250), math.rad(20), math.rad(-80))* RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(-10-10*math.cos(sine/30))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-0.01) * CFrame.Angles(math.rad(-30),math.rad(80),math.rad(10+10*math.cos(sine/30))),1/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-0.01) * CFrame.Angles(math.rad(-20),math.rad(-80),math.rad(-10-10*math.cos(sine/30))),1/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 40
		elseif taunt.Value == "None2" then
			change = 1
			--eeepitch = 1
			--eevol = 5
			sensitivity = 25
			if HipValLock == false then
				HipVal = 6
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					HoverBoard.Base.Joint.C0 = Clerp(HoverBoard.Base.Joint.C0,CFrame.new(0,3.2,0) * CFrame.Angles(math.rad(0+3*math.cos(sine/55)),math.rad(-10),math.rad(0+3*math.cos(sine/50))) * CFrame.new(0,eee.PlaybackLoudness/5000,0),1 / 3)
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(5),math.rad(0),math.rad(10)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(14 + 3 * math.cos(sine / 45))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-18 - 3 * math.cos(sine / 45))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-eee.PlaybackLoudness/5000,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1-eee.PlaybackLoudness/5000,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					HoverBoard.Base.Joint.C0 = Clerp(HoverBoard.Base.Joint.C0,CFrame.new(0,3.2,0) * CFrame.Angles(math.rad(-15+3*math.cos(sine/55)),0,math.rad(0+3*math.cos(sine/50))) * CFrame.new(0,0+.1*math.cos(sine/40),0),1 / 3)
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(35),math.rad(0+2*math.cos(sine/61.5)),math.rad(0)) * CFrame.new(0,0,0+.1*math.cos(sine/40)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-15),math.rad(0),math.rad(0)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(5-5 * math.cos(sine/50))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(-5+5 * math.cos(sine/50))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-.1*math.cos(sine/40),0) * CFrame.Angles(math.rad(36),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1-.1*math.cos(sine/40),0) * CFrame.Angles(math.rad(-6),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 100
		elseif taunt.Value == "lcv1" then
			change = 1
			if HipValLock == false then
				HipVal = 0
			end
			if Anim == "Walk" and Torsovelocity > 1 then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new(0,0,0.1 + 0.05 * math.cos(sine / 6)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0) - Head.RotVelocity.Y / 30),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,.95-.2*math.sin(sine/12),-.15*math.sin(sine/12)) * CFrame.Angles(math.rad(-5),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10+35 * math.cos(sine / 12))),0.6 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,.95+.2*math.sin(sine/12),.15*math.sin(sine/12)) * CFrame.Angles(math.rad(-5),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10+35 * math.cos(sine / 12))),0.6 / 3)
			elseif (Anim ~= "Walk") or (Torsovelocity < 1) then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
			end
			if RootPart.Velocity.y > 1 and hit == nil then 
				Anim = "Jump"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 ) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(10)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-50),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif RootPart.Velocity.y < -1 and hit == nil then 
				Anim = "Fall"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 ) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-15),math.rad(2.5),math.rad(5+5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-90 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity < 1 and hit ~= nil then
				Anim = "Idle"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.cos(sine / 12)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-15 - 3 * math.cos(sine / 12)),math.rad(5),math.rad(0)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5 + 0.1 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(-53.75+1.75 * math.cos(sine / 12)),math.rad(0),math.rad(5)) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5 + 0.1 * math.cos(sine / 12),-0) * CFrame.Angles(math.rad(15 - 1.5 * math.cos(sine / 12)),math.rad(0 - 6 * math.cos(sine / 12)),math.rad(0 - 6 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1.1 - 0.05 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(15),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1.1 - 0.05 * math.cos(sine / 12),0) * CFrame.Angles(math.rad(10),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-106.3-.9*math.cos(sine/12)),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity > 2 and hit ~= nil then
				Anim = "Walk"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.cos(sine / 12)) * CFrame.Angles(math.rad(20),math.rad(0 + 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-20 - 3 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-60 - 5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(5 + 2.5 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0 - 0.2 * math.cos(sine / 12)) * CFrame.Angles(math.rad(20 - 45 * math.cos(sine / 12)),math.rad(0 - 10 * math.cos(sine / 12)),math.rad(0 + 2.5 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1 ,-1,0) * CFrame.Angles(math.rad(0),math.rad(85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-93.75+7.25*math.cos(sine/12)),math.rad(0),math.rad(0)),1 / 2)
				end
			end
			GUN.Base.Transparency = 1
			GUN.Gun.Transparency = 0
			GUN.GunAdditions.Transparency = 1
			GUN.NeonParts.Transparency = 1
			Humanoid.WalkSpeed = 10
		elseif taunt.Value == "mlc" then
			change = 1
			if HipValLock == false then
				HipVal = 0
			end
			if Anim == "Walk" and Torsovelocity > 1 then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new(0,0,0.1 + 0.05 * math.cos(sine / 6)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0) - Head.RotVelocity.Y / 30),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,.95-.2*math.sin(sine/12),-.15*math.sin(sine/12)) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-10+35 * math.cos(sine / 12))),0.6 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,.95+.2*math.sin(sine/12),.15*math.sin(sine/12)) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10+35 * math.cos(sine / 12))),0.6 / 3)
			elseif (Anim ~= "Walk") or (Torsovelocity < 1) then
				RootJoint.C1 = Clerp(RootJoint.C1,rc0 * CFrame.new() * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.2 / 3)
				RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
				LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7 / 3)
			end
			if RootPart.Velocity.y > 1 and hit == nil then 
				Anim = "Jump"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(10)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(170),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif RootPart.Velocity.y < -1 and hit == nil then 
				Anim = "Fall"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-15),math.rad(2.5),math.rad(5+5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(175 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(0 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity < 1 and hit ~= nil then
				Anim = "Idle"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.sin(sine / 32)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-15 - 3 * math.cos(sine / 32)),math.rad(0),math.rad(0)),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5 + 0.1 * math.cos(sine / 32),0) * CFrame.Angles(math.rad(-53.75+1.75 * math.cos(sine / 32)),math.rad(0),math.rad(5)) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5 + 0.1 * math.cos(sine / 32),-0) * CFrame.Angles(math.rad(15 - 1.5 * math.cos(sine / 32)),math.rad(0 - 6 * math.cos(sine / 32)),math.rad(0 - 6 * math.cos(sine / 32))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1.1 - 0.05 * math.sin(sine / 32),0) * CFrame.Angles(math.rad(15),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1.1 - 0.05 * math.sin(sine / 32),0) * CFrame.Angles(math.rad(10),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-106.3+.9*math.sin(sine/32)),math.rad(0),math.rad(0)),1 / 2)
				end
			elseif Torsovelocity > 2 and hit ~= nil then
				Anim = "Walk"
				if attack == false then
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0 + 0.05 * math.sin(sine / 12)) * CFrame.Angles(math.rad(15),math.rad(0 + 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-5 - 3 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(0 - 2.5 * math.cos(sine / 12))),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(150),math.rad(0 - 2.5 * math.cos(sine / 12)),math.rad(5 + 2.5 * math.cos(sine / 12))) * rscp,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0 - 0.2 * math.cos(sine / 12)) * CFrame.Angles(math.rad(5 - 45 * math.cos(sine / 12)),math.rad(0 - 10 * math.cos(sine / 12)),math.rad(0 + 2.5 * math.cos(sine / 12))) * lscp,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1 ,-1,0) * CFrame.Angles(math.rad(0),math.rad(85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 2)
				end
			end
			GUN.Base.Transparency = 1
			GUN.Gun.Transparency = 0
			GUN.GunAdditions.Transparency = 1
			GUN.NeonParts.Transparency = 1
			Humanoid.WalkSpeed = 10
		elseif taunt.Value == "N4N" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			sensitivity = 25
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,math.cos(sine/25),0-math.sin(sine/25))*CFrame.Angles(math.rad(5*math.sin(sine/25)),0,0),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.Angles(math.rad(5*math.cos(sine/25)),0,0),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0)*CFrame.Angles(math.rad(160),0,math.rad(15-5*math.sin(sine/25)))* RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0)*CFrame.Angles(0,0,math.rad(-15+5*math.sin(sine/25)))* LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-.1*math.sin(sine/25),-.01)*CFrame.Angles(0,math.rad(80),0),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-.5-.25*math.sin(sine/25),-.51)*CFrame.Angles(math.rad(-10),math.rad(-80),0),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,math.cos(sine/25),0-math.sin(sine/25))*CFrame.Angles(math.rad(5*math.sin(sine/25)),0,math.rad(70)),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.Angles(0,0,math.rad(-70))*CFrame.Angles(math.rad(5*math.cos(sine/25)),0,0),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1,.5,-.25)*CFrame.Angles(0,math.rad(-10),math.rad(-90))* RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0)*CFrame.Angles(0,0,math.rad(-20+5*math.sin(sine/25)))* LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-.1*math.sin(sine/25),-.01)*CFrame.Angles(0,math.rad(80),0),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-.5-.25*math.sin(sine/25),-.51)*CFrame.Angles(math.rad(-10),math.rad(-80),0),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 50
		elseif taunt.Value == "Banisher2" then -- MrMaddox32's Anim
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10
			if math.random(0,20) == 1 then
				warn("spammer")
			end
			WACKYEFFECT({Time = 12, EffectType = "Block", Size = VT(3,3,3)/5, Size2 = VT(0,0,0), Transparency = .5, Transparency2 = 1, CFrame = GUN2.Hole.CFrame*CF(0,0,0)*ANGLES(math.rad(MRANDOM(-9999,9999)),math.rad(MRANDOM(-9999,9999)),math.rad(MRANDOM(-9999,9999))), MoveToPos = nil, RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then	
				GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(25 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(45 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(0.75, 0.4 - 0.1 * COS(sine / 12), -1) * ANGLES(RAD(70), RAD(0), RAD(-70)) * ANGLES(RAD(20), RAD(25), RAD(-15)) * RIGHTSHOULDERC0, 0.4 / Animation_Speed)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + 0.05 * COS(sine / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.8 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.1 - 0.1 * COS(sine / 12), -0.5) * ANGLES(RAD(25), RAD(0), RAD(85)) * LEFTSHOULDERC0, 0.4 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.025 * COS(sine / 12), -0.01) * ANGLES(RAD(0), RAD(83), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.8 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(sine / 12), -0.01) * ANGLES(RAD(0), RAD(-83), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.8 / Animation_Speed)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(5 - 2* SIN(sine / 6)), RAD(0), RAD(0-1*COS(sine / 12))), 0.8 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(40), RAD(4), RAD(45)) * RIGHTSHOULDERC0, 0.8 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0+25* SIN(sine / 12)), RAD(0), RAD(-12-5*COS(sine / 6))) * LEFTSHOULDERC0, 0.8 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, -0.1+0.1* COS(sine / 6)) * ANGLES(RAD(5-1*math.cos(sine/12)), RAD(0+1*COS(sine / 12)), RAD(0-2*SIN(sine / 12))), 0.8 / 3)
						RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0-0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(-5), RAD(-5 + 45 * SIN(sine / 12))), 0.8 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0+0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(5), RAD(5 + 45 * SIN(sine / 12))), 0.8 / 3)
					end
				end
			end
			walkspeed = 16
		elseif taunt.Value == "N0X" then
			--eeepitch = 1
			--eevol = 5
			change = 1
			sensitivity = 10
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				if HipValLock == false then
					HipVal = 0
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,.05*math.cos(sine/12))*CFrame.Angles(math.rad(15),0,0),1 / 3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.Angles(math.rad(-15-3*math.cos(sine/12)),math.rad(5-5*math.sin(sine/12)),0),1 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5+0.1*math.cos(sine/12),0)*CFrame.Angles(math.rad(-53.75+1.75*math.cos(sine/12)),0,math.rad(5))* RIGHTSHOULDERC0,1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5+.1*math.sin(sine/12),0)*CFrame.Angles(math.rad(15),0,math.rad(-5+5*math.cos(sine/12)))* LEFTSHOULDERC0,1 / 3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-.06*math.cos(sine/12),-.01)*CFrame.Angles(math.rad(10),math.rad(80),math.rad(0)),1 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1-.06*math.cos(sine/12),-.01)*CFrame.Angles(math.rad(20),math.rad(-80),math.rad(0)),1 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15)*CFrame.Angles(math.rad(-106.3-.9*math.cos(sine/12)),0,0),.25)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,.125*math.sin(sine/12),0)*CFrame.Angles(math.rad(10-5*math.cos(sine/12)),math.rad(-10*math.cos(sine/12)),math.rad(-5*math.cos(sine/12))),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.Angles(math.rad(10-5*math.cos(sine/12)),math.rad(10*math.cos(sine/12)),math.rad(5*math.cos(sine/12))),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5+.2*math.sin(sine/12),-.25)*CFrame.Angles(math.rad(165-15*math.cos(sine/12)),math.rad(-10+5*math.sin(sine/12)),math.rad(10))* RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5-.15*math.cos(sine/12),.5*math.sin(sine/12))*CFrame.Angles(math.rad(-30*math.sin(sine/12)),math.rad(5*math.cos(sine/12)),0)* LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.9-.2*math.cos(sine/12),.5*math.sin(sine/12))*CFrame.Angles(math.rad(-10-40*math.sin(sine/12)),math.rad(90+5*math.cos(sine/12)),math.rad(2.5*math.cos(sine/12))),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-.9+.2*math.cos(sine/12),-.5*math.sin(sine/12))*CFrame.Angles(math.rad(-10+40*math.sin(sine/12)),math.rad(-90+5*math.cos(sine/12)),math.rad(2.5*math.cos(sine/12))),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				end
			end
			Humanoid.WalkSpeed = 16
		elseif taunt.Value == "aEa" then
			--eeepitch = 1
			local ADD = Humanoid.WalkSpeed*2
			change = 2 / Animation_Speed
			sensitivity = 25
			if HipValLock == false then
				HipVal = 3
			end
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0+0.5*COS(sine / 15)) * ANGLES(RAD(0), RAD(0), RAD(0)), 5.15 / 9)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 - 0.1 * COS(sine / 5) + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine / 12)), RAD(10 * COS(sine / 12)), RAD(0)), 5.15 / 9)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.55, 0.5, 0.5) * CFrame.Angles(math.rad(250), math.rad(20), math.rad(-80))* RIGHTSHOULDERC0, 1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5 - 0.15 * COS(sine / 12), 0) * ANGLES(RAD(180 - 3.5 * SIN(sine / 12)), RAD(0 - 8.5 * SIN(sine / 12)), RAD(20 + 8.5 * SIN(sine / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1-.001*COS(sine / 7), -0.01) * ANGLES(RAD(-10-2.5*math.cos(sine/60)), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -.5-.001*math.cos(sine/7), -0.5) * ANGLES(RAD(-25-2.5*math.cos(sine/60)), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-120),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0,0,0+0.5*COS(sine / 15))*ANGLES(RAD(25+2.5*COS(sine / 12)),RAD(0-RootPart.RotVelocity.y),RAD(0 - RootPart.RotVelocity.Y * 4.5 + 3 * COS(sine / 47))), 1 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 - 0.1 * COS(sine / 5) + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine / 12)), RAD(10 * COS(sine / 12)), RAD(0)), 5.15 / 9)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.55, 0.5, 0.5) * CFrame.Angles(math.rad(250), math.rad(20), math.rad(-80))* RIGHTSHOULDERC0, 1 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5 - 0.15 * COS(sine / 12), 0) * ANGLES(RAD(180 - 3.5 * SIN(sine / 12)), RAD(0 - 8.5 * SIN(sine / 12)), RAD(20 + 8.5 * SIN(sine / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1-.001*COS(sine / 7), -0.01) * ANGLES(RAD(-20-2.5*math.cos(sine/60)), RAD(75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -.5-.001*math.cos(sine/7), -0.5) * ANGLES(RAD(-35-2.5*math.cos(sine/60)), RAD(-75), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-120),math.rad(0),math.rad(0)),1/2)
				end
			end
			Humanoid.WalkSpeed = 100
			GUN.Base.Transparency = 1
			GUN.Gun.Transparency = 0
			GUN.GunAdditions.Transparency = 1
			GUN.NeonParts.Transparency = 1
		elseif taunt.Value == "Insanity" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			sensitivity = 10
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if attack == false then
				if Torsovelocity < sensitivity/3.125 then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(20),math.rad(10*math.cos(sine/100)),math.rad(0)),1)
					if math.random(1,60) == 1 then
						Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(20+math.random(-20,20)),math.rad((10*math.cos(sine/100))+math.random(-20,20)),math.rad(math.random(-20,20))),1)
					end
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-41.6-4*math.sin(sine/50)),math.rad(0),math.rad(0)) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(-10-10*math.sin(sine/50))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-0.01) * CFrame.Angles(math.rad(10),math.rad(80),math.rad(10+10*math.sin(sine/50))),1/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-0.01) * CFrame.Angles(math.rad(20),math.rad(-80),math.rad(-10-10*math.sin(sine/50))),1/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity/3.125 then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),0.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-41.6-4*math.sin(sine/50)),math.rad(0),math.rad(0)) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(-10-10*math.sin(sine/50))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-0.01) * CFrame.Angles(math.rad(-20),math.rad(80),math.rad(10+10*math.sin(sine/50))),1/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-0.01) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(-10-10*math.sin(sine/50))),1/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 16
		elseif taunt.Value == "Banisher" then -- Pastel Shooter, Good Script.
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = 1
			change = 2 / Animation_Speed
			sensitivity = 10
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if attack == false then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity/3.125 then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 , 0 , 00 + 0.2 * COS(sine / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(30), RAD(0), RAD(0 + 25 * COS(sine / 20))), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5+ 0.35 * SIN(sine / 12), 0) * ANGLES(RAD(180), RAD(-15), RAD(0))* RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5 + 0.35 * SIN(sine / 12), 0) * ANGLES(RAD(0), RAD(0), RAD(-10 + 15 * COS(sine / 12))) * ANGLES(RAD(0), RAD(15), RAD(0)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1- 0.2 * COS(sine / 12), 0) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1- 0.2 * COS(sine / 12) , 0) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity/3.125 then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,.125*math.sin(sine/12),0)*CFrame.Angles(math.rad(10-5*math.cos(sine/12)),math.rad(-10*math.cos(sine/12)),math.rad(-5*math.cos(sine/12))),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.Angles(math.rad(10-5*math.cos(sine/12)),math.rad(10*math.cos(sine/12)),math.rad(5*math.cos(sine/12))),.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0)*CFrame.Angles(math.rad(-40-10*math.cos(sine/12)),math.rad(-10+5*math.sin(sine/12)),math.rad(10))* RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5-.15*math.cos(sine/12),.5*math.sin(sine/12))*CFrame.Angles(math.rad(-30*math.sin(sine/12)),math.rad(5*math.cos(sine/12)),0)* LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-.9-.2*math.cos(sine/12),.5*math.sin(sine/12))*CFrame.Angles(math.rad(-10-40*math.sin(sine/12)),math.rad(90+5*math.cos(sine/12)),math.rad(2.5*math.cos(sine/12))),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-.9+.2*math.cos(sine/12),-.5*math.sin(sine/12))*CFrame.Angles(math.rad(-10+40*math.sin(sine/12)),math.rad(-90+5*math.cos(sine/12)),math.rad(2.5*math.cos(sine/12))),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				end
			end
			Humanoid.WalkSpeed = 16
		elseif taunt.Value == "idkw" then -- ok....
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = 1
			change = 2 / Animation_Speed
			sensitivity = 10
			--eevol = 5
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if attack == false then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity/3.125 then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + .1 * COS(sine / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(30), RAD(0), RAD(0 + 25 * COS(sine / 20))), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5 + 0.35 * SIN(sine / 12), 0) * ANGLES(RAD(0), RAD(0), RAD(10 - 5 * COS(sine / 12))) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-.95, 0.5, 0.3) * ANGLES(RAD(-20), RAD(0), RAD(35)) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - .1 * COS(sine / 12), 0) * ANGLES(RAD(0), RAD(80), RAD(0)) * ANGLES(RAD(-3), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - .1 * COS(sine / 12), 0) * ANGLES(RAD(0), RAD(-80), RAD(0)) * ANGLES(RAD(-3), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity/3.125 then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 + .25*Cos(sine/63)+.92*Sin(sine/95), 0, 1 + 1 * SIN(sine / 53)) * ANGLES(RAD(70), RAD(0-RootPart.RotVelocity.y), RAD(0 - RootPart.RotVelocity.Y * 4.5 + 3 * COS(sine / 47))), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(12 - 4.10 * SIN(sine / 12))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12 + 4.10 * SIN(sine / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -.5 - 0.02 * SIN(sine / 12), -0.5) * ANGLES(RAD(-10 - 2.5 * SIN(sine / 21)), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.02 * SIN(sine / 12), -0.01) * ANGLES(RAD(-20 - 2.5 * SIN(sine / 51)), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)	
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 16
		elseif taunt.Value == "unholy" then
			if cannecksnap == true then
				local snap = math.random(1,6)
				local snap2 = math.random(1,2)
				if snap == 1 then
					Neck.C0 = Clerp(Neck.C0,NECKC0*CF(0,0,0)*ANGLES(math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000))),1/Animation_Speed)
				end
				if snap2 == 1 then
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1, 0.5, -0.6) * ANGLES(math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.5, -0.6) * ANGLES(math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
				end
			end
			change = 2 / Animation_Speed
			--eeepitch = 1
			--eevol = 5
			sensitivity = 25
			if HipValLock == false then
				HipVal = 3
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + 1 * SIN(sine / 26)) * ANGLES(RAD(25 - 2.5*SIN(sine/24)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-15 - 2.5 * SIN(sine / 12*5)), RAD(0), RAD(math.random(-5,5))), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1, 0.5, -0.6) * ANGLES(RAD(165), RAD(0), RAD(-50)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.5, -0.6) * ANGLES(RAD(165), RAD(0), RAD(50)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -.5 - 0.02 * SIN(sine / 12), -0.5) * ANGLES(RAD(-70 - 2.5 * SIN(sine / 32)), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.02 * SIN(sine / 12), -0.01) * ANGLES(RAD(-70 - 2.5 * SIN(sine / 16)), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + 1 * SIN(sine / 26)) * ANGLES(RAD(25 - 2.5*SIN(sine/24)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15), RAD(0), RAD(math.random(-5,5))), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(10), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(10), RAD(0), RAD(0)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -.5 - 0.02 * SIN(sine / 12), -0.5) * ANGLES(RAD(-70 - 2.5 * SIN(sine / 32)), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.02 * SIN(sine / 12), -0.01) * ANGLES(RAD(-70 - 2.5 * SIN(sine / 16)), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 30
		elseif taunt.Value == "uncolored" then
			change = 2 / Animation_Speed
			--eeepitch = .75
			--eevol = 5
			sensitivity = 25
			if HipValLock == false then
				HipVal = 2
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					snap = math.random(1,6)
					if snap == 1 then
						Neck.C0 = Clerp(Neck.C0,NECKC0*CF(0,0,0+((1)-1))*ANGLES(math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000)),math.rad(math.random(-10000,10000))),1/Animation_Speed)
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0,0,0+.5*COS(sine / 32))*ANGLES(RAD(-25 + 2*Cos(sine/42)),RAD(0),RAD(0)), 1 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-2.5+1*COS(sine / 12)), RAD(MRANDOM(-5,5)), RAD(0)), 1 / Animation_Speed) 
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(-30), RAD(0), RAD(15 - 5.5 * COS(sine / 20))) * RIGHTSHOULDERC0, 1 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(-30), RAD(0), RAD(-15 + 5.5 * COS(sine / 20))) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, -0.2) * ANGLES(RAD(-30+2*Cos(sine/32)), RAD(80), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.2) * ANGLES(RAD(-30+2*Cos(sine/46)), RAD(-80), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 + .25*Cos(sine/63)+.92*Sin(sine/95), 0, 1 + 1 * SIN(sine / 53)) * ANGLES(RAD(70), RAD(0-RootPart.RotVelocity.y), RAD(0 - RootPart.RotVelocity.Y * 4.5 + 3 * COS(sine / 47))), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(12 - 4.10 * SIN(sine / 12))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12 + 4.10 * SIN(sine / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -.5 - 0.02 * SIN(sine / 12), -0.5) * ANGLES(RAD(-10 - 2.5 * SIN(sine / 21)), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.02 * SIN(sine / 12), -0.01) * ANGLES(RAD(-20 - 2.5 * SIN(sine / 51)), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)	
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 120
		elseif taunt.Value == "error?" then
			change = 2 / Animation_Speed
			--eeepitch = 1
			--eevol = 5
			if HipValLock == false then
				HipVal = 1
			end
			sensitivity = 25
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				if math.random(1,3) == 1 then
					WACKYEFFECT({TIME = MRANDOM(15,25)*2, EffectType = "Sphere", Size = VT(3 + 2 * COS(sine2/4),3 + 2 * COS(sine2/4),3 + 2 * COS(sine2/4)), Size2 = VT(0,0,0), Transparency = 0, Transparency2 = -11, CFrame = CF(RootPart.Position-VT(MRANDOM(-20,20),2,MRANDOM(-20,20))), MoveToPos = Torso.Position+VT(0,MRANDOM(45,145)/1.5,0), RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = Color3.fromRGB(0,math.random(0,255),0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
					WACKYEFFECT({TIME = MRANDOM(0,22), EffectType = "Sphere", Size = VT(2 + 2 * COS(sine2/4),5 + 2 * COS(sine2/4),2 + 2 * COS(sine2/4)), Size2 = VT(-3,-6,-4), Transparency = 0, Transparency2 = 1, CFrame = RightArm.CFrame*CF(0,-1,0) * ANGLES(RAD(MRANDOM(-360,360)), RAD(MRANDOM(-360,360)), RAD(MRANDOM(-360,360))), MoveToPos = nil, RotationX = 0, RotationY = MRANDOM(-22,22), RotationZ = 0, Material = "Neon", Color = Color3.fromRGB(0,math.random(0,255),0), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					--WACKYEFFECT({Time = 2.5, EffectType = "Sphere", Size = VT(7+eee.PlaybackLoudness/25,0.55,7+eee.PlaybackLoudness/25), Size2 = VT(7+eee.PlaybackLoudness/25,0.55,7+eee.PlaybackLoudness/25), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,-3,0), MoveToPos = nil, RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = Color3.fromHSV(Hue/360,1,math.clamp(eee.PlaybackLoudness/950,0,1)), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0,0,0+.25*COS(sine2 / 12))*ANGLES(RAD(1+2.5*COS(sine2 / 12)),RAD(0),RAD(0)), 1 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(1-2.5*COS(sine2 / 12)), RAD(0), RAD(0)), 1 / Animation_Speed) 
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(90), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-.75, 0.5, -.7) * ANGLES(RAD(0), RAD(0), RAD(90)) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1-.05*COS(sine2 / 12), -0.01) * ANGLES(RAD(0), RAD(80), RAD(0)) * ANGLES(RAD(-8-2.5*COS(sine2/12)), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -.5-.05*COS(sine2  / 12), -0.5) * ANGLES(RAD(0), RAD(-80), RAD(0)) * ANGLES(RAD(-8-2.5*COS(sine2/12)), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					--WACKYEFFECT({Time = 2.5, EffectType = "Sphere", Size = VT(7+eee.PlaybackLoudness/25,0.55,7+eee.PlaybackLoudness/25), Size2 = VT(7+eee.PlaybackLoudness/25,0.55,7+eee.PlaybackLoudness/25), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0,-3,0), MoveToPos = nil, RotationX = 0, RotationY = 0, RotationZ = 0, Material = "Neon", Color = Color3.fromHSV(Hue/360,1,math.clamp(eee.PlaybackLoudness/950,0,1)), SoundID = nil, SoundPitch = nil, SoundVolume = nil})
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 + .25*Cos(sine2/63)+.92*Sin(sine2/95), 0, 0 + 1 * SIN(sine2 / 53)) * ANGLES(RAD(70), RAD(0-RootPart.RotVelocity.y), RAD(0 - RootPart.RotVelocity.Y * 4.5 + 3 * COS(sine2 / 47))), 0.15 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15 - 2.5 * SIN(sine2 / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(12 - 4.10 * SIN(sine2 / 12))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12 + 4.10 * SIN(sine2 / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -.5 - 0.02 * SIN(sine2 / 12), -0.5) * ANGLES(RAD(-10 - 2.5 * SIN(sine2 / 21)), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.02 * SIN(sine2 / 12), -0.01) * ANGLES(RAD(-20 - 2.5 * SIN(sine2 / 51)), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)	
					-----------------
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + 0.25 * COS(sine2 / 28)) * ANGLES(RAD(25+2.5*COS(sine2/28)), RAD(0), RAD(0)), 1 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0,NECKC0*CF(0,0,0+((1)-1))*ANGLES(RAD(-5+3.4*COS(sine2/28)),RAD(3*COS(sine2/28)),RAD(0)),1/Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CF(1.5, 0.5, 0)*ANGLES(RAD(-90-5*COS(sine2/28)),RAD(0),RAD(0))* RIGHTSHOULDERC0,1/Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-.75, 0.5, -.7) * ANGLES(RAD(0), RAD(0), RAD(90)) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1-.05*COS(sine2 / 28), -0.01) * ANGLES(RAD(-4), RAD(80), RAD(0)) * ANGLES(RAD(-8-2.5*COS(sine2/28)), RAD(0), RAD(0)), 1 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -.5-.05*COS(sine2  / 28), -0.5) * ANGLES(RAD(-8), RAD(-80), RAD(0)) * ANGLES(RAD(-8-2.5*COS(sine2/28)), RAD(0), RAD(0)), 1 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			Humanoid.WalkSpeed = 70
		elseif taunt.Value == "Err0r" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			--eevol = 5
			sensitivity = 25
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					local headsnap = math.random(1,60);
					local headsnapping=false;
					if headsnap == 1 then
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(500,500)), math.rad(math.random(500,500)), math.rad(math.random(500,500))), 1)headsnapping=true headsnapping=false
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 , 0 , 0 - .5 * math.sin(sine/25)) * CFrame.Angles(math.rad(20), math.rad(0), math.rad(0)), 0.8 / 3)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(0.25,3)), math.rad(math.random(0.25,3)), math.rad(math.random(0.25,3))), .7 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CFrame.new(1.5, 0.5, 0) * CFrame.Angles(math.rad(-41.6-4*math.sin(sine/25)), math.rad(math.random(-0.25,3)), math.rad(math.random(0.25,3)))* RIGHTSHOULDERC0, .7 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CFrame.new(-1.5, 0.5, 0) * CFrame.Angles(math.rad(20), math.rad(5+2* math.sin(sine/25+math.random(-0.25,3))), math.rad(-2+5*math.sin(sine / 25))) * LEFTSHOULDERC0, .7 / 3)
					RightHip.C0 = Clerp(RightHip.C0, CFrame.new(1, -1, 0) * CFrame.Angles(math.rad(-20-4*math.sin(sine/25-math.random(0.25,3))), math.rad(80), math.rad(0)), .7 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0, CFrame.new(-1, -1 , 0) * CFrame.Angles(math.rad(-10-4*math.sin(sine/25-math.random(-0.25,3))), math.rad(-80), math.rad(0)), .7 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					local headsnap = math.random(1,60);
					local headsnapping=false;
					if headsnap == 1 then
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(500,500)), math.rad(math.random(500,500)), math.rad(math.random(500,500))), 1)headsnapping=true headsnapping=false
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0 , 0 , 0 - .5 * math.sin(sine/25)) * CFrame.Angles(math.rad(20), math.rad(0), math.rad(0)), 0.8 / 3)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CFrame.new(0, 0, 0) * CFrame.Angles(25-math.rad(math.random(0.25,3)), math.rad(math.random(0.25,3)), math.rad(math.random(0.25,3))), .7 / 3)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CFrame.new(1.5, 0.5, 0) * CFrame.Angles(math.rad(-41.6-4*math.sin(sine/25)), math.rad(math.random(-0.25,3)), math.rad(math.random(0.25,3)))* RIGHTSHOULDERC0, .7 / 3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CFrame.new(-1.5, 0.5, 0) * CFrame.Angles(math.rad(90-4*math.sin(sine/25)), math.rad(5+2* math.sin(sine/25+math.random(-0.25,3))), math.rad(-2+5*math.sin(sine / 25))) * LEFTSHOULDERC0, .7 / 3)
					RightHip.C0 = Clerp(RightHip.C0, CFrame.new(1, -1, 0) * CFrame.Angles(math.rad(-30-4*math.sin(sine/25-math.random(0.25,3))), math.rad(80), math.rad(0)), .7 / 3)
					LeftHip.C0 = Clerp(LeftHip.C0, CFrame.new(-1, -1 , 0) * CFrame.Angles(math.rad(-20-4*math.sin(sine/25-math.random(-0.25,3))), math.rad(-80), math.rad(0)), .7 / 3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 50
		elseif taunt.Value == "Glitch" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			--eevol = 5
			change = 1
			sensitivity = 25
			WACKYEFFECT({Time = 1, EffectType = "Block", Size =VT(1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300), Size2 = VT(1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0+9*math.sin(sine/55),0+2*math.sin(sine/75),0+9*math.cos(sine/55))*CFrame.Angles(math.rad(-sine*1),math.rad(-sine*2),math.rad(-sine*3)), MoveToPos = nil, RotationX = nil, RotationY = 0, RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			WACKYEFFECT({Time = 1, EffectType = "Block", Size = VT(1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300), Size2 = VT(1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300,1+eee.PlaybackLoudness/300), Transparency = 0, Transparency2 = 1, CFrame = RootPart.CFrame*CF(0-9*math.sin(sine/55),0-2*math.sin(sine/75),0-9*math.cos(sine/55))*CFrame.Angles(math.rad(-sine*1),math.rad(-sine*2),math.rad(-sine*3)), MoveToPos = nil, RotationX = nil, RotationY = 0, RotationZ = 0, Material = "Neon", Color = GUN.NeonParts.Color, SoundID = nil, SoundPitch = nil, SoundVolume = nil})
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/9)) * CFrame.Angles(math.rad(-2.5*math.sin(sine/9)),math.rad(0),math.rad(0)),1/2)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new() * CFrame.Angles(math.rad(10-10*math.sin(sine/9)),math.rad(0),math.rad(0)),1/2)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5+.25*math.sin(sine/9),0) * CFrame.Angles(math.rad(135+5*math.sin(sine/9)),math.rad(0),math.rad(25)) * RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5+.25*math.sin(sine/9),0) * CFrame.Angles(math.rad(0+30*math.cos(sine/9)),math.rad(0),math.rad(-10+10*math.cos(sine/9))) * LEFTSHOULDERC0,.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-.01) * CFrame.Angles(math.rad(-10),math.rad(80),math.rad(5+5*math.sin(sine/9))),1/2)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.01) * CFrame.Angles(math.rad(0),math.rad(-80),math.rad(-5-5*math.sin(sine/9))),1/2)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/9)) * CFrame.Angles(math.rad(20-2.5*math.sin(sine/9)),math.rad(0),math.rad(0)),1/2)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new() * CFrame.Angles(math.rad(-10-10*math.sin(sine/9)),math.rad(0),math.rad(0)),1/2)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5+.25*math.sin(sine/9),0) * CFrame.Angles(math.rad(125+5*math.sin(sine/9)),math.rad(0),math.rad(25)) * RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5+.25*math.sin(sine/9),0) * CFrame.Angles(math.rad(-70+1*math.cos(sine/9)),math.rad(0),math.rad(0)) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-.01) * CFrame.Angles(math.rad(-10),math.rad(80),math.rad(5+5*math.sin(sine/9))),1/2)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.01) * CFrame.Angles(math.rad(0),math.rad(-80),math.rad(-5-5*math.sin(sine/9))),1/2)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				local partnum = math.random(1,48)
				coroutine.resume(coroutine.create(function()

					swait()
					if not alreadyfixing then
						print("but ex")
					end
				end))
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 50
		elseif taunt.Value == "X⁔X" then
			if HipValLock == false then
				HipVal = 2
			end
			--eeepitch = .8
			--eevol = 5
			change = 2 / Animation_Speed
			sensitivity = 25
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(15 - 6.5 * SIN(sine / 15)), RAD(10 * SIN(sine/32)), RAD(-10 + 5.5 * SIN(sine /15))), 3 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0 - 5.5 * SIN(sine/12)), RAD(5 * SIN(sine /12)), RAD(22 + 4.4 * SIN(sine /12))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0- 5.5 * SIN(sine /12)), RAD(5 * SIN(sine /12)), RAD(-22 + 4.4 * SIN(sine/12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, 0 + 1 * COS(sine / 39)) * ANGLES(RAD(0), RAD(0), RAD(10)), 0.8 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0) * ANGLES(RAD(0), RAD(80+10* SIN(sine / 78)), RAD(0)) * ANGLES(RAD(-3+1* SIN(sine / 58)), RAD(0), RAD(2.5+8 * SIN(sine / 43))), 0.8 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.5, -0.5) * ANGLES(RAD(0), RAD(-80-10* SIN(sine / 81)), RAD(0)) * ANGLES(RAD(-3+1* SIN(sine / 63)), RAD(0), RAD(0+15 * SIN(sine / 49))), 0.8 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.5 * COS(sine / 24)) * ANGLES(RAD(24), RAD(-5 * SIN(sine / 24)), RAD(0)), 0.4 / Animation_Speed*3)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-24), RAD(5 * SIN(sine / 24)), RAD(MRANDOM(-5.5,5.5))), 0.2)			
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5 + 0.15 * COS(sine / 24), 0) * ANGLES(RAD(-45), RAD(0), RAD(14 + 6.5* SIN(sine / 24)))* RIGHTSHOULDERC0, 0.15 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5 + 0.15 * COS(sine / 24), 0) * ANGLES(RAD(-45), RAD(0), RAD(-14 - 6.5 * SIN(sine / 24))) * LEFTSHOULDERC0, 0.4 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.1 * COS(sine / 24), 0) * ANGLES(RAD(-25), RAD(78), RAD(0)) * ANGLES(RAD(-5 * SIN(sine / 24)), RAD(0), RAD(5)), 0.4 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.3 - 0.1 * COS(sine / 24), -0.5) * ANGLES(RAD(0), RAD(-78), RAD(0)) * ANGLES(RAD(-5 * SIN(sine / 24)), RAD(0), RAD(5)), 0.4 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 100
		elseif taunt.Value == "Default" then -- it looks like powertommm's anim
			if HipValLock == false then -- but i made this
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10

			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				GUN.Base.Transparency = 0
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 0
				GUN.NeonParts.Transparency = 0

				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(25 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(45 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						RightHip.C0=Clerp(RightHip.C0,CF(1,-1 + 0.05 * math.cos(sine / 20)  - 0.02 * math.cos(sine / 40),0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3 + 2 * math.cos(sine / 40)),math.rad(-15),math.rad(0 + 2 * math.cos(sine / 20))),.1)
						LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1 + 0.05 * math.cos(sine / 20) - 0.02 * math.cos(sine / 40),0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3 - 2 * math.cos(sine / 40)),math.rad(1),math.rad(0 - 2 * math.cos(sine / 20))),.1)
						RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0 + 0.02 * math.cos(sine / 40),0 - 0.02 * math.cos(sine / 40),-0.05 - 0.05 * math.cos(sine / 20))*ANGLES(math.rad(0 + 2 * math.cos(sine / 20)),math.rad(0 + 2 * math.cos(sine / 40)),math.rad(30 + 3 * math.cos(sine / 40))),.1)
						Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(2),math.rad(0 - 7 * math.cos(sine / 40)),math.rad(-30 - 3 * math.cos(sine / 40))),.1)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(0.9, 0.5 + 0.05 * SIN(sine / 40), -0.5) * ANGLES(RAD(100), RAD(0), RAD(-70)) * RIGHTSHOULDERC0, 1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-0.9, 0.25 + 0.05 * SIN(sine / 40), -0.35) * ANGLES(RAD(70), RAD(0), RAD(80)) * LEFTSHOULDERC0, 1 / 3)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(5 - 2* SIN(sine / 6)), RAD(0), RAD(0-1*COS(sine / 12))), 0.8 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0-25* SIN(sine / 12)), RAD(0), RAD(12+5*COS(sine / 6))) * RIGHTSHOULDERC0, 0.8 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0+25* SIN(sine / 12)), RAD(0), RAD(-12-5*COS(sine / 6))) * LEFTSHOULDERC0, 0.8 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, -0.1+0.1* COS(sine / 6)) * ANGLES(RAD(5-1*math.cos(sine/12)), RAD(0+1*COS(sine / 12)), RAD(0-2*SIN(sine / 12))), 0.8 / 3)
						RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0-0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(-5), RAD(-5 + 45 * SIN(sine / 12))), 0.8 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0+0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(5), RAD(5 + 45 * SIN(sine / 12))), 0.8 / 3)
					end
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 16
		elseif taunt.Value == "lostsos" then -- it looks like powertommm's anim
			if HipValLock == false then -- but i made this
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10

			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1

				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.1 + 0.1 * COS(sine / 20)) * ANGLES(RAD(10), RAD(0), RAD(0)), 0.3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * ANGLES(RAD(-40), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(-40), RAD(0), RAD(20)) * RIGHTSHOULDERC0, 0.2 / 1.75)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0 * 1) * ANGLES(RAD(-40), RAD(0), RAD(-20)) * LEFTSHOULDERC0, 0.2 / 1.75)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, -0.3) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(-20)), 0.2 / 1.75)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.3) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(20)), 0.2 / 1.75)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.1 + 0.1 * COS(sine / 20)) * ANGLES(RAD(-5), RAD(0), RAD(0)), 0.3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * ANGLES(RAD(40), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(60)) * RIGHTSHOULDERC0, 0.2 / 1.75)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-60)) * LEFTSHOULDERC0, 0.2 / 1.75)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(20)), 0.2 / 1.75)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(10)), 0.2 / 1.75)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, -0.1, -0.1 + 0.05 * COS(sine / 12)) * ANGLES(RAD(15), RAD(0), RAD(0)), 0.15 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5 + 0.025 * COS(sine / 12), 0) * ANGLES(RAD(0), RAD(0 - 7.5 * SIN(sine / 12)), RAD(12 + 7.5 * SIN(sine / 12))) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5 + 0.025 * COS(sine / 12), 0) * ANGLES(RAD(0), RAD(0 + 7.5 * SIN(sine / 12)), RAD(-12 - 7.5 * SIN(sine / 12))) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(sine / 12), -0.01) * ANGLES(RAD(20), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(sine / 12), -0.01) * ANGLES(RAD(5), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * ANGLES(RAD(20), RAD(-10 - 2.5 * SIN(sine / 10)), RAD(20 * COS(sine / 10))), 1 / Animation_Speed)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.175 + 0.025 * COS(sine / 3.5) + -SIN(sine / 3.5) / 7) * ANGLES(RAD(9-2.5 * COS(sine / 3.5)), RAD(0), RAD(10 * COS(sine / 7))), 0.15)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(20 + MRANDOM(-5,5) - 1 * SIN(sine / (WALKSPEEDVALUE / 2))), RAD(MRANDOM(-5,5)), RAD(0)), 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -0.925 - 0.5 * COS(sine / 7) / 2, 0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 - 35 * COS(sine / 7)) + -SIN(sine / 7) / 2.5, RAD(90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 + 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.925 + 0.5 * COS(sine / 7) / 2, -0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 + 35 * COS(sine / 7)) + SIN(sine / 7) / 2.5, RAD(-90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 - 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1, 0.5 + 0.05 * SIN(sine / 30), 0.025 * COS(sine / 20)) * ANGLES(RAD(70) * COS(sine / 7) , RAD(90), RAD(5)), 0.1)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.5 + 0.05 * SIN(sine / 30), 0.025 * COS(sine / 20)) * ANGLES(RAD(-70) * COS(sine / 7) , RAD(-90),	RAD(-5)), 0.1)
					end
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 16
		elseif taunt.Value == "echoes" then -- it looks like powertommm's anim
			if HipValLock == false then -- but i made this
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10
			sick = eee
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1

				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.1 + 0.1 * COS(sine / 20)) * ANGLES(RAD(10), RAD(0), RAD(0)), 0.3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * ANGLES(RAD(-40), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(-40), RAD(0), RAD(20)) * RIGHTSHOULDERC0, 0.2 / 1.75)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0 * 1) * ANGLES(RAD(-40), RAD(0), RAD(-20)) * LEFTSHOULDERC0, 0.2 / 1.75)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, -0.3) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(-20)), 0.2 / 1.75)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.3) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(20)), 0.2 / 1.75)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.1 + 0.1 * COS(sine / 20)) * ANGLES(RAD(-5), RAD(0), RAD(0)), 0.3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * ANGLES(RAD(40), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(60)) * RIGHTSHOULDERC0, 0.2 / 1.75)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-60)) * LEFTSHOULDERC0, 0.2 / 1.75)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(20)), 0.2 / 1.75)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(10)), 0.2 / 1.75)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 , 0 , -0.2 + 0.2*COS(sine / 13) ) * ANGLES(RAD(-20), RAD(0), RAD(0)), 0.35 / Animation_Speed)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(-20+MRANDOM(-15-eee.PlaybackLoudness/200,15+eee.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200))), 0.35 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5+ 0.2*COS(sine / 13), 0) * ANGLES(RAD(-20+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)))* RIGHTSHOULDERC0, 0.35 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5+ 0.2*COS(sine / 13), 0) * ANGLES(RAD(-20+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200)), RAD(0+MRANDOM(-15-sick.PlaybackLoudness/200,15+sick.PlaybackLoudness/200))) * LEFTSHOULDERC0, 0.35 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1- 0.2*COS(sine / 13), 0) * ANGLES(RAD(-20), RAD(0), RAD(0)) * ANGLES(RAD(0), RAD(90), RAD(0)), 0.35 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1- 0.2*COS(sine / 13) , 0) * ANGLES(RAD(-20), RAD(0), RAD(0)) * ANGLES(RAD(0), RAD(-90), RAD(0)), 0.35 / Animation_Speed)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.175 + 0.025 * COS(sine / 3.5) + -SIN(sine / 3.5) / 7) * ANGLES(RAD(9-2.5 * COS(sine / 3.5)), RAD(0), RAD(10 * COS(sine / 7))), 0.15)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(20 + MRANDOM(-5,5) - 1 * SIN(sine / (WALKSPEEDVALUE / 2))), RAD(MRANDOM(-5,5)), RAD(0)), 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -0.925 - 0.5 * COS(sine / 7) / 2, 0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 - 35 * COS(sine / 7)) + -SIN(sine / 7) / 2.5, RAD(90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 + 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.925 + 0.5 * COS(sine / 7) / 2, -0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 + 35 * COS(sine / 7)) + SIN(sine / 7) / 2.5, RAD(-90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 - 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1, 0.5 + 0.05 * SIN(sine / 30), 0.025 * COS(sine / 20)) * ANGLES(RAD(70) * COS(sine / 7) , RAD(90), RAD(5)), 0.1)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1, 0.5 + 0.05 * SIN(sine / 30), 0.025 * COS(sine / 20)) * ANGLES(RAD(-70) * COS(sine / 7) , RAD(-90),	RAD(-5)), 0.1)
					end
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 16
		elseif taunt.Value == "pandora" then -- it looks like powertommm's anim
			if HipValLock == false then -- but i made this
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10
			SIZE = 1
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1

				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0*SIZE, 0*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0*SIZE, 0*SIZE, 0 + ((1.1*SIZE) - 1)) * ANGLES(RAD(-20), RAD(0), RAD(0)), 1 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5*SIZE, 0.5*SIZE, 0*SIZE) * ANGLES(RAD(-40), RAD(0), RAD(20)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5*SIZE, 0.5*SIZE, 0*SIZE) * ANGLES(RAD(-40), RAD(0), RAD(-20)) * LEFTSHOULDERC0, 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1*SIZE, -1*SIZE, -0.3*SIZE) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(-20)), 1 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1*SIZE, -1*SIZE, -0.3*SIZE) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(20)), 1 / Animation_Speed)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0*SIZE, 0*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(0), RAD(0)), 1 / Animation_Speed)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0*SIZE, 0*SIZE, 0 + ((1.1*SIZE) - 1)) * ANGLES(RAD(20), RAD(0), RAD(0)), 1 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5*SIZE, 0.5*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(0), RAD(60)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5*SIZE, 0.5*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(0), RAD(-60)) * LEFTSHOULDERC0, 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1*SIZE, -1*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(20)), 1 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1*SIZE, -1*SIZE, 0*SIZE) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(10)), 1 / Animation_Speed)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0 - 0.04 * SIN(sine / 24)*SIZE, 0 + 0.04 * SIN(sine / 12)*SIZE, 0 + 0.05*SIZE * COS(sine / 12)) * ANGLES(RAD(0 - 2.5 * SIN(sine / 12)), RAD(0 - 2.5 * SIN(sine / 24)), RAD(0)), 1 / Animation_Speed)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1.1*SIZE) - 1)) * ANGLES(RAD(25 - 4 * SIN(sine / 12)), RAD(0), RAD(0)), 1 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.25*SIZE, 0.5*SIZE, 0.5*SIZE) * ANGLES(RAD(-35), RAD(-25 + 2.5 * SIN(sine / WALKSPEEDVALUE)), RAD(-55 + 2.5 * SIN(sine / WALKSPEEDVALUE))) * RIGHTSHOULDERC0, 1 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.25*SIZE, 0.5*SIZE, 0.5*SIZE) * ANGLES(RAD(-35), RAD(25 - 2.5 * SIN(sine / WALKSPEEDVALUE)), RAD(55 - 2.5 * SIN(sine / WALKSPEEDVALUE))) * LEFTSHOULDERC0, 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1*SIZE, -1*SIZE + 0.06 * SIN(sine / 24) - 0.05*SIZE * COS(sine / 12), -0.01*SIZE) * ANGLES(RAD(0 - 2.5 * SIN(sine / 12)), RAD(75), RAD(0)) * ANGLES(RAD(-2 - 2.5 * SIN(sine / 24)), RAD(0), RAD(0)), 1 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1*SIZE, -1*SIZE - 0.06 * SIN(sine / 24) - 0.05*SIZE * COS(sine / 12), -0.01*SIZE) * ANGLES(RAD(0 - 2.5 * SIN(sine / 12)), RAD(-75), RAD(0)) * ANGLES(RAD(-2 + 2.5 * SIN(sine / 24)), RAD(0), RAD(0)), 1 / Animation_Speed)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -0.175 + 0.025 * COS(sine / 3.5) + -SIN(sine / 3.5) / 7) * ANGLES(RAD(9-2.5 * COS(sine / 3.5)), RAD(0), RAD(10 * COS(sine / 7))), 0.15)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1.1*SIZE) - 1)) * ANGLES(RAD(15 - 1 * SIN(sine / (WALKSPEEDVALUE / 2))), RAD(0), RAD(0)), 1/ Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.25*SIZE, 0.5*SIZE, 0.5*SIZE) * ANGLES(RAD(-35), RAD(-25 + 2.5 * SIN(sine / WALKSPEEDVALUE)), RAD(-55 + 2.5 * SIN(sine / WALKSPEEDVALUE))) * RIGHTSHOULDERC0, 1 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.25*SIZE, 0.5*SIZE, 0.5*SIZE) * ANGLES(RAD(-35), RAD(25 - 2.5 * SIN(sine / WALKSPEEDVALUE)), RAD(55 - 2.5 * SIN(sine / WALKSPEEDVALUE))) * LEFTSHOULDERC0, 1 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -0.925 - 0.5 * COS(sine / 7) / 2, 0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 - 35 * COS(sine / 7)) + -SIN(sine / 7) / 2.5, RAD(90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 + 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.925 + 0.5 * COS(sine / 7) / 2, -0.5 * COS(sine / 7) / 2) * ANGLES(RAD(-15 + 35 * COS(sine / 7)) + SIN(sine / 7) / 2.5, RAD(-90 - 2 * COS(sine / 7)), RAD(0)) * ANGLES(RAD(0 - 2.5 * COS(sine / 7)), RAD(0), RAD(0)), 0.3)
					end
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 16
		elseif taunt.Value == "Matt" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			--eevol = 5
			sensitivity = 25
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			if attack == false then
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/15*2)) * CFrame.Angles(math.rad(0),math.rad(-10*math.cos(sine/30*2)),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(0),math.rad(-15*math.cos(sine/30*2)),math.rad(0)),1/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(135+-15*math.cos(sine/30*2)),math.rad(0),math.rad(25+15*math.cos(sine/30*2))) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(5),math.rad(5),math.rad(-10+15*math.cos(sine/30*2))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-0.01) * CFrame.Angles(math.rad(-10),math.rad(80),math.rad(10+10*math.sin(sine/15*2))),1/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-0.01) * CFrame.Angles(math.rad(0),math.rad(-80),math.rad(-10-10*math.sin(sine/15*2))),1/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				elseif Torsovelocity >= sensitivity then
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 + .5 * math.cos(sine/15*2)) * CFrame.Angles(math.rad(40),math.rad(-5*math.cos(sine/30*2)),math.rad(0)),0.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-40),math.rad(0),math.rad(0)),0.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(5 + 2 * math.cos(sine/19))) * RIGHTSHOULDERC0,0.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(-5 - 2 * math.cos(sine/19))) * LEFTSHOULDERC0,0.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.5,-0.5) * CFrame.Angles(math.rad(-20 + 9 * math.cos(sine/74*2)),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(0 + 5 * math.cos(sine/37)),math.rad(0),math.rad(0)),0.7/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(-20 - 9 * math.cos(sine/54*2)),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(0 - 5 * math.cos(sine/41)),math.rad(0),math.rad(0)),0.7/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
				end
				local partnum = math.random(1,48)
				coroutine.resume(coroutine.create(function()
					swait()
					if not alreadyfixing then
						warn("no more wingy wingy")
					end
				end))
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
			walkspeed = 200
		elseif taunt.Value == "BadKarma" then
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10
			if math.random(0,20) == 1 then
				print("sus")
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(25 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(45 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(100),math.rad(180),math.rad(0)),1 / 3)
						RightHip.C0=Clerp(RightHip.C0,CF(1,-1 + 0.05 * math.cos(sine / 20)  - 0.02 * math.cos(sine / 40),0)*ANGLES(math.rad(0),math.rad(90),math.rad(0))*ANGLES(math.rad(-3 + 2 * math.cos(sine / 40)),math.rad(0 - 6 * math.cos(sine / 40)),math.rad(-6 + 2 * math.cos(sine / 20) - 6 * math.cos(sine / 40))),.1)
						LeftHip.C0=Clerp(LeftHip.C0,CF(-1,-1 + 0.05 * math.cos(sine / 20) - 0.02 * math.cos(sine / 40),0)*ANGLES(math.rad(0),math.rad(-90),math.rad(0))*ANGLES(math.rad(-3 - 2 * math.cos(sine / 40)),math.rad(10 - 6 * math.cos(sine / 40)),math.rad(3 - 2 * math.cos(sine / 20) - 3 * math.cos(sine / 40))),.1)
						RootJoint.C0=Clerp(RootJoint.C0,ROOTC0*CF(0 + 0.02 * math.cos(sine / 40),0 - 0.06 * math.cos(sine / 40),-0.05 - 0.05 * math.cos(sine / 20))*ANGLES(math.rad(0 + 2 * math.cos(sine / 20)),math.rad(0 + 2 * math.cos(sine / 40)),math.rad(-20 + 6 * math.cos(sine / 40))),.1)
						Torso.Neck.C0=Clerp(Torso.Neck.C0,NECKC0*ANGLES(math.rad(6),math.rad(0 - 2 * math.cos(sine / 42)),math.rad(20 - 6 * math.cos(sine / 40))),.1)
						RightShoulder.C0=Clerp(RightShoulder.C0,CF(1,0.5 + 0.05 * math.cos(sine / 28),0.1)*ANGLES(math.rad(-13 + 3 * math.cos(sine / 26)),math.rad(-20 - 3 * math.cos(sine / 24)),math.rad(20 - 5 * math.cos(sine / 34)))*ANGLES(RAD(0),RAD(90),RAD(0)),.1)
						LeftShoulder.C0=Clerp(LeftShoulder.C0,CF(-1,0.5 + 0.05 * math.cos(sine / 28),0.1)*ANGLES(math.rad(-13 - 3 * math.cos(sine / 25)),math.rad(10 + 3 * math.cos(sine / 24)),math.rad(-10 + 5 * math.cos(sine / 34)))*ANGLES(RAD(0),RAD(-90),RAD(0)),.1)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(90),math.rad(180),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(5 - 2* SIN(sine / 6)), RAD(0), RAD(0-1*COS(sine / 12))), 0.8 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(-1+1* SIN(sine / 12)), RAD(0), RAD(12+2*SIN(sine / 12))) * RIGHTSHOULDERC0, 0.8 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0+25* SIN(sine / 12)), RAD(0), RAD(-12-5*COS(sine / 6))) * LEFTSHOULDERC0, 0.8 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, -0.1+0.1* COS(sine / 6)) * ANGLES(RAD(5-1*math.cos(sine/12)), RAD(0+1*COS(sine / 12)), RAD(0-2*SIN(sine / 12))), 0.8 / 3)
						RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0-0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(-5), RAD(-5 + 45 * SIN(sine / 12))), 0.8 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0+0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(5), RAD(5 + 45 * SIN(sine / 12))), 0.8 / 3)
					end
				end
			end
			walkspeed = 16
		elseif taunt.Value == "Visualizer" then
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = .8
			--eevol = 5
			change = 1
			sensitivity = 10
			if math.random(0,20) == 1 then
				print("r")
			end
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if RootPart.Velocity.y > 1 and hit == nil then 
					Anim = "Jump"
					if true then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.36) * CFrame.Angles(math.rad(-3),math.rad(0),math.rad(0)),1 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(-25),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(25 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(50),math.rad(0),math.rad(-25 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.4,-0.6) * CFrame.Angles(math.rad(1),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-85),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif RootPart.Velocity.y < -1 and hit == nil then 
					Anim = "Fall"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.36) * CFrame.Angles(math.rad(-34),math.rad(0),math.rad(0)),1 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(0,0 ,0 + ((1) - 1)) * CFrame.Angles(math.rad(15),math.rad(0),math.rad(0)),1 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(45 + 10 * math.cos(sine / 12))) * rscp,1 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(35 - 4 * math.cos(sine / 6)),math.rad(0),math.rad(-45 - 10 * math.cos(sine / 12))) * lscp,1 / 3)
						RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-0.3,-0.7) * CFrame.Angles(math.rad(-25 + 5 * math.sin(sine / 12)),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-0.8,-0.3) * CFrame.Angles(math.rad(-10),math.rad(-80),math.rad(0)) * CFrame.Angles(math.rad(-1 * math.sin(sine / 6)),math.rad(0),math.rad(0)),1 / 3)
					end
				elseif Torsovelocity < 1 and hit ~= nil then
					Anim = "Idle"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.36) * CFrame.Angles(math.rad(-34),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(2 + 6.0 * SIN(sine / 15)), RAD(0), RAD(-25)), 3 / Animation_Speed)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0- 0.1 * COS(sine / 30), 0 + 0.1 * COS(sine / 15)) * ANGLES(RAD(0+ 5 * COS(sine / 30)), RAD(0), RAD(25)), 1 / Animation_Speed)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0+6.0 * COS(sine / 30)), RAD(0), RAD(12))* RIGHTSHOULDERC0, 0.15 / Animation_Speed)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0+6.0 * COS(sine / 30)), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
						RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.1 * COS(sine / 15), -0.01) * ANGLES(RAD(0), RAD(75), RAD(0)) * ANGLES(RAD(-6-2.5 * COS(sine / 30)), RAD(0), RAD(0+ 5 * COS(sine / 30))), 1 / Animation_Speed)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.1 * COS(sine / 15), -0.01) * ANGLES(RAD(0), RAD(-75), RAD(0)) * ANGLES(RAD(-6+2.5 * COS(sine / 30)), RAD(0), RAD(0- 5 * COS(sine / 30))), 1 / Animation_Speed)
					end
				elseif Torsovelocity > 2 and hit ~= nil then
					Anim = "Walk"
					if not attack then
						GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.36) * CFrame.Angles(math.rad(-34),math.rad(0),math.rad(0)),1 / 3)
						Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(5 - 2* SIN(sine / 6)), RAD(0), RAD(0-1*COS(sine / 12))), 0.8 / 3)
						RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(-1+1* SIN(sine / 12)), RAD(0), RAD(12+2*SIN(sine / 12))) * RIGHTSHOULDERC0, 0.8 / 3)
						LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0+25* SIN(sine / 12)), RAD(0), RAD(-12-5*COS(sine / 6))) * LEFTSHOULDERC0, 0.8 / 3)
						RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0, 0, -0.1+0.1* COS(sine / 6)) * ANGLES(RAD(5-1*math.cos(sine/12)), RAD(0+1*COS(sine / 12)), RAD(0-2*SIN(sine / 12))), 0.8 / 3)
						RightHip.C0 = Clerp(RightHip.C0, CF(1 , -1, 0-0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(-5), RAD(-5 + 45 * SIN(sine / 12))), 0.8 / 3)
						LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0+0.07*SIN(sine/12)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(5), RAD(5 + 45 * SIN(sine / 12))), 0.8 / 3)
					end
				end
			end
			walkspeed = 16
		elseif taunt.Value == "Pazolite" then
			if HipValLock == false then
				HipVal = 3
			end
			--eeepitch = 1
			change = 1
			--eevol = 5
			sensitivity = 25
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/9)) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(0)),.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,-.05,0) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)),.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.25,.5,-.1) * CFrame.Angles(math.rad(45),math.rad(-45),math.rad(0)) * RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1,.75,.1) * CFrame.Angles(math.rad(-165),math.rad(0),math.rad(40)) * LEFTSHOULDERC0,.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-12.5),math.rad(90),math.rad(0)) * CFrame.Angles(math.rad(10),math.rad(0),math.rad(0)),.7/3)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(12.5),math.rad(-90),math.rad(0)) * CFrame.Angles(math.rad(10),math.rad(0),math.rad(0)),.7/3)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				elseif Torsovelocity >= sensitivity then
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0 - .5 * math.sin(sine/9)) * CFrame.Angles(math.rad(45),math.rad(0),math.rad(0)),.7/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new(0,-.05,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)),.7/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,-.1) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)) * RIGHTSHOULDERC0,.7/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(135),math.rad(0),math.rad(0)) * LEFTSHOULDERC0,.7/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-.01) * CFrame.Angles(math.rad(-10),math.rad(80),math.rad(5+5*math.sin(sine/9))),1/2)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.01) * CFrame.Angles(math.rad(0),math.rad(-80),math.rad(-5-5*math.sin(sine/9))),1/2)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				end
				local partnum = math.random(1,48)
				coroutine.resume(coroutine.create(function()

					swait()
					if not alreadyfixing then
						print("e")
					end
				end))
			end
			walkspeed = 50
		elseif taunt.Value == "FAST BOIII" then
			change = 1
			if HipValLock == false then
				HipVal = 0
			end
			--eeepitch = 1
			--eevol = 5
			sensitivity = 25

			local vAlUe = 100
			RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
			Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
			RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
			LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
			RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
			LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
			Humanoid.WalkSpeed = walkspeed*6
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if Torsovelocity < sensitivity then
					Anim = "Idle"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,.2) * CFrame.Angles(math.rad(-sine*6),math.rad(0),math.rad(0)),.25)
					Neck.C0 = Clerp(Neck.C0,NECKC0,.25)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.5,0) * CFrame.Angles(math.rad(-75*math.sin(sine/5)),math.rad(0),math.rad(0)) * RIGHTSHOULDERC0,.25)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.5,0) * CFrame.Angles(math.rad(75*math.sin(sine/5)),math.rad(0),math.rad(0)) * LEFTSHOULDERC0,.25)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-.01) * CFrame.Angles(math.rad(75*math.sin(sine/5)),math.rad(90),math.rad(0)),.25)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.01) * CFrame.Angles(math.rad(-75*math.sin(sine/5)),math.rad(-90),math.rad(0)),.25)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),.25)
				elseif Torsovelocity >= sensitivity then -- i modified anim
					Anim = "Walk"
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)),.25/3)
					Neck.C0 = Clerp(Neck.C0,NECKC0 * CFrame.new() * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)),.25/3)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,.6,.5) * CFrame.Angles(math.rad(-135),math.rad(0),math.rad(0)) * RIGHTSHOULDERC0,.75/3)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,.6,.5) * CFrame.Angles(math.rad(-135),math.rad(0),math.rad(0)) * LEFTSHOULDERC0,.75/3)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,-.01) * CFrame.Angles(math.rad(180+-sine*vAlUe),math.rad(90),math.rad(0)),1)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,-.01) * CFrame.Angles(math.rad(-sine*vAlUe),math.rad(-90),math.rad(0)),1)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
					GUN.Base.Transparency = 1
					GUN.Gun.Transparency = 0
					GUN.GunAdditions.Transparency = 1
					GUN.NeonParts.Transparency = 1
				end
			else
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 0
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
			end
		else
			if not attack then
				GUN.Base.Transparency = 1
				GUN.Gun.Transparency = 1
				GUN.GunAdditions.Transparency = 1
				GUN.NeonParts.Transparency = 1
				if HipValLock == false then
					HipVal = 0
				end
				if taunt.Value == "Krump" then
					walkspeed = 6
					change = 1
					--eeepitch = 1
					if HipValLock == false then
						HipVal = 0
					end
					RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0+1*math.sin(sine/3),0+1*math.cos(sine/3),-.75) * CFrame.Angles(math.rad(0),math.rad(-10),math.rad(0)),1)
					Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new(),1)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,1,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)) * rscp,1)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,1,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)) * lscp,1)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1.5,-1,0) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(70)),1)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-.5,-1.25,-.25) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10)),1)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(),1)
					RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
					LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)

				elseif taunt.Value == "Sus" then
					walkspeed = 6

					--Anim Fixer
					RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
					Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
					RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
					LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
					--End


					change = 1
					--eeepitch = 1
					if HipValLock == false then
						HipVal = 0
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(-0.25 * COS(LOOPx / 50), 0, -0.5 - 0.5 * COS(LOOPx / 25)) * ANGLES(RAD(0), RAD(0), RAD(45 * SIN(LOOPx / 50))) * ANGLES(RAD(45 + 22.5 * COS(LOOPx / 25)), RAD(0), RAD(0)), 2 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(-45 - 22.5 * COS(LOOPx / 25)), RAD(0), RAD(-45 * SIN(LOOPx / 50))), 2 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(175+65 * SIN(LOOPx / 25)), RAD(0), RAD(-45 * SIN(LOOPx / 12.5))) * CF(0,-0.5,0) * RIGHTSHOULDERC0, 1 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(175+65 * SIN(LOOPx / 25)), RAD(0), RAD(45 * SIN(LOOPx / 12.5))) * CF(0,-0.5,0) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -0.5 + 0.5 * COS(LOOPx / 25), -0.5 - 0.5 * COS(LOOPx / 25)) * ANGLES(RAD(0), RAD(70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 2 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -0.5 + 0.5 * COS(LOOPx / 25), -0.5 - 0.5 * COS(LOOPx / 25)) * ANGLES(RAD(0), RAD(-70), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 2 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				elseif taunt.Value == "when" then
					walkspeed = 6
					--Anim Fixer
					RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
					Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
					RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
					LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
					--End

					change = 1
					--eeepitch = 1
					if HipValLock == false then
						HipVal = 0
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(0,0,0) * ANGLES(RAD(-sine*500), RAD(0), RAD(0)), 2 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0 + ((1) - 1)) * ANGLES(RAD(0), RAD(0), RAD(0)), 2 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(0)) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 ,0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 2 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 2 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				elseif taunt.Value == "OOOOO" then
					walkspeed = 30
					if HipValLock == false then
						HipVal = 0
					end
					change = 1

					--eeepitch = 1
					sensitivity = 25
					if not eee:FindFirstChildOfClass("DistortionSoundEffect") then
						local dse = Instance.new("DistortionSoundEffect")
						dse.Priority = 2147483647
						dse.Level = 1
						dse.Name = randomstring()
						dse.Parent = eee
						coroutine.resume(coroutine.create(function()
							repeat swait() until not dse:IsDescendantOf(game) or taunt.Value ~= "OOOOO"
							if not soundfixing then
								soundfixing = true
								dse:Destroy()
								soundfixing = false
							end
						end))
					end
					RootJoint.C0 = Clerp(RootJoint.C0,rc0*CFrame.new(math.random(-1,1)/2,math.random(-1,1)/2,math.random(-1,1)/2)*CFrame.Angles(math.rad(math.random(-45,45)),math.rad(math.random(-45,45)),0),1)
					Neck.C0 = Clerp(Neck.C0,nc0,1)
					RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(2,0,0) * rscp * CFrame.Angles(math.rad(-90),0,0),1)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-2,0,0) * lscp * CFrame.Angles(math.rad(-90),0,0),1)
					RightHip.C0 = Clerp(RightHip.C0,CFrame.new(.5,-2,0),1)
					LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-.5,-2,0),1)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(),1)
					RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
					LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0,-1,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
				elseif taunt.Value == "UpsideDown" then -- my anim
					change = 1
					--eeepitch = 1
					--eevol = 5
					sensitivity = 25
					if HipValLock == false then
						HipVal = 6
					end
					RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0 * CFrame.new(0,0,0),0.2/3)
					Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-0.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),0.2/3)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(0.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-0.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
					if attack == false then
						GUN.Base.Transparency = 1
						GUN.Gun.Transparency = 1
						GUN.GunAdditions.Transparency = 1
						GUN.NeonParts.Transparency = 1
						if Torsovelocity < sensitivity then
							Anim = "Idle"
							HoverBoard.Base.Joint.C0 = Clerp(HoverBoard.Base.Joint.C0,CFrame.new(0,3.2,0) * CFrame.Angles(math.rad(0+3*math.cos(sine/55)),math.rad(-10),math.rad(0+3*math.cos(sine/50))) * CFrame.new(0,eee.PlaybackLoudness/5000,0),1 / 3)
							RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(0),math.rad(-180),math.rad(0)) * CFrame.Angles(0,math.rad(0+2*math.cos(sine/61.5)),0),1 / 3)
							Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(5),math.rad(0),math.rad(0)),1 / 3)
							RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(180),math.rad(0),math.rad(0 - 3 * math.cos(sine / 45))) * rscp,1 / 3)
							LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(180),math.rad(0),math.rad(0 + 3 * math.cos(sine / 45))) * lscp,1 / 3)
							RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1,0) * CFrame.Angles(math.rad(-5),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
							LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1,0) * CFrame.Angles(math.rad(0),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
							GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(.05,-1,-.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
						elseif Torsovelocity >= sensitivity then
							Anim = "Walk"
							HoverBoard.Base.Joint.C0 = Clerp(HoverBoard.Base.Joint.C0,CFrame.new(0,3.2,0) * CFrame.Angles(math.rad(-15+3*math.cos(sine/55)),0,math.rad(0+3*math.cos(sine/50))) * CFrame.new(0,0+.1*math.cos(sine/40),0),1 / 3)
							RootJoint.C0 = Clerp(RootJoint.C0,rc0 * CFrame.new(0 + .5 * math.cos(sine/50),0,0 - .5 * math.sin(sine/50)) * CFrame.Angles(math.rad(35),math.rad(0+2*math.cos(sine/61.5)),math.rad(0)) * CFrame.new(0,0,0+.1*math.cos(sine/40)),.5)
							Neck.C0 = Clerp(Neck.C0,nc0 * CFrame.new() * CFrame.Angles(math.rad(-15),math.rad(0),math.rad(0)),1 / 3)
							RightShoulder.C0 = Clerp(RightShoulder.C0,CFrame.new(1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(5-5 * math.cos(sine/50))) * rscp,1 / 3)
							LeftShoulder.C0 = Clerp(LeftShoulder.C0,CFrame.new(-1.5,0.5,0) * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(-5+5 * math.cos(sine/50))) * lscp,1 / 3)
							RightHip.C0 = Clerp(RightHip.C0,CFrame.new(1,-1-.1*math.cos(sine/40),0) * CFrame.Angles(math.rad(36),math.rad(80),math.rad(0)) * CFrame.Angles(math.rad(-4),math.rad(0),math.rad(0)),1 / 3)
							LeftHip.C0 = Clerp(LeftHip.C0,CFrame.new(-1,-1-.1*math.cos(sine/40),0) * CFrame.Angles(math.rad(-6),math.rad(-70),math.rad(0)) * CFrame.Angles(math.rad(-5),math.rad(0),math.rad(0)),1 / 3)
							GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(0.05,-1,-0.15) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1/2)
						end
					else
						GUN.Base.Transparency = 1
						GUN.Gun.Transparency = 0
						GUN.GunAdditions.Transparency = 1
						GUN.NeonParts.Transparency = 1
					end
					walkspeed = 100
				elseif taunt.Value == "h" then -- my anim
					if HipValLock == false then
						HipVal = 0
					end
					change = 1
					--eeepitch = 1
					sensitivity = 25
					if not eee:FindFirstChildOfClass("DistortionSoundEffect") then
						local dse = Instance.new("DistortionSoundEffect")
						dse.Priority = 2147483647
						dse.Level = .99
						dse.Name = randomstring()
						dse.Parent = eee

					end
					--Anim Fixer
					RootJoint.C1 = Clerp(RootJoint.C1,ROOTC0,.2/3)
					Neck.C1 = Clerp(Neck.C1,CFrame.new(0,-.5,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(180)),.2/3)
					RightHip.C1 = Clerp(RightHip.C1,CFrame.new(.5,1,0,-4.37113918e-08,0,1,0,1,0,-1,0,-4.37113918e-08),1)
					LeftHip.C1 = Clerp(LeftHip.C1,CFrame.new(-.5,1,0,-4.37113918e-08,-0,-1,0,1,-0,1,0,-4.37113918e-08),1)
					RightShoulder.C1 = Clerp(RightShoulder.C1,CFrame.new(-.5,.5,0,0,0,1,0,1,-0,-1,0,0),1)
					LeftShoulder.C1 = Clerp(LeftShoulder.C1,CFrame.new(.5,.499975681,0,0,0,-1,0,1,0,1,0,0),1)
					--End

					change = 1
					--eeepitch = 1
					if HipValLock == false then
						HipVal = 0
					end
					RootJoint.C0 = Clerp(RootJoint.C0,ROOTC0 * CF(math.random(-1.5,1.5),math.random(-1.5,1.5),math.random(-1.5,1.5)) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))), 2 / Animation_Speed)
					Neck.C0 = Clerp(Neck.C0, NECKC0 * CFrame.new(0,.5,0) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))), 2 / Animation_Speed)
					RightShoulder.C0 = Clerp(RightShoulder.C0, CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))) * RIGHTSHOULDERC0, 1 / Animation_Speed)
					LeftShoulder.C0 = Clerp(LeftShoulder.C0, CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))) * LEFTSHOULDERC0, 1 / Animation_Speed)
					RightHip.C0 = Clerp(RightHip.C0, CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))) , 2 / Animation_Speed)
					LeftHip.C0 = Clerp(LeftHip.C0, CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * ANGLES(RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999)), RAD(math.random(-99999,99999))) , 2 / Animation_Speed)
					GunJoint.C0 = Clerp(GunJoint.C0,CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),1)
					walkspeed = 500
				end
			end
		end
	end
	if taunt.Value ~= "Banisher" or taunt.Value ~= "Banisher2" or taunt.Value ~= "X⁔X" then
		Hole = GUN.Hole
		Holetwo = GUN.Hole2
	else
		Hole = GUN2.Hole
		Holetwo = GUN2.Hole
	end
	shieldblock.Transparency = 0
	shieldblock.Shape = "Ball"
	shieldblock.Locked = true
	shieldblock.Massless = false
	shieldblock.CanTouch = true
	shieldblock.CanCollide = false
	shieldblock.Archivable = true
	shieldblock.Material = "ForceField"
	shieldblock.Reflectance = 0
	shieldblock.Anchored = true
	shieldblock.CastShadow = false
	shieldblock:ClearAllChildren()
	eeeblock.Transparency = "inf"

	if not BallFolder then
		BallFolder = Instance.new("Folder")
		BallFolder.Parent = workspace.Terrain
		BallFolder.Name = randomstring()
	end
	if taunt.Value == "None2" and not attack then
		candohtaunt = false
		HoverBoard.Base.Transparency = 0
		HoverBoard.Colors.Transparency = 0
	elseif taunt.Value == "UpsideDown" and not attack then
		candohtaunt = false
		HoverBoard.Base.Transparency = 0
		HoverBoard.Colors.Transparency = 0
	else
		candohtaunt = true
		HoverBoard.Base.Transparency = 1
		HoverBoard.Colors.Transparency = 1
	end
	if taunt.Value == "h" then
		Box.Transparency = 0
		Box.SurfaceTransparency = "inf"
	else
		Box.Transparency = "inf"
		Box.SurfaceTransparency = "inf"
	end
	Hue = Hue + 1
	if (Hue>360) then Hue = 0 end

	swait()
end
--[[
 /$$                 /$$
| $$                | $$
| $$        /$$$$$$ | $$
| $$       /$$__  $$| $$
| $$      | $$  \ $$| $$
| $$      | $$  | $$| $$
| $$$$$$$$|  $$$$$$/| $$
|________/ \______/ |__/
]]
